import type {
  DevelopmentPlanPreviewRequest,
  DevelopmentPlanPreviewResponse,
  Project,
  ProjectBriefDraftRequest,
  ProjectBriefDraftResponse,
  ProjectIntakeRequest,
  ProjectIntakeResponse,
  ProjectProfileInput,
  ProjectToolResult,
  ApplyPatchRequest,
  ApplyPatchResponse,
  ProposePatchRequest,
  ProposePatchResponse,
  ApprovalDecisionResult,
  AgentInfo,
  AgentSelectionResult,
  CommandAnalysisRequest,
  CommandAnalysisResponse,
  GitDiffResponse,
  GitStatusResponse,
  ModelProfile,
  ModelRouteDecision,
  ModelRoutePersistResponse,
  ModelRoutePreviewResponse,
  ModelRegistryItem,
  ModelRouteRequest,
  ModelRouteResult,
  ProviderInfo,
  ProviderMode,
  ProviderStatus,
  GuidedExecutionPlanResponse,
  RollbackPatchRequest,
  RollbackPatchResponse,
  Run,
  StepToolPlanResponse,
  RunArtifact,
  RunAgentAssignment,
  RunProjectCommandRequest,
  RunProjectCommandResponse,
  RunStep,
  ClarificationAnswerResult,
  RegeneratePlanResult,
  ToolCall,
  WorkspaceStatus,
  TestRunResult,
  AutoStepReadRequest,
  AutoStepReadResponse,
  AutoContextGatherRequest,
  AutoContextGatherResponse,
  StepContextBundleResponse,
  ContextPatchDraftRequest,
  ContextPatchDraftResponse,
  PatchReviewRequest,
  PatchReviewResponse,
  PatchWorkflowPlanResponse,
} from "../types";

const BASE = "";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API ${res.status}: ${text}`);
  }
  return res.json();
}

// Health
export const getHealth = () => request<{ status: string; ollama: string }>("/health");

// Projects
export const getProjects = async () => {
  const projects = await request<Partial<Project>[]>("/api/projects");
  return projects.map(normalizeProject);
};
export const getProject = async (id: string) => normalizeProject(await request<Partial<Project>>(`/api/projects/${id}`));
export const createProject = (data: ProjectProfileInput) =>
  request<Partial<Project>>("/api/projects", { method: "POST", body: JSON.stringify(data) }).then(normalizeProject);
export const updateProject = (id: string, data: Partial<ProjectProfileInput>) =>
  request<Partial<Project>>(`/api/projects/${id}`, { method: "PATCH", body: JSON.stringify(data) }).then(normalizeProject);
export const analyzeProjectIntake = (data: ProjectIntakeRequest) =>
  request<ProjectIntakeResponse>("/api/project-intake/questions", { method: "POST", body: JSON.stringify(data) });
export const draftProjectBrief = (data: ProjectBriefDraftRequest) =>
  request<ProjectBriefDraftResponse>("/api/project-intake/brief-draft", {
    method: "POST",
    body: JSON.stringify(data),
  });
export const previewIntakePlan = (data: DevelopmentPlanPreviewRequest) =>
  request<DevelopmentPlanPreviewResponse>("/api/project-intake/plan-preview", {
    method: "POST",
    body: JSON.stringify(data),
  });

// Agents
export const getAgents = () => request<any[]>("/api/agents");
export const getAgentRegistry = () => request<AgentInfo[]>("/api/agents/registry");

// Models and providers
export const getModelRegistry = () => request<ModelRegistryItem[]>("/api/models/registry");
export const getModelProfiles = () => request<ModelProfile[]>("/api/models/profiles");
export const routeModel = (data: ModelRouteRequest) =>
  request<ModelRouteResult>("/api/models/route", { method: "POST", body: JSON.stringify(data) });
export const getProviders = () => request<ProviderInfo[]>("/api/providers");
export const getProviderStatus = () => request<ProviderStatus[]>("/api/providers/status");
export const updateProviderMode = (providerMode: ProviderMode) =>
  request<{ provider_mode: ProviderMode }>("/api/settings/provider-mode", {
    method: "PATCH",
    body: JSON.stringify({ provider_mode: providerMode }),
  });

// Runs
export const getRuns = () => request<Run[]>("/api/runs");
export const createRun = (data: { prompt: string; mode?: string; project_id?: string }) =>
  request<Run>("/api/runs", { method: "POST", body: JSON.stringify(data) });
export const getRun = (id: string) => request<Run>(`/api/runs/${id}`);
export const getRunSteps = (id: string) => request<RunStep[]>(`/api/runs/${id}/steps`);
export const getRunStepToolPlan = (id: string) =>
  request<StepToolPlanResponse>(`/api/runs/${id}/steps/tool-plan`);
export const getRunGuidedExecutionPlan = (id: string) =>
  request<GuidedExecutionPlanResponse>(`/api/runs/${id}/guided-execution-plan`);
export const getRunPatchWorkflowPlan = (id: string) =>
  request<PatchWorkflowPlanResponse>(`/api/runs/${id}/patch-workflow-plan`);
export const runStepAutoRead = (runId: string, stepId: string, req: AutoStepReadRequest) =>
  request<AutoStepReadResponse>(`/api/runs/${runId}/steps/${stepId}/auto-read`, {
    method: "POST",
    body: JSON.stringify(req),
  });
export const runStepAutoContext = (runId: string, stepId: string, req: AutoContextGatherRequest) =>
  request<AutoContextGatherResponse>(`/api/runs/${runId}/steps/${stepId}/auto-context`, {
    method: "POST",
    body: JSON.stringify(req),
  });
export const getRunStepContextBundle = (runId: string, stepId: string) =>
  request<StepContextBundleResponse>(`/api/runs/${runId}/steps/${stepId}/context-bundle`);
export const buildContextPatchDraft = (runId: string, stepId: string, req: ContextPatchDraftRequest) =>
  request<ContextPatchDraftResponse>(`/api/runs/${runId}/steps/${stepId}/context-patch-draft`, {
    method: "POST",
    body: JSON.stringify(req),
  });
export const getRunAgents = (id: string) => request<RunAgentAssignment[]>(`/api/runs/${id}/agents`);
export const selectRunAgents = (id: string) =>
  request<AgentSelectionResult>(`/api/runs/${id}/agents/select`, { method: "POST" });
export const updateRunAgent = (runId: string, agentId: string, data: Partial<RunAgentAssignment>) =>
  request<RunAgentAssignment>(`/api/runs/${runId}/agents/${agentId}`, {
    method: "PATCH",
    body: JSON.stringify(data),
  });
export const getRunModelRoutes = (id: string, scope: "agents" | "steps" | "all" = "all") =>
  request<ModelRouteDecision[]>(`/api/runs/${id}/model-routes?scope=${scope}`);
export const previewRunModelRoutes = (id: string) =>
  request<ModelRoutePreviewResponse>(`/api/runs/${id}/model-routes/preview`, { method: "POST" });
export const persistRunModelRoutes = (id: string) =>
  request<ModelRoutePersistResponse>(`/api/runs/${id}/model-routes/persist`, { method: "POST" });
export const previewStepModelRoutes = (id: string) =>
  request<ModelRoutePreviewResponse>(`/api/runs/${id}/steps/model-routes/preview`, { method: "POST" });
export const persistStepModelRoutes = (id: string) =>
  request<ModelRoutePersistResponse>(`/api/runs/${id}/steps/model-routes/persist`, { method: "POST" });
export const getRunArtifact = (id: string, artifactName: string) =>
  request<RunArtifact>(`/api/runs/${id}/artifacts/${encodeURIComponent(artifactName)}`);
export const submitClarifications = (id: string, answers: string) =>
  request<ClarificationAnswerResult>(`/api/runs/${id}/clarifications`, {
    method: "POST",
    body: JSON.stringify({ answers }),
  });
export const regeneratePlan = (id: string) =>
  request<RegeneratePlanResult>(`/api/runs/${id}/regenerate-plan`, { method: "POST" });
export const stopRun = (id: string) =>
  request<any>(`/api/runs/${id}/stop`, { method: "POST" });

// Local tools
export const getWorkspaceStatus = () => request<WorkspaceStatus>("/api/workspace/status");
export const runTests = () =>
  request<TestRunResult>("/api/tools/run-tests", { method: "POST" });
export const getProjectWorkspaceStatus = (projectId: string) =>
  request<WorkspaceStatus>(`/api/projects/${projectId}/workspace/status`);
export const runProjectTests = (projectId: string) =>
  request<ProjectToolResult>(`/api/projects/${projectId}/tools/run-tests`, { method: "POST" });
export const runProjectBuild = (projectId: string) =>
  request<ProjectToolResult>(`/api/projects/${projectId}/tools/run-build`, { method: "POST" });
export const runProjectCommand = (projectId: string, req: RunProjectCommandRequest) =>
  request<RunProjectCommandResponse>(`/api/projects/${projectId}/tools/run-command`, {
    method: "POST",
    body: JSON.stringify(req),
  });
export const analyzeCommandResult = (projectId: string, req: CommandAnalysisRequest) =>
  request<CommandAnalysisResponse>(`/api/projects/${projectId}/tools/analyze-command-result`, {
    method: "POST",
    body: JSON.stringify(req),
  });
export const getRunToolCalls = (runId: string) =>
  request<ToolCall[]>(`/api/runs/${runId}/tool-calls`);
export const getStepToolCalls = (runId: string, stepId: string) =>
  request<ToolCall[]>(`/api/runs/${runId}/steps/${stepId}/tool-calls`);
export const getProjectToolCalls = (projectId: string) =>
  request<ToolCall[]>(`/api/projects/${projectId}/tool-calls`);
export const getProjectGitStatus = (projectId: string) =>
  request<GitStatusResponse>(`/api/projects/${projectId}/git/status`);
export const getProjectGitDiff = (projectId: string) =>
  request<GitDiffResponse>(`/api/projects/${projectId}/git/diff`);
export const proposeProjectPatch = (projectId: string, data: ProposePatchRequest) =>
  request<ProposePatchResponse>(`/api/projects/${projectId}/tools/propose-patch`, {
    method: "POST",
    body: JSON.stringify(data),
  });
export const applyProjectPatch = (projectId: string, data: ApplyPatchRequest) =>
  request<ApplyPatchResponse>(`/api/projects/${projectId}/tools/apply-patch`, {
    method: "POST",
    body: JSON.stringify(data),
  });
export const rollbackProjectPatch = (projectId: string, data: RollbackPatchRequest) =>
  request<RollbackPatchResponse>(`/api/projects/${projectId}/tools/rollback-patch`, {
    method: "POST",
    body: JSON.stringify(data),
  });
export const reviewProjectPatch = (projectId: string, data: PatchReviewRequest) =>
  request<PatchReviewResponse>(`/api/projects/${projectId}/tools/review-patch`, {
    method: "POST",
    body: JSON.stringify(data),
  });

// Approvals
export const getApprovals = () => request<any[]>("/api/approvals");
export const approveRequest = (id: string) =>
  request<ApprovalDecisionResult>(`/api/approvals/${id}/approve`, { method: "POST", body: JSON.stringify({}) });
export const rejectRequest = (id: string) =>
  request<any>(`/api/approvals/${id}/reject`, { method: "POST", body: JSON.stringify({}) });

// Config
export const getConfig = () => request<any>("/api/config");
export const updateConfig = (data: Record<string, unknown>) =>
  request<any>("/api/config", { method: "POST", body: JSON.stringify(data) });

function normalizeProject(project: Partial<Project>): Project {
  return {
    id: project.id || "",
    name: project.name || "",
    path: project.path || "",
    description: project.description || "",
    stack: project.stack || "",
    package_manager: project.package_manager || "",
    test_command: project.test_command || "",
    build_command: project.build_command || "",
    safe_commands: Array.isArray(project.safe_commands) ? project.safe_commands : [],
    blocked_commands: Array.isArray(project.blocked_commands) ? project.blocked_commands : [],
    ignore_paths: Array.isArray(project.ignore_paths) ? project.ignore_paths : [],
    created_at: project.created_at || "",
    updated_at: project.updated_at || null,
  };
}
