export type RunStatus = "pending" | "running" | "waiting_approval" | "completed" | "failed" | "stopped";
export type ApprovalStatus = "pending" | "approved" | "rejected";
export type ProviderType = "ollama" | "codex" | "claude";
export type RunMode = "offline" | "hybrid" | "cloud";
export type ProviderMode = "local" | "hybrid" | "cloud";
export type ModelProviderId = "local_ollama" | "claude_code" | "chatgpt_codex" | "external_api" | string;
export type ProjectIntakeMode = "new_project" | "existing_project" | "unknown";
export type ProjectIntakeQuestionPriority = "required" | "recommended" | "optional";
export type ProjectIntakeQuestionCategory =
  | "product_goal"
  | "users_roles"
  | "platform"
  | "tech_stack"
  | "data_storage"
  | "auth_security"
  | "integrations"
  | "files_uploads"
  | "payments_billing"
  | "notifications"
  | "ui_design"
  | "deployment"
  | "existing_project"
  | "constraints"
  | "quality_testing";
export type ProjectIntakeTargetType =
  | "web_app"
  | "mobile_app"
  | "desktop_app"
  | "api_service"
  | "cli_tool"
  | "automation"
  | "unknown";
export type ProjectIntakeMaturityGoal =
  | "mvp"
  | "full_product"
  | "diploma"
  | "prototype"
  | "internal_tool"
  | "unknown";

export interface Project {
  id: string;
  name: string;
  path: string;
  description: string;
  stack: string;
  package_manager: string;
  test_command: string;
  build_command: string;
  safe_commands: string[];
  blocked_commands: string[];
  ignore_paths: string[];
  created_at: string;
  updated_at: string | null;
}

export interface ProjectIntakeQuestion {
  id: string;
  category: ProjectIntakeQuestionCategory;
  priority: ProjectIntakeQuestionPriority;
  question: string;
  why_it_matters: string;
  suggested_default?: string | null;
  options?: string[] | null;
}

export interface ProjectIntakeRequest {
  idea: string;
  mode?: ProjectIntakeMode | null;
  existing_project_attached?: boolean | null;
  known_stack?: string[] | null;
  known_constraints?: string[] | null;
  user_goal?: string | null;
}

export interface ProjectIntakeResponse {
  mode: ProjectIntakeMode;
  detected_target_type: ProjectIntakeTargetType;
  detected_maturity_goal: ProjectIntakeMaturityGoal;
  summary: string;
  assumptions: string[];
  missing_information: string[];
  questions: ProjectIntakeQuestion[];
  ready_to_plan: boolean;
  recommended_next_step: string;
  confidence: string;
}

export type ProjectBriefSectionStatus = "confirmed" | "assumed" | "missing";

export interface ProjectBriefSection {
  title: string;
  content: string;
  status: ProjectBriefSectionStatus;
  notes?: string | null;
}

export interface ProjectBriefDraftRequest extends ProjectIntakeRequest {
  answers?: Record<string, string> | null;
}

export interface ProjectBriefDraftResponse {
  title: string;
  mode: ProjectIntakeMode;
  target_type: ProjectIntakeTargetType;
  maturity_goal: ProjectIntakeMaturityGoal;
  readiness: string;
  summary: string;
  brief_markdown: string;
  sections: ProjectBriefSection[];
  assumptions: string[];
  missing_information: string[];
  open_questions: ProjectIntakeQuestion[];
  recommended_next_step: string;
  ready_to_plan: boolean;
}

export type DevelopmentPlanPhaseStatus = "ready" | "needs_input" | "blocked";

export interface DevelopmentPlanPhase {
  id: string;
  title: string;
  description: string;
  priority: ProjectIntakeQuestionPriority;
  status: DevelopmentPlanPhaseStatus;
  suggested_agent_id?: string | null;
  depends_on: string[];
  deliverables: string[];
  risks: string[];
}

export interface DevelopmentPlanSourceReadiness {
  intake_ready_to_plan: boolean;
  brief_ready_to_plan: boolean;
}

export interface DevelopmentPlanPreviewRequest extends ProjectBriefDraftRequest {
  brief_markdown?: string | null;
}

export interface DevelopmentPlanPreviewResponse {
  title: string;
  mode: ProjectIntakeMode;
  target_type: ProjectIntakeTargetType;
  maturity_goal: ProjectIntakeMaturityGoal;
  ready_to_start: boolean;
  summary: string;
  phases: DevelopmentPlanPhase[];
  required_inputs: string[];
  assumptions: string[];
  risks: string[];
  recommended_agent_ids: string[];
  recommended_next_step: string;
  source_readiness: DevelopmentPlanSourceReadiness;
}

export interface AgentInfo {
  id: string;
  name: string;
  role: string;
  description: string;
  provider: ProviderType;
  instructions_file: string;
  category: string;
  skills: string[];
  default_tools: string[];
  model_profile: string;
  default_model: string;
  fast_model: string;
  reasoning_model: string;
  can_edit_files: boolean;
  can_run_commands: boolean;
  risk_level: string;
  enabled: boolean;
  best_for: string[];
}

export interface Run {
  id: string;
  task_id: string;
  project_id: string;
  project_path: string;
  current_step_id: string;
  agent_id: string;
  status: RunStatus;
  mode: RunMode;
  prompt: string;
  plan: string;
  result: string;
  logs: string[];
  artifacts: string[];
  run_dir: string;
  created_at: string;
  finished_at: string | null;
}

export interface RunStep {
  id: string;
  run_id: string;
  parent_step_id: string;
  agent_id: string;
  status: string;
  title: string;
  input: string;
  output: string;
  error: string;
  started_at: string;
  finished_at: string;
  created_at: string;
}

export interface RunArtifact {
  name: string;
  path: string;
  content: string;
}

export interface ClarificationAnswerResult {
  artifact: string;
  content: string;
  step: RunStep;
}

export interface RegeneratePlanResult {
  plan: string;
  architecture: string;
  tasks: string;
  staged_steps: RunStep[];
  source: string;
  artifacts: string[];
  step: RunStep | null;
}

export interface ApprovalRequest {
  id: string;
  run_id: string;
  action: string;
  command: string;
  description: string;
  status: ApprovalStatus;
  created_at: string;
  resolved_at: string | null;
}

export interface HealthStatus {
  status: string;
  timestamp: string;
  ollama: string;
}

export interface Config {
  default_mode: string;
  provider_mode?: ProviderMode;
  ollama: { base_url: string; default_model: string; timeout_seconds: number };
  codex: { enabled: boolean };
  claude: { enabled: boolean };
  [key: string]: unknown;
}

export interface WorkspaceChange {
  status: string;
  path: string;
}

export interface WorkspaceStatus {
  branch: string;
  clean: boolean;
  changes: WorkspaceChange[];
  raw: string;
  error: string;
  returncode?: number;
  cwd?: string;
}

export interface TestRunResult {
  command: string;
  status: "passed" | "failed";
  returncode: number;
  stdout: string;
  stderr: string;
  started_at: string;
  finished_at: string;
  report_path: string;
}

export interface ProjectProfileInput {
  name: string;
  path: string;
  description?: string;
  stack?: string;
  package_manager?: string;
  test_command?: string;
  build_command?: string;
  safe_commands?: string[];
  blocked_commands?: string[];
  ignore_paths?: string[];
}

export interface ProjectToolResult {
  approval_required: boolean;
  approval_id?: string;
  tool_call_id?: string;
  project_id: string;
  project_path: string;
  command: string;
  command_type: "test" | "build" | string;
  status: "passed" | "failed" | "approval_required";
  returncode: number | null;
  stdout: string;
  stderr: string;
  started_at?: string;
  finished_at?: string;
  action?: string;
  description?: string;
  report_path: string;
}

export interface ToolCall {
  id: string;
  run_id: string;
  project_id: string;
  step_id: string;
  tool_name: string;
  command: string;
  cwd: string;
  status: string;
  approval_id: string;
  stdout: string;
  stderr: string;
  returncode: number | null;
  report_path: string;
  started_at: string;
  finished_at: string;
  input_json: string;
  output_json: string;
  error: string;
  risk_level: string;
  completed_at: string | null;
  created_at: string;
}

export interface GitChangedFile {
  status: string;
  path: string;
}

export interface GitStatusResponse {
  project_id: string;
  project_path: string;
  command: string[];
  returncode: number;
  stdout: string;
  stderr: string;
  changed_files: GitChangedFile[];
  clean: boolean;
}

export interface GitDiffResponse {
  project_id: string;
  project_path: string;
  commands: string[][];
  returncode: number;
  stat: string;
  name_only: string[];
  diff: string;
  stderr: string;
  truncated: boolean;
}

export interface PatchOperation {
  file_path: string;
  old_text: string;
  new_text: string;
  create_if_missing: boolean;
  replace_all: boolean;
}

export interface ProposePatchRequest {
  operations: PatchOperation[];
  run_id?: string;
  step_id?: string;
  agent_id?: string;
}

export interface ProposedPatchFile {
  path: string;
  status: "create" | "modify" | "unchanged" | "error" | string;
  diff: string;
  error?: string;
}

export interface ProposePatchResponse {
  files: ProposedPatchFile[];
  summary: string;
  warnings: string[];
  tool_call_id?: string;
  proposal_id?: string;
}

export interface ApplyPatchRequest {
  operations: PatchOperation[];
  run_id?: string;
  step_id?: string;
  agent_id?: string;
  confirm: boolean;
  expected_summary?: string;
  proposal_id?: string;
}

export interface AppliedPatchFile {
  path: string;
  status: "modified" | "created" | "unchanged" | "error" | string;
  error?: string;
}

export interface ApplyPatchResponse {
  files: AppliedPatchFile[];
  summary: string;
  git_status?: string;
  git_diff_stat?: string;
  warnings: string[];
  tool_call_id?: string;
  applied_from_proposal_id?: string;
}

export interface RolledBackFile {
  path: string;
  operation: string;
  status: string;
  reason?: string;
}

export interface RollbackPatchRequest {
  tool_call_id: string;
  confirm: boolean;
  run_id?: string;
  step_id?: string;
  agent_id?: string;
}

export interface RollbackPatchResponse {
  rolled_back_files: RolledBackFile[];
  skipped_files: RolledBackFile[];
  warnings: string[];
  git_status?: string;
  git_diff_stat?: string;
  tool_call_id?: string;
}

// ── Safe Test Command Runner ──────────────────────────────────────────────────

export type ProjectCommandKind = "test" | "build" | "lint" | "typecheck";

export interface RunProjectCommandRequest {
  command_kind: ProjectCommandKind;
  run_id?: string;
  step_id?: string;
  agent_id?: string;
  timeout_seconds?: number;
}

export interface RunProjectCommandResponse {
  command_kind: string;
  command: string;
  cwd: string;
  returncode: number;
  stdout: string;
  stderr: string;
  duration_ms: number;
  timed_out: boolean;
  tool_call_id: string;
}

// ── Test Result Analysis ──────────────────────────────────────────────────────

export type CommandIssueKind =
  | "test_failure"
  | "assertion_error"
  | "traceback"
  | "type_error"
  | "lint_error"
  | "build_error"
  | "timeout"
  | "unknown";

export interface CommandIssue {
  kind: CommandIssueKind | string;
  file_path: string | null;
  line: number | null;
  message: string;
  raw_excerpt: string;
}

export interface CommandAnalysisRequest {
  tool_call_id?: string;
  stdout?: string;
  stderr?: string;
  returncode?: number;
  command_kind?: string;
  run_id?: string;
  step_id?: string;
  agent_id?: string;
}

export interface CommandAnalysisResponse {
  status: "passed" | "failed" | "timed_out" | "unknown";
  summary: string;
  issues: CommandIssue[];
  suggested_next_actions: string[];
  can_create_fix_proposal: boolean;
  source_tool_call_id: string;
}

export interface RunAgentAssignment {
  id: string;
  run_id: string;
  agent_id: string;
  assigned_role: string;
  reason: string;
  confidence: number;
  status: string;
  created_at: string;
}

export interface AgentSelectionResult {
  selected_agents: RunAgentAssignment[];
  team_size: number;
  recommended_execution_mode: RunMode;
  detected_stack: string[];
  signals: Record<string, unknown>;
}

export interface ApprovalDecisionResult {
  approval: ApprovalRequest;
  execution: ProjectToolResult | null;
  execution_error?: string;
  already_resolved?: boolean;
}

export interface ModelRegistryItem {
  id: string;
  provider: ModelProviderId;
  display_name: string;
  family: string;
  capabilities: string[];
  context_window: number;
  memory_tier: "small" | "medium" | "large" | "xlarge" | string;
  recommended_for: string[];
  installed: boolean;
  enabled: boolean;
  max_parallel: number;
  notes: string;
}

export interface ModelProfile {
  id: string;
  primary_model: string;
  fast_model: string;
  reasoning_model: string;
  fallback_model: string;
  allowed_providers: ModelProviderId[];
  preferred_provider: ModelProviderId;
  max_parallel: number;
  local_only_default: boolean;
  description: string;
}

export interface ProviderInfo {
  id: ModelProviderId;
  display_name: string;
  kind: string;
  enabled: boolean;
  available: boolean;
  local: boolean;
  requires_approval: boolean;
  supports_execution: boolean;
  modes: ProviderMode[];
  notes: string;
}

export interface ProviderStatus {
  id: ModelProviderId;
  enabled: boolean;
  available: boolean;
  status: string;
  models: string[];
  warnings: string[];
}

export interface ModelRouteRequest {
  agent_id?: string;
  task_type?: string;
  model_profile?: string;
  provider_mode?: ProviderMode;
  available_models?: string[];
  project_privacy_level?: string;
  hardware_memory_gb?: number | null;
  user_preference_model?: string;
  user_preference_provider?: ModelProviderId;
}

export interface ModelRouteResult {
  selected_model: string;
  selected_provider: ModelProviderId;
  fallback_model: string;
  reason: string;
  confidence: number;
  warnings: string[];
  model_profile: string;
  task_type: string;
}

export interface ModelRouteDecision {
  id: string;
  run_id: string;
  step_id: string | null;
  agent_id: string;
  task_type: string;
  model_profile: string;
  selected_model: string;
  selected_provider: ModelProviderId;
  fallback_model: string;
  fallback_provider: ModelProviderId | null;
  provider_mode: ProviderMode;
  reason: string;
  confidence: number;
  warnings: string[];
  created_at: string;
  updated_at: string | null;
}

export interface ModelRouteDecisionResponse {
  run_id: string;
  count: number;
  persisted: boolean;
  decisions: ModelRouteDecision[];
  warnings: string[];
}

export type ModelRoutePreviewResponse = ModelRouteDecisionResponse;
export type ModelRoutePersistResponse = ModelRouteDecisionResponse;

// ── Orchestrator Tool Planning ────────────────────────────────────────────────

export interface StepToolRecommendation {
  step_id: string;
  agent_id: string;
  task_type: string;
  recommended_tools: string[];
  reason: string;
  confidence: number;
  warnings: string[];
}

export interface StepToolPlanResponse {
  run_id: string;
  recommendations: StepToolRecommendation[];
  summary: string;
  warnings: string[];
}

// ── Orchestrator Guided Execution ─────────────────────────────────────────────

export interface GuidedStepAction {
  step_id: string;
  action_id: string;
  action_type: string;
  tool_name: string;
  title: string;
  description: string;
  reason: string;
  requires_confirmation: boolean;
  risk_level: string;
  enabled: boolean;
  blocked_reason: string;
  related_tool_call_id: string;
  related_proposal_id: string;
}

export interface GuidedStepExecutionPlan {
  run_id: string;
  step_id: string;
  agent_id: string;
  task_type: string;
  recommended_next_action: GuidedStepAction | null;
  actions: GuidedStepAction[];
  status_summary: string;
  warnings: string[];
}

export interface GuidedExecutionPlanResponse {
  run_id: string;
  steps: GuidedStepExecutionPlan[];
  summary: string;
  warnings: string[];
}

// ── Safe Auto Read/Search ──────────────────────────────────────────────────────

export interface AutoStepReadRequest {
  step_id: string;
  action_type: string;
  query?: string;
  file_path?: string;
  limit?: number;
  run_id?: string;
  agent_id?: string;
}

export interface AutoStepReadResponse {
  run_id: string;
  step_id: string;
  action_type: string;
  tool_call_id: string;
  status: string;
  summary: string;
  result: Record<string, unknown>;
  warnings: string[];
}

// ── Auto Context Gathering ─────────────────────────────────────────────────────

export interface AutoContextGatherRequest {
  max_tool_calls?: number;
  query?: string;
  include_file_patterns?: string[];
  exclude_file_patterns?: string[];
  agent_id?: string;
}

export interface AutoContextGatheredFile {
  file_path: string;
  reason: string;
  source_tool_call_id?: string;
}

export interface AutoContextGatherResponse {
  run_id: string;
  step_id: string;
  status: string;
  summary: string;
  tool_call_ids: string[];
  searched_queries: string[];
  files_considered: string[];
  files_read: AutoContextGatheredFile[];
  warnings: string[];
  next_recommended_action: string;
}

// ── Step Context Bundle ────────────────────────────────────────────────────────

export interface StepContextFile {
  file_path: string;
  source_tool_call_ids: string[];
  reason: string | null;
  snippets: string[];
  read: boolean;
  match_count: number;
}

export interface StepContextBundle {
  run_id: string;
  step_id: string;
  agent_id: string | null;
  task_type: string | null;
  status: string;
  summary: string;
  queries: string[];
  files: StepContextFile[];
  tool_call_ids: string[];
  warnings: string[];
  next_recommended_action: string | null;
}

export interface StepContextBundleResponse {
  bundle: StepContextBundle;
}

// ── Context Patch Draft ────────────────────────────────────────────────────────

export interface ContextPatchDraftRequest {
  preferred_file_path?: string;
  preferred_snippet_index?: number;
  intent?: string;
  agent_id?: string;
}

export interface ContextPatchDraftCandidate {
  file_path: string;
  old_text: string;
  new_text: string;
  reason: string;
  confidence: number;
  source_tool_call_ids: string[];
  warnings: string[];
}

export interface ContextPatchDraftResponse {
  run_id: string;
  step_id: string;
  status: string;
  summary: string;
  candidates: ContextPatchDraftCandidate[];
  recommended_candidate_index: number | null;
  warnings: string[];
  next_recommended_action: string | null;
}

// ── Patch Proposal Review ─────────────────────────────────────────────────────

export interface PatchReviewOperation {
  file_path: string;
  old_text: string;
  new_text: string;
}

export interface PatchReviewRequest {
  operations: PatchReviewOperation[];
  run_id?: string;
  step_id?: string;
  agent_id?: string;
}

export interface PatchReviewIssue {
  severity: "info" | "warning" | "blocker";
  code: string;
  message: string;
  file_path: string | null;
  operation_index: number | null;
}

export interface PatchReviewOperationResult {
  operation_index: number;
  file_path: string;
  status: "ok" | "warning" | "blocked";
  old_text_found: boolean;
  old_text_occurrences: number;
  estimated_diff_lines: number;
  issues: PatchReviewIssue[];
}

export interface PatchReviewResponse {
  status: "ok" | "warning" | "blocked";
  summary: string;
  operation_results: PatchReviewOperationResult[];
  issues: PatchReviewIssue[];
  safe_to_create_proposal: boolean;
  safe_to_apply: boolean;
}

// ── Approval-gated Patch Workflow Orchestrator ────────────────────────────────

export interface PatchWorkflowStage {
  stage_id: string;
  title: string;
  status: "not_started" | "ready" | "blocked" | "completed" | "warning";
  summary: string;
  related_tool_call_ids: string[];
  warnings: string[];
  blockers: string[];
}

export interface PatchWorkflowNextAction {
  action_type: string;
  title: string;
  description: string;
  risk_level: "low" | "medium" | "high";
  requires_confirmation: boolean;
  enabled: boolean;
  blocked_reason: string | null;
}

export interface StepPatchWorkflowPlan {
  run_id: string;
  step_id: string;
  agent_id: string | null;
  task_type: string | null;
  status: "not_started" | "in_progress" | "blocked" | "ready_for_review" | "ready_for_tests" | "done";
  summary: string;
  stages: PatchWorkflowStage[];
  recommended_next_action: PatchWorkflowNextAction | null;
  warnings: string[];
  blockers: string[];
}

export interface PatchWorkflowPlanResponse {
  run_id: string;
  steps: StepPatchWorkflowPlan[];
  summary: string;
  warnings: string[];
}
