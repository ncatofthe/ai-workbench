import { useEffect, useState, type ReactNode } from "react";
import { Link, useParams } from "react-router-dom";
import {
  analyzeCommandResult,
  applyProjectPatch,
  rollbackProjectPatch,
  runProjectCommand,
  getAgentRegistry,
  getModelProfiles,
  getModelRegistry,
  getRun,
  getRunAgents,
  getRunArtifact,
  getRunGuidedExecutionPlan,
  getRunModelRoutes,
  getRunSteps,
  getRunStepToolPlan,
  getRunToolCalls,
  getStepToolCalls,
  proposeProjectPatch,
  reviewProjectPatch,
  getRunPatchWorkflowPlan,
  runStepAutoRead,
  runStepAutoContext,
  getRunStepContextBundle,
  buildContextPatchDraft,
  persistRunModelRoutes,
  previewRunModelRoutes,
  regeneratePlan,
  selectRunAgents,
  stopRun,
  submitClarifications,
} from "../api/client";

import StatusBadge from "../components/StatusBadge";
import { NextActionCard, WorkflowActionLauncher, WorkflowModeSelector, WorkflowStageRow, WorkflowStepPicker } from "../components/run-detail/PatchWorkflowPanel";
import {
  WORKFLOW_BOUNDARY_SUMMARY_LINES,
  WORKFLOW_MANUAL_ONLY_ACTION_TYPES,
  getWorkflowActionBoundary,
  type WorkflowAutomationMode,
} from "../components/run-detail/workflowActionPolicy";
import type {
  AgentInfo,
  AutoContextGatherResponse,
  AutoStepReadResponse,
  ContextPatchDraftCandidate,
  ContextPatchDraftResponse,
  StepContextBundle,
  StepContextFile,
  CommandAnalysisResponse,
  GuidedExecutionPlanResponse,
  GuidedStepExecutionPlan,
  GuidedStepAction,
  ModelProfile,
  ModelRegistryItem,
  ModelRouteDecision,
  ApplyPatchResponse,
  ProposePatchResponse,
  RollbackPatchResponse,
  PatchReviewResponse,
  PatchReviewIssue,
  PatchWorkflowPlanResponse,
  StepPatchWorkflowPlan,
  PatchWorkflowNextAction,
  Run,
  RunAgentAssignment,
  RunProjectCommandResponse,
  RunStep,
  StepToolPlanResponse,
  ToolCall,
} from "../types";

type IssuePrefill = {
  file_path: string;
  context_kind: string;
  context_location: string;
  context_message: string;
};

type PatchFormState = {
  file_path: string;
  old_text: string;
  new_text: string;
  create_if_missing: boolean;
  replace_all: boolean;
};

type ManualFocusResult = {
  message: string;
  error?: string;
};

type ToolCallFocus = {
  nonce: number;
  stepId?: string;
  toolName?: string;
  status?: string;
  toolCallId?: string;
  visibleLimit?: number;
  message?: string;
};

const emptyPatchForm: PatchFormState = {
  file_path: "",
  old_text: "",
  new_text: "",
  create_if_missing: false,
  replace_all: false,
};

function workflowUiStorageKey(runId: string): string {
  return `ai-workbench:run:${runId}:workflow-ui`;
}

function isWorkflowAutomationMode(value: unknown): value is WorkflowAutomationMode {
  return value === "manual" || value === "guided" || value === "safe_prep";
}

function loadWorkflowUiState(runId: string): {
  workflowAutomationMode: WorkflowAutomationMode;
  activeWorkflowStepId: string | null;
} {
  try {
    const raw = window.localStorage.getItem(workflowUiStorageKey(runId));
    if (!raw) return { workflowAutomationMode: "guided", activeWorkflowStepId: null };
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    return {
      workflowAutomationMode: isWorkflowAutomationMode(parsed.workflowAutomationMode)
        ? parsed.workflowAutomationMode
        : "guided",
      activeWorkflowStepId:
        typeof parsed.activeWorkflowStepId === "string" && parsed.activeWorkflowStepId.trim()
          ? parsed.activeWorkflowStepId
          : null,
    };
  } catch {
    return { workflowAutomationMode: "guided", activeWorkflowStepId: null };
  }
}

function saveWorkflowUiState(
  runId: string,
  state: { workflowAutomationMode: WorkflowAutomationMode; activeWorkflowStepId: string | null },
) {
  try {
    window.localStorage.setItem(workflowUiStorageKey(runId), JSON.stringify(state));
  } catch {
    // localStorage can be unavailable in privacy modes; ignore and keep page state.
  }
}

export default function RunDetail() {
  const { id } = useParams<{ id: string }>();
  const [run, setRun] = useState<Run | null>(null);
  const [steps, setSteps] = useState<RunStep[]>([]);
  const [team, setTeam] = useState<RunAgentAssignment[]>([]);
  const [agentRegistry, setAgentRegistry] = useState<AgentInfo[]>([]);
  const [modelProfiles, setModelProfiles] = useState<ModelProfile[]>([]);
  const [modelRegistry, setModelRegistry] = useState<ModelRegistryItem[]>([]);
  const [modelRoutes, setModelRoutes] = useState<ModelRouteDecision[]>([]);
  const [modelRoutesPersisted, setModelRoutesPersisted] = useState(true);
  const [stepRoutes, setStepRoutes] = useState<Record<string, ModelRouteDecision>>({});
  const [toolCalls, setToolCalls] = useState<ToolCall[]>([]);
  const [toolCallsError, setToolCallsError] = useState("");
  const [runNotFound, setRunNotFound] = useState(false);
  const [artifactContent, setArtifactContent] = useState<Record<string, string>>({});
  const [answers, setAnswers] = useState("");
  const [notice, setNotice] = useState("");
  const [savingAnswers, setSavingAnswers] = useState(false);
  const [regeneratingPlan, setRegeneratingPlan] = useState(false);
  const [selectingTeam, setSelectingTeam] = useState(false);
  const [routingModels, setRoutingModels] = useState(false);
  const [toolPlan, setToolPlan] = useState<StepToolPlanResponse | null>(null);
  const [toolPlanLoading, setToolPlanLoading] = useState(false);
  const [toolPlanError, setToolPlanError] = useState("");
  const [guidedPlan, setGuidedPlan] = useState<GuidedExecutionPlanResponse | null>(null);
  const [guidedPlanLoading, setGuidedPlanLoading] = useState(false);
  const [guidedPlanError, setGuidedPlanError] = useState("");
  const [contextBundles, setContextBundles] = useState<Record<string, StepContextBundle>>({});
  const [bundleLoading, setBundleLoading] = useState<Record<string, boolean>>({});
  const [draftPrefills, setDraftPrefills] = useState<Record<string, PatchFormState | null>>({});
  const [toolCallFocus, setToolCallFocus] = useState<ToolCallFocus | null>(null);
  const [workflowPlan, setWorkflowPlan] = useState<PatchWorkflowPlanResponse | null>(null);
  const [workflowPlanLoading, setWorkflowPlanLoading] = useState(false);
  const [workflowPlanError, setWorkflowPlanError] = useState("");
  const [activeWorkflowStepId, setActiveWorkflowStepId] = useState<string | null>(null);
  const [workflowAutomationMode, setWorkflowAutomationMode] = useState<WorkflowAutomationMode>("guided");
  const [workflowUiLoadedForRun, setWorkflowUiLoadedForRun] = useState<string | null>(null);
  const [tab, setTab] = useState<
    "timeline" | "team" | "spec" | "questions" | "plan" | "architecture" | "tasks" | "logs" | "result" | "tool-plan" | "guided" | "patch-workflow"
  >("timeline");

  const refreshToolCalls = async () => {
    if (!id) return;
    const nextToolCalls = await getRunToolCalls(id).catch((e: any) => {
      setToolCallsError(readableError(e));
      return null;
    });
    if (nextToolCalls) {
      setToolCalls(nextToolCalls);
      setToolCallsError("");
    }
  };

  const loadToolPlan = async () => {
    if (!id) return;
    setToolPlanLoading(true);
    setToolPlanError("");
    try {
      const plan = await getRunStepToolPlan(id);
      setToolPlan(plan);
    } catch (e: any) {
      setToolPlanError(readableError(e));
    } finally {
      setToolPlanLoading(false);
    }
  };

  const loadGuidedPlan = async () => {
    if (!id) return;
    setGuidedPlanLoading(true);
    setGuidedPlanError("");
    try {
      const plan = await getRunGuidedExecutionPlan(id);
      setGuidedPlan(plan);
    } catch (e: any) {
      setGuidedPlanError(readableError(e));
    } finally {
      setGuidedPlanLoading(false);
    }
  };

  const loadContextBundle = async (stepId: string) => {
    if (!id) return;
    setBundleLoading((prev) => ({ ...prev, [stepId]: true }));
    try {
      const res = await getRunStepContextBundle(id, stepId);
      setContextBundles((prev) => ({ ...prev, [stepId]: res.bundle }));
    } catch {
      // silently ignore — empty bundle shown
    } finally {
      setBundleLoading((prev) => ({ ...prev, [stepId]: false }));
    }
  };

  const loadWorkflowPlan = async () => {
    if (!id) return;
    setWorkflowPlanLoading(true);
    setWorkflowPlanError("");
    try {
      const plan = await getRunPatchWorkflowPlan(id);
      setWorkflowPlan(plan);
    } catch (e: any) {
      setWorkflowPlanError(readableError(e));
    } finally {
      setWorkflowPlanLoading(false);
    }
  };

  useEffect(() => {
    if (!id) return;
    setWorkflowUiLoadedForRun(null);
    const saved = loadWorkflowUiState(id);
    setWorkflowAutomationMode(saved.workflowAutomationMode);
    setActiveWorkflowStepId(saved.activeWorkflowStepId);
    setWorkflowUiLoadedForRun(id);
  }, [id]);

  useEffect(() => {
    if (!id || workflowUiLoadedForRun !== id) return;
    saveWorkflowUiState(id, { workflowAutomationMode, activeWorkflowStepId });
  }, [id, workflowUiLoadedForRun, workflowAutomationMode, activeWorkflowStepId]);

  useEffect(() => {
    if (!workflowPlan || !activeWorkflowStepId) return;
    const exists = workflowPlan.steps.some((step) => step.step_id === activeWorkflowStepId);
    if (!exists) {
      setActiveWorkflowStepId(null);
      setNotice("Saved active workflow step no longer exists. Cockpit returned to auto mode.");
    }
  }, [workflowPlan, activeWorkflowStepId]);

  const focusManualAction = async (stepId: string, actionType: string): Promise<ManualFocusResult> => {
    const latestFailedCommand = [...toolCalls]
      .filter((call) => call.step_id === stepId && isFailedRunCommandCall(call))
      .sort((a, b) => toolCallTime(b).localeCompare(toolCallTime(a)))[0];
    const latestRollbackCall = [...toolCalls]
      .filter((call) => call.step_id === stepId && isRollbackCapableApplyPatchCall(call))
      .sort((a, b) => toolCallTime(b).localeCompare(toolCallTime(a)))[0];

    const target: {
      tab: "timeline";
      anchor: string;
      message: string;
      toolCallId?: string;
      toolName?: string;
      status?: string;
      visibleLimit?: number;
    } =
      actionType === "run_tests_manual" || actionType === "run_tests" || actionType === "run_command"
        ? {
            tab: "timeline" as const,
            anchor: "guided-fix",
            message: "Run tests manually from the Guided Fix Workflow. No command was started by this launcher.",
          }
      : actionType === "analyze_result"
        ? latestFailedCommand
          ? {
              tab: "timeline" as const,
              anchor: "tool-call",
              toolCallId: latestFailedCommand.id,
              toolName: "run-command",
              status: "needs_attention",
              visibleLimit: 50,
              message: "Open this failed run-command and click Analyze manually. No analysis was started by this launcher.",
            }
          : {
            tab: "timeline" as const,
            anchor: "tool-calls",
            toolName: "run-command",
            status: "needs_attention",
            visibleLimit: 50,
            message: "No failed run-command found in loaded Tool Calls. Load more or run tests first.",
          }
      : actionType === "rollback_manual" || actionType === "rollback_patch"
        ? latestRollbackCall
          ? {
              tab: "timeline" as const,
              anchor: "tool-call",
              toolCallId: latestRollbackCall.id,
              toolName: "apply-patch",
              visibleLimit: 50,
              message: "Use rollback controls on this apply-patch call. Rollback requires manual confirm=true.",
            }
          : {
            tab: "timeline" as const,
            anchor: "tool-calls",
            toolName: "apply-patch",
            visibleLimit: 50,
            message: "No rollback-capable apply-patch call found for this step.",
          }
      : actionType === "review_patch"
        ? {
            tab: "timeline" as const,
            anchor: "step-patch",
            message: "Review Patch needs file_path, old_text, and new_text. Create Patch Draft from Context first or fill the form manually, then click Review Patch.",
          }
      : actionType === "apply_patch_manual" || actionType === "apply_patch"
        ? {
            tab: "timeline" as const,
            anchor: "step-patch",
            message: "Apply requires the manual confirmation checkbox and confirm=true. No patch was applied.",
          }
      : {
          tab: "timeline" as const,
          anchor: "step-patch",
          message: "Review or edit the patch fields, then create the proposal manually. No proposal was created.",
        };

    setTab(target.tab);
    if (target.anchor === "tool-call" || target.anchor === "tool-calls") {
      setToolCallFocus({
        nonce: Date.now(),
        stepId,
        toolName: target.toolName,
        status: target.status,
        toolCallId: target.toolCallId,
        visibleLimit: target.visibleLimit ?? 50,
        message: target.message,
      });
    }
    await new Promise((resolve) => window.setTimeout(resolve, 80));
    window.dispatchEvent(
      new CustomEvent("aiw-focus-manual-action", {
        detail: { stepId, actionType, anchor: target.anchor },
      })
    );
    await new Promise((resolve) => window.setTimeout(resolve, 120));
    window.dispatchEvent(
      new CustomEvent("aiw-focus-manual-action", {
        detail: { stepId, actionType, anchor: target.anchor },
      })
    );
    await new Promise((resolve) => window.setTimeout(resolve, 120));

    const selector =
      target.anchor === "tool-call" && "toolCallId" in target
        ? `[data-tool-call-id="${target.toolCallId}"][data-action-anchor="tool-call"]`
      : target.anchor === "tool-calls"
        ? `[data-action-anchor="tool-calls"]`
        : `[data-step-id="${stepId}"][data-action-anchor="${target.anchor}"]`;
    let element = document.querySelector(selector) as HTMLElement | null;
    let focusError = "";
    if (!element && target.anchor === "tool-call") {
      element = document.querySelector(`[data-action-anchor="tool-calls"]`) as HTMLElement | null;
      focusError = "The exact tool call is not visible in the latest Tool Calls list. Use Tool Calls to find it manually.";
    }
    if (!element) {
      return {
        message: target.message,
        error:
          target.anchor === "step-patch" || target.anchor === "guided-fix"
            ? "This step has no patch/test UI anchor. Choose a child implementation step or use Tool Calls."
            : "Target UI section was not found. Open Tool Calls and continue manually.",
      };
    }

    element.scrollIntoView({ behavior: "smooth", block: "center" });
    element.animate(
      [
        { boxShadow: "0 0 0 0 rgba(16,185,129,0)", borderColor: "rgb(31,41,55)" },
        { boxShadow: "0 0 0 4px rgba(16,185,129,0.45)", borderColor: "rgb(16,185,129)" },
        { boxShadow: "0 0 0 0 rgba(16,185,129,0)", borderColor: "rgb(31,41,55)" },
      ],
      { duration: 2600, easing: "ease-out" }
    );

    return { message: target.message, error: focusError || undefined };
  };

  useEffect(() => {
    if (!id) return;
    setRunNotFound(false);
    setRun(null);
    Promise.all([getAgentRegistry(), getModelProfiles(), getModelRegistry()])
      .then(([agents, profiles, models]) => {
        setAgentRegistry(agents);
        setModelProfiles(profiles);
        setModelRegistry(models);
      })
      .catch(() => {});
    getRunModelRoutes(id)
      .then((routes) => {
        setModelRoutes(routes);
        setModelRoutesPersisted(true);
      })
      .catch(() => {});
    getRunModelRoutes(id, "steps")
      .then((routes) => {
        const byStep = Object.fromEntries(routes.filter((r) => r.step_id).map((r) => [r.step_id!, r]));
        setStepRoutes(byStep);
      })
      .catch(() => {});

    let lastArtifactCount = -1;
    let runFinished = false;
    let stopPolling = false;
    const load = async () => {
      if (stopPolling) return;
      try {
        const [nextRun, nextSteps, nextTeam] = await Promise.all([getRun(id), getRunSteps(id), getRunAgents(id)]);
        setRunNotFound(false);
        setRun(nextRun);
        setSteps(nextSteps);
        setTeam(nextTeam);
        await refreshToolCalls();
        // Only reload artifacts when the list changes or run just finished
        const isFinished = nextRun.status === "completed" || nextRun.status === "failed" || nextRun.status === "stopped";
        const artifactCountChanged = nextRun.artifacts.length !== lastArtifactCount;
        const justFinished = isFinished && !runFinished;
        if (artifactCountChanged || justFinished) {
          lastArtifactCount = nextRun.artifacts.length;
          setArtifactContent(await loadRunArtifacts(id, nextRun.artifacts));
        }
        if (justFinished) {
          // Refresh step routes once the run finishes — the execution pipeline
          // persists them during _persist_step_route_decisions.
          const sRoutes = await getRunModelRoutes(id, "steps").catch(() => []);
          setStepRoutes(Object.fromEntries(sRoutes.filter((r) => r.step_id).map((r) => [r.step_id!, r])));
        }
        runFinished = isFinished;
      } catch (e: any) {
        if (isNotFoundError(e)) {
          stopPolling = true;
          setRunNotFound(true);
          setRun(null);
          setSteps([]);
          setTeam([]);
          setToolCalls([]);
          setArtifactContent({});
          return;
        }
        // Polling is best-effort for transient errors; the next interval can recover.
      }
    };
    load();
    const interval = setInterval(load, 2000);
    return () => clearInterval(interval);
  }, [id]);

  if (runNotFound) return <RunNotFound runId={id || ""} />;
  if (!run) return <p className="text-gray-500">Loading...</p>;

  const handleStop = async () => {
    if (id) {
      await stopRun(id);
      const [nextRun, nextSteps, nextTeam] = await Promise.all([getRun(id), getRunSteps(id), getRunAgents(id)]);
      setRun(nextRun);
      setSteps(nextSteps);
      setTeam(nextTeam);
      await refreshToolCalls();
      const routes = await getRunModelRoutes(id).catch(() => []);
      setModelRoutes(routes);
      setModelRoutesPersisted(true);
      const sRoutes = await getRunModelRoutes(id, "steps").catch(() => []);
      setStepRoutes(Object.fromEntries(sRoutes.filter((r) => r.step_id).map((r) => [r.step_id!, r])));
      setArtifactContent(await loadRunArtifacts(id, nextRun.artifacts));
    }
  };

  const handleSubmitAnswers = async () => {
    if (!id || !answers.trim()) return;
    setSavingAnswers(true);
    setNotice("");
    try {
      const result = await submitClarifications(id, answers);
      setArtifactContent((current) => ({ ...current, [result.artifact]: result.content }));
      const [nextRun, nextSteps, nextTeam] = await Promise.all([getRun(id), getRunSteps(id), getRunAgents(id)]);
      setRun(nextRun);
      setSteps(nextSteps);
      setTeam(nextTeam);
      setNotice("Clarification answers saved.");
      setAnswers("");
    } catch (e: any) {
      setNotice(e.message);
    } finally {
      setSavingAnswers(false);
    }
  };

  const handleRegeneratePlan = async () => {
    if (!id) return;
    setRegeneratingPlan(true);
    setNotice("");
    try {
      const result = await regeneratePlan(id);
      const [nextRun, nextSteps, nextTeam] = await Promise.all([getRun(id), getRunSteps(id), getRunAgents(id)]);
      setRun(nextRun);
      setSteps(nextSteps);
      setTeam(nextTeam);
      setArtifactContent(await loadRunArtifacts(id, nextRun.artifacts));
      setNotice(result.source);
      setTab("plan");
    } catch (e: any) {
      setNotice(e.message);
    } finally {
      setRegeneratingPlan(false);
    }
  };

  const handleSelectTeam = async () => {
    if (!id) return;
    setSelectingTeam(true);
    setNotice("");
    try {
      const result = await selectRunAgents(id);
      setTeam(result.selected_agents);
      setModelRoutes([]);
      setModelRoutesPersisted(true);
      setNotice(
        `Selected ${result.team_size} agents. Recommended mode: ${result.recommended_execution_mode}.`,
      );
      setTab("team");
    } catch (e: any) {
      setNotice(e.message);
    } finally {
      setSelectingTeam(false);
    }
  };

  const handlePreviewModelRoutes = async () => {
    if (!id) return;
    setRoutingModels(true);
    setNotice("");
    try {
      const result = await previewRunModelRoutes(id);
      setModelRoutes(result.decisions);
      setModelRoutesPersisted(false);
      setNotice(
        result.warnings.length > 0
          ? `Previewed ${result.count} model routes. ${result.warnings[0]}`
          : `Previewed ${result.count} model routes.`,
      );
      setTab("team");
    } catch (e: any) {
      setNotice(e.message);
    } finally {
      setRoutingModels(false);
    }
  };

  const handlePersistModelRoutes = async () => {
    if (!id) return;
    setRoutingModels(true);
    setNotice("");
    try {
      const result = await persistRunModelRoutes(id);
      setModelRoutes(result.decisions);
      setModelRoutesPersisted(true);
      setNotice(
        result.warnings.length > 0
          ? `Persisted ${result.count} model routes. ${result.warnings[0]}`
          : `Persisted ${result.count} model routes.`,
      );
      setTab("team");
    } catch (e: any) {
      setNotice(e.message);
    } finally {
      setRoutingModels(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Run: {run.id}</h2>
        <div className="flex items-center gap-3">
          <StatusBadge status={run.status} />
          {(run.status === "running" || run.status === "pending") && (
            <button
              onClick={handleStop}
              className="px-3 py-1 bg-red-800 hover:bg-red-700 rounded text-sm"
            >
              Stop
            </button>
          )}
        </div>
      </div>

      <div className="bg-gray-900 rounded border border-gray-800 p-4">
        <p className="text-sm text-gray-300">{run.prompt}</p>
        <div className="flex gap-4 mt-2 text-xs text-gray-500">
          <span>Mode: {run.mode}</span>
          <span>Agent: {run.agent_id}</span>
          {run.project_id && (
            <Link to="/projects" className="text-emerald-400 hover:text-emerald-300">
              Project: {run.project_id}
            </Link>
          )}
          {run.current_step_id && <span>Current step: {run.current_step_id}</span>}
          <span>Created: {run.created_at}</span>
          {run.finished_at && <span>Finished: {run.finished_at}</span>}
        </div>
      </div>

      {notice && (
        <div className="rounded border border-blue-800/60 bg-blue-950/30 p-3 text-sm text-blue-100">
          {notice}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-800">
        {(["timeline", "team", "spec", "questions", "plan", "architecture", "tasks", "logs", "result", "tool-plan", "guided", "patch-workflow"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm border-b-2 transition-colors ${
              tab === t
                ? "border-emerald-500 text-emerald-300"
                : "border-transparent text-gray-500 hover:text-gray-300"
            }`}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <div className="bg-gray-900 rounded border border-gray-800 p-4 min-h-[200px]">
        {tab === "timeline" && (
          <Timeline
            run={run}
            steps={steps}
            stepRoutes={stepRoutes}
            toolCalls={toolCalls}
            onToolCallsChanged={refreshToolCalls}
            draftPrefills={draftPrefills}
            onDraftPrefillConsumed={(stepId) =>
              setDraftPrefills((prev) => ({ ...prev, [stepId]: null }))
            }
          />
        )}
        {tab === "team" && (
          <AssignedTeam
            team={team}
            agentRegistry={agentRegistry}
            modelProfiles={modelProfiles}
            modelRegistry={modelRegistry}
            modelRoutes={modelRoutes}
            modelRoutesPersisted={modelRoutesPersisted}
            selecting={selectingTeam}
            routingModels={routingModels}
            onSelectTeam={handleSelectTeam}
            onPreviewModelRoutes={handlePreviewModelRoutes}
            onPersistModelRoutes={handlePersistModelRoutes}
          />
        )}
        {tab === "spec" && (
          <ArtifactViewer
            title="Product Spec"
            content={artifactContent["product-spec.md"]}
            empty="No product spec generated yet..."
          />
        )}
        {tab === "questions" && (
          <ClarificationPanel
            questions={artifactContent["clarification-questions.md"]}
            savedAnswers={artifactContent["clarification-answers.md"]}
            answers={answers}
            saving={savingAnswers}
            regeneratingPlan={regeneratingPlan}
            onAnswersChange={setAnswers}
            onSubmit={handleSubmitAnswers}
            onRegeneratePlan={handleRegeneratePlan}
          />
        )}
        {tab === "plan" && (
          <pre className="text-sm text-gray-300 whitespace-pre-wrap">
            {run.plan || "No plan generated yet..."}
          </pre>
        )}
        {tab === "architecture" && (
          <ArtifactViewer
            title="Architecture"
            content={artifactContent["architecture.md"]}
            empty="No architecture artifact generated yet..."
          />
        )}
        {tab === "tasks" && (
          <ArtifactViewer
            title="Tasks"
            content={artifactContent["tasks.md"]}
            empty="No task breakdown generated yet..."
          />
        )}
        {tab === "logs" && (
          <div className="space-y-1 font-mono text-xs">
            {run.logs.length === 0 ? (
              <p className="text-gray-500">No logs yet...</p>
            ) : (
              run.logs.map((l, i) => (
                <p key={i} className="text-gray-400">{l}</p>
              ))
            )}
          </div>
        )}
        {tab === "result" && (
          <pre className="text-sm text-gray-300 whitespace-pre-wrap">
            {run.result || "No result yet..."}
          </pre>
        )}
        {tab === "tool-plan" && (
          <ToolPlanPanel
            plan={toolPlan}
            loading={toolPlanLoading}
            error={toolPlanError}
            onRefresh={loadToolPlan}
          />
        )}
        {tab === "guided" && (
          <GuidedExecutionPanel
            plan={guidedPlan}
            loading={guidedPlanLoading}
            error={guidedPlanError}
            steps={steps}
            runId={run.id}
            onRefresh={loadGuidedPlan}
            onAutoReadDone={async () => {
              await refreshToolCalls();
              await loadGuidedPlan();
            }}
            contextBundles={contextBundles}
            bundleLoading={bundleLoading}
            onLoadBundle={loadContextBundle}
            onUseDraft={(stepId, candidate) =>
              setDraftPrefills((prev) => ({
                ...prev,
                [stepId]: {
                  file_path: candidate.file_path,
                  old_text: candidate.old_text,
                  new_text: candidate.new_text === "TODO: replace with intended change"
                    ? ""
                    : candidate.new_text,
                  create_if_missing: false,
                  replace_all: false,
                },
              }))
            }
          />
        )}
        {tab === "patch-workflow" && (
          <PatchWorkflowPanel
            runId={run.id}
            steps={steps}
            plan={workflowPlan}
            activeStepId={activeWorkflowStepId}
            loading={workflowPlanLoading}
            error={workflowPlanError}
            workflowMode={workflowAutomationMode}
            onWorkflowModeChange={setWorkflowAutomationMode}
            onRefresh={loadWorkflowPlan}
            onActiveStepChange={setActiveWorkflowStepId}
            onGuidedRefresh={loadGuidedPlan}
            onToolCallsRefresh={refreshToolCalls}
            onFocusManualAction={focusManualAction}
            onUseDraft={(stepId, candidate) =>
              setDraftPrefills((prev) => ({
                ...prev,
                [stepId]: {
                  file_path: candidate.file_path,
                  old_text: candidate.old_text,
                  new_text: candidate.new_text === "TODO: replace with intended change"
                    ? ""
                    : candidate.new_text,
                  create_if_missing: false,
                  replace_all: false,
                },
              }))
            }
          />
        )}
      </div>

      <ToolCallsPanel calls={toolCalls} error={toolCallsError} focus={toolCallFocus} />

      {run.artifacts.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-gray-400 mb-2">Artifacts</h3>
          <div className="flex flex-wrap gap-2">
            {run.artifacts.map((a, i) => (
              <span key={i} className="px-2 py-1 bg-gray-800 rounded text-xs text-gray-300">
                {a}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

async function loadRunArtifacts(runId: string, artifacts: string[]) {
  const visibleArtifacts = [
    "product-spec.md",
    "clarification-questions.md",
    "clarification-answers.md",
    "architecture.md",
    "tasks.md",
  ];
  const available = visibleArtifacts.filter((artifact) => artifacts.includes(artifact));
  const entries = await Promise.all(
    available.map(async (artifact) => {
      try {
        const loaded = await getRunArtifact(runId, artifact);
        return [artifact, loaded.content] as const;
      } catch {
        return [artifact, ""] as const;
      }
    }),
  );
  return Object.fromEntries(entries);
}

function RunNotFound({ runId }: { runId: string }) {
  return (
    <div className="max-w-2xl rounded border border-yellow-900 bg-yellow-950/20 p-5">
      <h2 className="text-xl font-semibold text-yellow-100">Run not found</h2>
      <p className="mt-2 text-sm text-yellow-200">
        This run does not exist anymore, or the local database was reset while the page was open.
      </p>
      {runId && <p className="mt-3 font-mono text-xs text-yellow-300">Run ID: {runId}</p>}
      <div className="mt-5 flex flex-wrap gap-3">
        <Link to="/runs" className="rounded bg-gray-800 px-4 py-2 text-sm hover:bg-gray-700">
          Back to Runs
        </Link>
        <Link to="/new-task" className="rounded bg-emerald-700 px-4 py-2 text-sm hover:bg-emerald-600">
          Create New Task
        </Link>
        <Link to="/projects" className="rounded bg-gray-800 px-4 py-2 text-sm hover:bg-gray-700">
          Open Projects
        </Link>
      </div>
    </div>
  );
}

function ToolCallsPanel({ calls, error, focus }: { calls: ToolCall[]; error: string; focus: ToolCallFocus | null }) {
  const [visibleLimit, setVisibleLimit] = useState(25);
  const [toolNameFilter, setToolNameFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [stepFilter, setStepFilter] = useState("all");
  const [focusMessage, setFocusMessage] = useState("");

  useEffect(() => {
    if (!focus) return;
    if (focus.visibleLimit) setVisibleLimit((current) => Math.max(current, focus.visibleLimit!));
    setToolNameFilter(focus.toolName || "all");
    setStatusFilter(focus.status || "all");
    setStepFilter(focus.stepId || "all");
    setFocusMessage(focus.message || "");
  }, [focus]);

  const sorted = [...calls]
    .sort((a, b) => toolCallTime(b).localeCompare(toolCallTime(a)))
  const toolNames = Array.from(new Set(sorted.map((call) => call.tool_name).filter(Boolean)));
  const stepIds = Array.from(new Set(sorted.map((call) => call.step_id).filter(Boolean)));
  const filtered = sorted.filter((call) => {
    if (toolNameFilter === "read-search-context") {
      if (!isReadSearchContextTool(call.tool_name)) return false;
    } else if (toolNameFilter !== "all" && call.tool_name !== toolNameFilter) {
      return false;
    }
    if (stepFilter !== "all" && call.step_id !== stepFilter) return false;
    if (statusFilter !== "all") {
      if (statusFilter === "needs_attention") {
        return isFailedRunCommandCall(call);
      }
      if (statusFilter === "timed_out") {
        return isTimedOutToolCall(call);
      }
      if ((call.status || "unknown") !== statusFilter) return false;
    }
    return true;
  });
  const recent = filtered.slice(0, visibleLimit);
  const hasMore = filtered.length > recent.length;

  const clearFilters = () => {
    setToolNameFilter("all");
    setStatusFilter("all");
    setStepFilter("all");
    setFocusMessage("");
  };

  return (
    <section data-action-anchor="tool-calls" className="rounded border border-gray-800 bg-gray-900 p-4">
      <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="font-semibold text-gray-200">Tool Calls</h3>
          <p className="mt-1 text-xs text-gray-500">
            {calls.length} logged calls for this run. Showing {recent.length} of {filtered.length} matching calls.
          </p>
        </div>
        <span className="rounded bg-gray-800 px-2 py-1 text-xs text-gray-400">
          read-only journal
        </span>
      </div>

      {focusMessage && (
        <div className="mb-3 rounded border border-emerald-800 bg-emerald-950/20 p-3 text-xs text-emerald-200">
          {focusMessage}
        </div>
      )}

      {error && (
        <div className="mb-3 rounded border border-yellow-800 bg-yellow-950/20 p-3 text-sm text-yellow-200">
          {error}
        </div>
      )}

      <div className="mb-4 space-y-3 rounded border border-gray-800 bg-gray-950 p-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-gray-500">Tool</span>
          <FilterChip active={toolNameFilter === "all"} onClick={() => setToolNameFilter("all")}>all</FilterChip>
          {["run-command", "apply-patch", "propose-patch", "rollback-patch", "analyze-command-result"].map((name) => (
            <FilterChip key={name} active={toolNameFilter === name} onClick={() => setToolNameFilter(name)}>
              {name}
            </FilterChip>
          ))}
          <FilterChip
            active={toolNameFilter === "read-search-context"}
            onClick={() => setToolNameFilter("read-search-context")}
          >
            read/search/context
          </FilterChip>
          {toolNames
            .filter((name) => !["run-command", "apply-patch", "propose-patch", "rollback-patch", "analyze-command-result"].includes(name))
            .slice(0, 6)
            .map((name) => (
              <FilterChip key={name} active={toolNameFilter === name} onClick={() => setToolNameFilter(name)}>
                {name}
              </FilterChip>
            ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-gray-500">Status</span>
          {["all", "completed", "failed", "pending", "timed_out", "needs_attention"].map((status) => (
            <FilterChip key={status} active={statusFilter === status} onClick={() => setStatusFilter(status)}>
              {status === "needs_attention" ? "failed command" : status}
            </FilterChip>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-gray-500">Step</span>
          <FilterChip active={stepFilter === "all"} onClick={() => setStepFilter("all")}>all</FilterChip>
          {stepIds.slice(0, 8).map((stepId) => (
            <FilterChip key={stepId} active={stepFilter === stepId} onClick={() => setStepFilter(stepId)}>
              {truncate(stepId, 14)}
            </FilterChip>
          ))}
          {(toolNameFilter !== "all" || statusFilter !== "all" || stepFilter !== "all" || focusMessage) && (
            <button onClick={clearFilters} className="ml-auto text-xs text-gray-500 hover:text-gray-300">
              clear filters
            </button>
          )}
        </div>
      </div>

      {recent.length === 0 ? (
        <p className="text-sm text-gray-500">No tool calls match the current filters.</p>
      ) : (
        <div className="divide-y divide-gray-800">
          {recent.map((call) => (
            <ToolCallRow key={call.id} call={call} />
          ))}
        </div>
      )}
      <div className="mt-3 flex flex-wrap gap-2">
        {hasMore && (
          <button
            onClick={() => setVisibleLimit((current) => current + 25)}
            className="rounded bg-gray-800 px-3 py-1.5 text-xs text-gray-200 hover:bg-gray-700"
          >
            Show more tool calls
          </button>
        )}
        <button
          onClick={() => setVisibleLimit(25)}
          className="rounded bg-gray-800 px-3 py-1.5 text-xs text-gray-400 hover:bg-gray-700"
        >
          Show latest 25
        </button>
        <button
          onClick={() => setVisibleLimit(50)}
          className="rounded bg-gray-800 px-3 py-1.5 text-xs text-gray-400 hover:bg-gray-700"
        >
          Show latest 50
        </button>
      </div>
    </section>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded px-2 py-1 text-xs ${
        active
          ? "bg-emerald-800 text-emerald-100"
          : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"
      }`}
    >
      {children}
    </button>
  );
}

function ToolCallRow({ call }: { call: ToolCall }) {
  const audit = patchAuditDetails(call);
  const isRunCommand = call.tool_name === "run-command";
  const isApplyPatch = call.tool_name === "apply-patch";
  const needsAnalysis = isFailedRunCommandCall(call);
  const [analysisRunning, setAnalysisRunning] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<CommandAnalysisResponse | null>(null);
  const [analysisError, setAnalysisError] = useState("");

  // Rollback state (apply-patch calls only)
  const hasRollbackData = isRollbackCapableApplyPatchCall(call);
  const [rollbackConfirmed, setRollbackConfirmed] = useState(false);
  const [rollbackRunning, setRollbackRunning] = useState(false);
  const [rollbackResult, setRollbackResult] = useState<RollbackPatchResponse | null>(null);
  const [rollbackError, setRollbackError] = useState("");

  const handleRollback = async () => {
    if (!call.project_id || !rollbackConfirmed) return;
    setRollbackRunning(true);
    setRollbackError("");
    try {
      const result = await rollbackProjectPatch(call.project_id, {
        tool_call_id: call.id,
        confirm: true,
        run_id: call.run_id,
        step_id: call.step_id,
      });
      setRollbackResult(result);
    } catch (e: any) {
      setRollbackError(e.message || "Rollback failed");
    } finally {
      setRollbackRunning(false);
    }
  };

  const handleAnalyze = async () => {
    if (!call.project_id) return;
    setAnalysisRunning(true);
    setAnalysisError("");
    try {
      const result = await analyzeCommandResult(call.project_id, {
        tool_call_id: call.id,
        run_id: call.run_id,
        step_id: call.step_id,
      });
      setAnalysisResult(result);
    } catch (e: any) {
      setAnalysisError(e.message || "Analysis failed");
    } finally {
      setAnalysisRunning(false);
    }
  };

  return (
    <article
      data-action-anchor="tool-call"
      data-tool-call-id={call.id}
      data-tool-name={call.tool_name}
      data-step-id={call.step_id || ""}
      data-rollback-capable={hasRollbackData ? "true" : "false"}
      data-command-failed={isFailedRunCommandCall(call) ? "true" : "false"}
      className="py-3 space-y-2"
    >
      <div className="grid gap-3 xl:grid-cols-[180px_1fr_180px]">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge status={call.status || "unknown"} />
                  <span className="rounded bg-gray-800 px-2 py-0.5 text-xs text-gray-400">
                    {call.risk_level || "low"}
                  </span>
                  {needsAnalysis && (
                    <span className="rounded bg-red-900/50 px-2 py-0.5 text-xs text-red-300">
                      Failed command
                    </span>
                  )}
                  {hasRollbackData && (
                    <span className="rounded bg-orange-900/50 px-2 py-0.5 text-xs text-orange-300">
                      Rollback available
                    </span>
                  )}
                </div>
                <p className="font-mono text-xs text-gray-300">{call.tool_name}</p>
              </div>

              <div className="min-w-0 space-y-2">
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                  {call.project_id && <span>project: {call.project_id}</span>}
                  {call.step_id && <span>step: {call.step_id}</span>}
                  {audit.agentId && <span>agent: {audit.agentId}</span>}
                  {call.returncode !== null && <span>exit: {call.returncode}</span>}
                </div>
                {(audit.proposalId || audit.appliedFromProposalId) && (
                  <div className="flex flex-wrap gap-2 text-xs">
                    {audit.proposalId && (
                      <span className="rounded bg-gray-800 px-2 py-0.5 text-gray-300">
                        proposal: {audit.proposalId}
                      </span>
                    )}
                    {audit.appliedFromProposalId && (
                      <span className="rounded bg-gray-800 px-2 py-0.5 text-gray-300">
                        applied from: {audit.appliedFromProposalId}
                      </span>
                    )}
                  </div>
                )}
                {call.error ? (
                  <p className="rounded bg-red-950/30 px-2 py-1 text-xs text-red-300">
                    {truncate(call.error, 260)}
                  </p>
                ) : (
                  <p className="text-xs text-gray-400">{summarizeToolOutput(call)}</p>
                )}
                {needsAnalysis && !analysisResult && (
                  <button
                    onClick={handleAnalyze}
                    disabled={analysisRunning}
                    className="rounded bg-gray-800 px-3 py-1 text-xs text-gray-300 hover:bg-gray-700 disabled:text-gray-500"
                  >
                    {analysisRunning ? "Analyzing..." : "Analyze command result"}
                  </button>
                )}
                {analysisError && (
                  <p className="text-xs text-red-400">{analysisError}</p>
                )}
              </div>

              <div className="text-xs text-gray-500 xl:text-right">
                <p>{call.completed_at || call.finished_at || call.created_at || "unknown time"}</p>
                {call.report_path && <p className="mt-1 truncate">{call.report_path}</p>}
              </div>
      </div>
      {analysisResult && (
        <ToolCallAnalysisPanel result={analysisResult} onDismiss={() => setAnalysisResult(null)} />
      )}
      {isApplyPatch && !rollbackResult && (
        <div className="ml-4 rounded border border-gray-800 bg-gray-950 p-2 space-y-1.5">
          <p className="text-xs font-medium text-gray-400">Rollback this patch</p>
          {!hasRollbackData ? (
            <p className="text-xs text-gray-600">No rollback metadata — only patches applied after rollback support was introduced can be reverted.</p>
          ) : (
            <>
              <label className="flex items-start gap-2 text-xs text-gray-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rollbackConfirmed}
                  onChange={(e) => setRollbackConfirmed(e.target.checked)}
                  className="mt-0.5 h-3 w-3 flex-shrink-0"
                />
                I understand this will modify files by reverting a previous patch
              </label>
              <button
                onClick={handleRollback}
                disabled={!rollbackConfirmed || rollbackRunning}
                className="rounded bg-orange-800 px-3 py-1 text-xs text-orange-100 hover:bg-orange-700 disabled:bg-gray-800 disabled:text-gray-500"
              >
                {rollbackRunning ? "Rolling back…" : "Rollback"}
              </button>
              {rollbackError && <p className="text-xs text-red-400">{rollbackError}</p>}
            </>
          )}
        </div>
      )}
      {rollbackResult && (
        <RollbackResultPanel result={rollbackResult} onDismiss={() => setRollbackResult(null)} />
      )}
    </article>
  );
}

function RollbackResultPanel({ result, onDismiss }: { result: RollbackPatchResponse; onDismiss: () => void }) {
  return (
    <div className="ml-4 rounded border border-orange-800 bg-orange-950/20 p-3 space-y-2">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-orange-300">Rollback complete</p>
        <button onClick={onDismiss} className="text-xs text-gray-500 hover:text-gray-300">dismiss</button>
      </div>
      {result.rolled_back_files.length > 0 && (
        <div className="space-y-0.5">
          <p className="text-xs text-gray-500">Rolled back:</p>
          {result.rolled_back_files.map((f, i) => (
            <p key={i} className="text-xs text-gray-300 font-mono">
              <span className="rounded bg-emerald-900 px-1 py-0.5 text-emerald-300 mr-1">
                {f.status}
              </span>
              {f.path}
            </p>
          ))}
        </div>
      )}
      {result.skipped_files.length > 0 && (
        <div className="space-y-0.5">
          <p className="text-xs text-gray-500">Skipped:</p>
          {result.skipped_files.map((f, i) => (
            <p key={i} className="text-xs text-gray-400 font-mono">
              <span className="rounded bg-yellow-900 px-1 py-0.5 text-yellow-300 mr-1">
                {f.status}
              </span>
              {f.path}
              {f.reason && <span className="text-gray-500 ml-1">— {f.reason}</span>}
            </p>
          ))}
        </div>
      )}
      {result.warnings.length > 0 && (
        <div className="space-y-0.5">
          {result.warnings.map((w, i) => (
            <p key={i} className="text-xs text-yellow-400">⚠ {w}</p>
          ))}
        </div>
      )}
      {result.git_status && (
        <pre className="text-xs text-gray-500 font-mono">{result.git_status}</pre>
      )}
    </div>
  );
}

function ToolCallAnalysisPanel({ result, onDismiss }: { result: CommandAnalysisResponse; onDismiss: () => void }) {
  const statusColor =
    result.status === "passed"
      ? "text-emerald-400"
      : result.status === "timed_out"
      ? "text-yellow-400"
      : "text-red-400";

  return (
    <div className="ml-4 rounded border border-gray-700 bg-gray-900 p-3 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className={`font-semibold text-xs ${statusColor}`}>{result.status.toUpperCase()}</span>
          {result.can_create_fix_proposal && (
            <span className="rounded bg-blue-900 px-2 py-0.5 text-xs text-blue-300">fix proposal possible</span>
          )}
        </div>
        <button onClick={onDismiss} className="text-xs text-gray-500 hover:text-gray-300">dismiss</button>
      </div>
      <p className="text-xs text-gray-300">{result.summary}</p>
      {result.issues.length > 0 && (
        <div className="space-y-1">
          {result.issues.map((issue, i) => (
            <div key={i} className="rounded bg-gray-800 px-2 py-1 text-xs">
              <span className="rounded bg-gray-700 px-1 py-0.5 text-gray-400 mr-2">{issue.kind}</span>
              {issue.file_path && (
                <span className="text-gray-500 mr-1">
                  {issue.file_path}{issue.line != null ? `:${issue.line}` : ""}
                </span>
              )}
              <span className="text-gray-300">{issue.message}</span>
            </div>
          ))}
        </div>
      )}
      {result.suggested_next_actions.length > 0 && (
        <div className="space-y-0.5">
          <p className="text-xs text-gray-500 font-medium">Suggested actions:</p>
          {result.suggested_next_actions.map((action, i) => (
            <p key={i} className="text-xs text-gray-400">• {action}</p>
          ))}
        </div>
      )}
    </div>
  );
}

function AssignedTeam({
  team,
  agentRegistry,
  modelProfiles,
  modelRegistry,
  modelRoutes,
  modelRoutesPersisted,
  selecting,
  routingModels,
  onSelectTeam,
  onPreviewModelRoutes,
  onPersistModelRoutes,
}: {
  team: RunAgentAssignment[];
  agentRegistry: AgentInfo[];
  modelProfiles: ModelProfile[];
  modelRegistry: ModelRegistryItem[];
  modelRoutes: ModelRouteDecision[];
  modelRoutesPersisted: boolean;
  selecting: boolean;
  routingModels: boolean;
  onSelectTeam: () => void;
  onPreviewModelRoutes: () => void;
  onPersistModelRoutes: () => void;
}) {
  const agentById = Object.fromEntries(agentRegistry.map((agent) => [agent.id, agent]));
  const profileById = Object.fromEntries(modelProfiles.map((profile) => [profile.id, profile]));
  const modelById = Object.fromEntries(modelRegistry.map((model) => [model.id, model]));
  const routeByAgent = Object.fromEntries(modelRoutes.map((route) => [route.agent_id, route]));

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="font-semibold text-gray-200">Assigned Team</h3>
          <p className="mt-1 text-xs text-gray-500">
            These agents are selected for this run only. Selection does not grant file-editing powers by itself.
          </p>
        </div>
        <button
          onClick={onSelectTeam}
          disabled={selecting}
          className="rounded bg-gray-800 px-4 py-2 text-sm hover:bg-gray-700 disabled:text-gray-500"
        >
          {selecting ? "Selecting..." : "Re-select Team"}
        </button>
      </div>

      <div className="mb-4 rounded border border-gray-800 bg-gray-950 p-3">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h4 className="text-sm font-medium text-gray-200">Model Routing Status</h4>
            <p className="mt-1 text-xs text-gray-500">
              {modelRoutes.length} route decisions {modelRoutesPersisted ? "saved for this run" : "previewed, not saved"}.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={onPreviewModelRoutes}
              disabled={routingModels}
              className="rounded bg-gray-800 px-3 py-2 text-sm hover:bg-gray-700 disabled:text-gray-500"
            >
              {routingModels ? "Routing..." : "Preview model routes"}
            </button>
            <button
              onClick={onPersistModelRoutes}
              disabled={routingModels}
              className="rounded bg-emerald-700 px-3 py-2 text-sm hover:bg-emerald-600 disabled:bg-gray-700 disabled:text-gray-500"
            >
              {routingModels ? "Routing..." : "Persist model routes"}
            </button>
          </div>
        </div>
      </div>

      {team.length === 0 ? (
        <div className="rounded border border-yellow-900 bg-yellow-950/20 p-3 text-sm text-yellow-300">
          No agents have been assigned yet.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
          {team.map((agent) => (
            <AssignedAgentCard
              key={agent.id}
              assignment={agent}
              agent={agentById[agent.agent_id]}
              profile={agentById[agent.agent_id] ? profileById[agentById[agent.agent_id].model_profile] : undefined}
              route={routeByAgent[agent.agent_id]}
              model={
                routeByAgent[agent.agent_id]
                  ? modelById[routeByAgent[agent.agent_id].selected_model]
                  : agentById[agent.agent_id] && profileById[agentById[agent.agent_id].model_profile]
                  ? modelById[profileById[agentById[agent.agent_id].model_profile].primary_model]
                  : undefined
              }
            />
          ))}
        </div>
      )}
    </div>
  );
}

function AssignedAgentCard({
  assignment,
  agent,
  profile,
  route,
  model,
}: {
  assignment: RunAgentAssignment;
  agent?: AgentInfo;
  profile?: ModelProfile;
  route?: ModelRouteDecision;
  model?: ModelRegistryItem;
}) {
  const selectedModel = route?.selected_model || profile?.primary_model || "unknown";
  const selectedProvider = route?.selected_provider || profile?.preferred_provider || "unknown";
  return (
    <article className="rounded border border-gray-800 bg-gray-950 p-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h4 className="font-mono text-sm text-gray-200">{assignment.agent_id}</h4>
          <p className="mt-1 text-xs text-gray-500">Role: {assignment.assigned_role || "specialist"}</p>
        </div>
        <span className="rounded bg-emerald-900/40 px-2 py-1 text-xs text-emerald-300">
          {Math.round(assignment.confidence * 100)}%
        </span>
      </div>
      <p className="mt-3 text-sm text-gray-400">{assignment.reason}</p>
      <div className="mt-3 grid grid-cols-1 gap-2 text-xs text-gray-500 sm:grid-cols-2">
        <TeamInfo label="task type" value={route?.task_type || "not routed"} />
        <TeamInfo label="model profile" value={route?.model_profile || agent?.model_profile || "unknown"} />
        <TeamInfo label="selected model" value={selectedModel} />
        <TeamInfo label="provider" value={selectedProvider} />
        <TeamInfo label="fallback" value={route?.fallback_model || profile?.fallback_model || "unknown"} />
        <TeamInfo label="status" value={assignment.status} />
      </div>
      {route?.reason && <p className="mt-2 text-xs text-gray-500">{route.reason}</p>}
      {route?.warnings?.length ? (
        <p className="mt-2 text-xs text-yellow-300">{route.warnings.join(" ")}</p>
      ) : null}
      {model && (
        <p className={`mt-2 text-xs ${model.installed ? "text-emerald-300" : "text-yellow-300"}`}>
          {model.installed ? "Model installed locally" : `Model not installed locally: ollama pull ${model.id}`}
        </p>
      )}
    </article>
  );
}

function TeamInfo({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 rounded bg-gray-900 px-2 py-1.5">
      <span className="text-gray-600">{label}</span>
      <p className="truncate text-gray-300">{value}</p>
    </div>
  );
}

function ArtifactViewer({ title, content, empty }: { title: string; content?: string; empty: string }) {
  return (
    <div>
      <h3 className="mb-3 font-semibold text-gray-200">{title}</h3>
      {content ? (
        <pre className="max-h-[560px] overflow-auto whitespace-pre-wrap rounded bg-gray-950 p-3 text-sm text-gray-300">
          {content}
        </pre>
      ) : (
        <p className="text-sm text-gray-500">{empty}</p>
      )}
    </div>
  );
}

function ClarificationPanel({
  questions,
  savedAnswers,
  answers,
  saving,
  regeneratingPlan,
  onAnswersChange,
  onSubmit,
  onRegeneratePlan,
}: {
  questions?: string;
  savedAnswers?: string;
  answers: string;
  saving: boolean;
  regeneratingPlan: boolean;
  onAnswersChange: (value: string) => void;
  onSubmit: () => void;
  onRegeneratePlan: () => void;
}) {
  return (
    <div className="space-y-4">
      <ArtifactViewer
        title="Clarification Questions"
        content={questions}
        empty="No clarification questions generated yet..."
      />
      {savedAnswers && (
        <ArtifactViewer title="Saved Answers" content={savedAnswers} empty="" />
      )}
      {savedAnswers && (
        <button
          onClick={onRegeneratePlan}
          disabled={regeneratingPlan}
          className="rounded bg-blue-700 px-4 py-2 text-sm hover:bg-blue-600 disabled:bg-gray-700 disabled:text-gray-500"
        >
          {regeneratingPlan ? "Regenerating..." : "Regenerate Plan From Answers"}
        </button>
      )}
      <div>
        <h3 className="mb-2 font-semibold text-gray-200">Answer Questions</h3>
        <textarea
          value={answers}
          onChange={(event) => onAnswersChange(event.target.value)}
          rows={8}
          className="w-full rounded border border-gray-700 bg-gray-950 px-3 py-2 text-sm text-gray-200 focus:border-emerald-500 focus:outline-none"
          placeholder="Write answers, constraints, decisions, and product preferences here..."
        />
        <button
          onClick={onSubmit}
          disabled={saving || !answers.trim()}
          className="mt-3 rounded bg-emerald-600 px-4 py-2 text-sm hover:bg-emerald-500 disabled:bg-gray-700 disabled:text-gray-500"
        >
          {saving ? "Saving..." : "Save Answers"}
        </button>
      </div>
    </div>
  );
}

function Timeline({
  run,
  steps,
  stepRoutes,
  toolCalls,
  onToolCallsChanged,
  draftPrefills,
  onDraftPrefillConsumed,
}: {
  run: Run;
  steps: RunStep[];
  stepRoutes: Record<string, ModelRouteDecision>;
  toolCalls: ToolCall[];
  onToolCallsChanged: () => Promise<void>;
  draftPrefills?: Record<string, PatchFormState | null>;
  onDraftPrefillConsumed?: (stepId: string) => void;
}) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  if (steps.length === 0) {
    return <p className="text-sm text-gray-500">No steps recorded yet...</p>;
  }

  const toggle = (id: string) =>
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));

  const orchestratorSteps = steps.filter((s) => !s.parent_step_id);
  const childSteps = steps.filter((s) => s.parent_step_id);
  const callsByStep = groupPatchCallsByStep(toolCalls);

  useEffect(() => {
    const handleFocus = (event: Event) => {
      const detail = (event as CustomEvent<{ stepId?: string }>).detail;
      if (!detail?.stepId) return;
      const step = steps.find((s) => s.id === detail.stepId);
      if (step?.parent_step_id) {
        setExpanded((prev) => ({ ...prev, [step.parent_step_id]: true }));
      }
    };

    window.addEventListener("aiw-focus-manual-action", handleFocus);
    return () => window.removeEventListener("aiw-focus-manual-action", handleFocus);
  }, [steps]);

  return (
    <div className="space-y-3">
      {orchestratorSteps.map((step) => {
        const isOpen = expanded[step.id] ?? false;
        const children = childSteps.filter((c) => c.parent_step_id === step.id);
        return (
          <div key={step.id}>
            <div className="grid gap-3 rounded border border-gray-800 bg-gray-950 p-3 lg:grid-cols-[180px_1fr]">
              <div className="space-y-2">
                <StatusBadge status={step.status} />
                <p className="text-xs text-gray-500">{step.agent_id || "orchestrator"}</p>
                {children.length > 0 && (
                  <button
                    onClick={() => toggle(step.id)}
                    className="text-xs text-emerald-400 hover:text-emerald-300"
                  >
                    {isOpen ? "▾ Hide" : "▸ Show"} {children.length} sub-steps
                  </button>
                )}
              </div>
              <div className="min-w-0">
                <h3 className="font-medium text-gray-200">{step.title}</h3>
                <div className="mt-1 flex flex-wrap gap-3 text-xs text-gray-500">
                  {step.started_at && <span>Started: {step.started_at}</span>}
                  {step.finished_at && <span>Finished: {step.finished_at}</span>}
                </div>
                {step.output && (
                  <ExpandableOutput value={step.output} previewMax={300} />
                )}
                {step.error && (
                  <pre className="mt-3 whitespace-pre-wrap rounded bg-red-950/40 p-3 text-xs text-red-300">
                    {step.error}
                  </pre>
                )}
              </div>
            </div>
            {isOpen && children.length > 0 && (
              <div className="ml-6 mt-1 space-y-2 border-l-2 border-gray-800 pl-4">
                {children.map((child) => (
                  <StepCard
                    key={child.id}
                    run={run}
                    step={child}
                    route={stepRoutes[child.id]}
                    patchCalls={callsByStep[child.id] || []}
                    onToolCallsChanged={onToolCallsChanged}
                    draftPrefill={draftPrefills?.[child.id] ?? null}
                    onDraftPrefillConsumed={() => onDraftPrefillConsumed?.(child.id)}
                  />
                ))}
              </div>
            )}
          </div>
        );
      })}
      {/* Show orphan child steps if parent is missing */}
      {childSteps
        .filter((c) => !orchestratorSteps.some((p) => p.id === c.parent_step_id))
        .map((step) => (
          <StepCard
            key={step.id}
            run={run}
            step={step}
            route={stepRoutes[step.id]}
            patchCalls={callsByStep[step.id] || []}
            onToolCallsChanged={onToolCallsChanged}
            draftPrefill={draftPrefills?.[step.id] ?? null}
            onDraftPrefillConsumed={() => onDraftPrefillConsumed?.(step.id)}
          />
        ))}
    </div>
  );
}

function StepCard({
  run,
  step,
  route,
  patchCalls,
  onToolCallsChanged,
  draftPrefill,
  onDraftPrefillConsumed,
}: {
  run: Run;
  step: RunStep;
  route?: ModelRouteDecision;
  patchCalls: ToolCall[];
  onToolCallsChanged: () => Promise<void>;
  draftPrefill?: PatchFormState | null;
  onDraftPrefillConsumed?: () => void;
}) {
  const [patchPrefill, setPatchPrefill] = useState<IssuePrefill | null>(null);

  return (
    <div className="grid gap-3 rounded border border-gray-800 bg-gray-950 p-3 lg:grid-cols-[160px_1fr]">
      <div className="space-y-1">
        <StatusBadge status={step.status} />
        <p className="text-xs text-gray-500">{step.agent_id || "unassigned"}</p>
        {route && (
          <div className="space-y-0.5">
            <p className="text-xs font-mono text-emerald-400 truncate" title={route.selected_model}>
              {route.selected_model}
            </p>
            <p className="text-xs text-gray-600">{route.selected_provider}</p>
          </div>
        )}
      </div>
      <div className="min-w-0">
        <h4 className="text-sm font-medium text-gray-300">{step.title}</h4>
        {route && (
          <div className="mt-1 flex flex-wrap gap-2 text-xs">
            <span className="rounded bg-gray-800 px-1.5 py-0.5 text-gray-400">
              agent: <span className="text-gray-200">{route.agent_id}</span>
            </span>
            <span className="rounded bg-gray-800 px-1.5 py-0.5 text-gray-400">
              task: <span className="text-gray-200">{route.task_type}</span>
            </span>
            {route.fallback_model && route.fallback_model !== route.selected_model && (
              <span className="rounded bg-gray-800 px-1.5 py-0.5 text-gray-400">
                fallback: <span className="text-gray-200">{route.fallback_model}</span>
              </span>
            )}
            {route.warnings.length > 0 && (
              <span className="rounded bg-yellow-900/50 px-1.5 py-0.5 text-yellow-400">
                {route.warnings.length} warning{route.warnings.length > 1 ? "s" : ""}
              </span>
            )}
          </div>
        )}
        <div className="mt-1 flex flex-wrap gap-3 text-xs text-gray-500">
          {step.started_at && <span>Started: {step.started_at}</span>}
          {step.finished_at && <span>Finished: {step.finished_at}</span>}
        </div>
        {step.input && (
          <ExpandableOutput value={step.input} previewMax={200} muted />
        )}
        {step.output && (
          <ExpandableOutput value={step.output} previewMax={500} />
        )}
        {step.error && (
          <pre className="mt-3 whitespace-pre-wrap rounded bg-red-950/40 p-3 text-xs text-red-300">
            {step.error}
          </pre>
        )}
        {run.project_id && (
          <GuidedFixWorkflow
            run={run}
            step={step}
            agentId={step.agent_id || route?.agent_id || ""}
            onToolCallsChanged={onToolCallsChanged}
            onUsePatchPrefill={setPatchPrefill}
          />
        )}
        <StepPatchSection
          run={run}
          step={step}
          route={route}
          calls={patchCalls}
          onToolCallsChanged={onToolCallsChanged}
          externalPrefill={patchPrefill}
          onPrefillConsumed={() => setPatchPrefill(null)}
          draftPrefill={draftPrefill ?? null}
          onDraftPrefillConsumed={onDraftPrefillConsumed}
        />
      </div>
    </div>
  );
}

// ── Guided Fix Workflow ───────────────────────────────────────────────────────

function GuidedFixWorkflow({
  run,
  step,
  agentId,
  onToolCallsChanged,
  onUsePatchPrefill,
}: {
  run: Run;
  step: RunStep;
  agentId: string;
  onToolCallsChanged: () => Promise<void>;
  onUsePatchPrefill?: (prefill: IssuePrefill) => void;
}) {
  const [open, setOpen] = useState(false);
  const [commandResult, setCommandResult] = useState<RunProjectCommandResponse | null>(null);
  const [analysis, setAnalysis] = useState<CommandAnalysisResponse | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const handleFocus = (event: Event) => {
      const detail = (event as CustomEvent<{ stepId?: string; anchor?: string }>).detail;
      if (detail?.stepId === step.id && detail.anchor === "guided-fix") {
        setOpen(true);
      }
    };

    window.addEventListener("aiw-focus-manual-action", handleFocus);
    return () => window.removeEventListener("aiw-focus-manual-action", handleFocus);
  }, [step.id]);

  const handleRunTests = async () => {
    setIsRunning(true);
    setError("");
    setCommandResult(null);
    setAnalysis(null);
    try {
      const result = await runProjectCommand(run.project_id, {
        command_kind: "test",
        run_id: run.id,
        step_id: step.id,
        agent_id: agentId,
      });
      setCommandResult(result);
      await onToolCallsChanged();
    } catch (e: any) {
      setError(e.message || "Failed to run tests");
    } finally {
      setIsRunning(false);
    }
  };

  const handleAnalyze = async () => {
    if (!commandResult?.tool_call_id) return;
    setIsAnalyzing(true);
    setError("");
    try {
      const result = await analyzeCommandResult(run.project_id, {
        tool_call_id: commandResult.tool_call_id,
        run_id: run.id,
        step_id: step.id,
        agent_id: agentId,
      });
      setAnalysis(result);
      await onToolCallsChanged();
    } catch (e: any) {
      setError(e.message || "Analysis failed");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const failed = commandResult !== null && (commandResult.returncode !== 0 || commandResult.timed_out);
  const passed = commandResult !== null && commandResult.returncode === 0 && !commandResult.timed_out;

  return (
    <div data-step-id={step.id} data-action-anchor="guided-fix" className="mt-3 rounded border border-gray-800 bg-gray-950">
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between px-3 py-2 text-xs text-gray-400 hover:text-gray-200"
      >
        <span className="font-medium">Guided Fix Workflow</span>
        <span>{open ? "▾" : "▸"}</span>
      </button>

      {open && (
        <div className="px-3 pb-3 space-y-3 border-t border-gray-800">
          {/* Step 1 */}
          <div className="space-y-1 pt-2">
            <p className="text-xs text-gray-500 font-medium">Step 1 — Run Tests</p>
            <button
              onClick={handleRunTests}
              disabled={isRunning}
              className="rounded bg-gray-800 px-3 py-1.5 text-xs text-gray-200 hover:bg-gray-700 disabled:text-gray-500"
            >
              {isRunning ? "Running…" : "Run Tests"}
            </button>
            {commandResult && (
              <div
                className={`mt-1 rounded px-2 py-1 text-xs space-y-0.5 ${
                  passed ? "bg-emerald-950/40 text-emerald-300" : "bg-red-950/30 text-red-300"
                }`}
              >
                <p>
                  exit {commandResult.returncode}
                  {commandResult.timed_out && " · timed out"}
                  {" · "}{commandResult.duration_ms}ms
                </p>
                {commandResult.stdout.trim() && (
                  <p className="text-gray-400 font-mono">{truncate(commandResult.stdout.trim(), 160)}</p>
                )}
                {commandResult.stderr.trim() && (
                  <p className="text-gray-500 font-mono">{truncate(commandResult.stderr.trim(), 160)}</p>
                )}
              </div>
            )}
            {passed && (
              <p className="text-xs text-emerald-400">✓ Tests passed — no fix needed.</p>
            )}
          </div>

          {/* Step 2 */}
          {failed && (
            <div className="space-y-1">
              <p className="text-xs text-gray-500 font-medium">Step 2 — Analyze Result</p>
              {!analysis ? (
                <button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing}
                  className="rounded bg-gray-800 px-3 py-1.5 text-xs text-gray-200 hover:bg-gray-700 disabled:text-gray-500"
                >
                  {isAnalyzing ? "Analyzing…" : "Analyze"}
                </button>
              ) : (
                <div className="rounded border border-gray-700 bg-gray-900 p-2 space-y-1.5">
                  <p className="text-xs text-red-400">{analysis.summary}</p>
                  {analysis.issues.length > 0 && (
                    <div className="space-y-1.5">
                      {analysis.issues.slice(0, 5).map((issue, i) => (
                        <div key={i} className="rounded bg-gray-800 px-2 py-1.5 text-xs space-y-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="rounded bg-gray-700 px-1 py-0.5 text-gray-500">{issue.kind}</span>
                            {issue.file_path && (
                              <span className="font-mono text-gray-500">
                                {issue.file_path}{issue.line != null ? `:${issue.line}` : ""}
                              </span>
                            )}
                          </div>
                          <p className="text-gray-400">{issue.message}</p>
                          {issue.file_path && onUsePatchPrefill && (
                            <button
                              onClick={() => onUsePatchPrefill({
                                file_path: issue.file_path!,
                                context_kind: issue.kind,
                                context_location: `${issue.file_path}${issue.line != null ? `:${issue.line}` : ""}`,
                                context_message: issue.message,
                              })}
                              className="rounded bg-blue-900 px-2 py-0.5 text-xs text-blue-300 hover:bg-blue-800"
                            >
                              Use for Patch Proposal ↓
                            </button>
                          )}
                        </div>
                      ))}
                      {analysis.issues.length > 5 && (
                        <p className="text-xs text-gray-600">…and {analysis.issues.length - 5} more</p>
                      )}
                    </div>
                  )}
                  {analysis.suggested_next_actions.length > 0 && (
                    <div className="space-y-0.5 border-t border-gray-800 pt-1">
                      {analysis.suggested_next_actions.map((a, i) => (
                        <p key={i} className="text-xs text-gray-500">• {a}</p>
                      ))}
                    </div>
                  )}
                  {analysis.can_create_fix_proposal && (
                    <p className="text-xs text-blue-400">
                      Fix proposal possible — use the Patch Proposal form below.
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Step 3 hint */}
          {analysis && analysis.can_create_fix_proposal && (
            <div className="space-y-0.5">
              <p className="text-xs text-gray-500 font-medium">Step 3 — Create Patch Proposal</p>
              <p className="text-xs text-gray-600">Open the Patch Proposal section below, fill in file/old/new text, preview and confirm.</p>
            </div>
          )}

          {/* Step 4 hint */}
          {analysis && analysis.can_create_fix_proposal && (
            <div className="space-y-0.5">
              <p className="text-xs text-gray-500 font-medium">Step 4 — Apply Patch</p>
              <p className="text-xs text-gray-600">Check the confirmation box in the patch form and click Apply Patch. Then re-run tests above to verify.</p>
            </div>
          )}

          {error && <p className="text-xs text-red-400">{error}</p>}
        </div>
      )}
    </div>
  );
}

function StepPatchSection({
  run,
  step,
  route,
  calls,
  onToolCallsChanged,
  externalPrefill,
  onPrefillConsumed,
  draftPrefill,
  onDraftPrefillConsumed,
}: {
  run: Run;
  step: RunStep;
  route?: ModelRouteDecision;
  calls: ToolCall[];
  onToolCallsChanged: () => Promise<void>;
  externalPrefill?: IssuePrefill | null;
  onPrefillConsumed?: () => void;
  draftPrefill?: PatchFormState | null;
  onDraftPrefillConsumed?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [localCalls, setLocalCalls] = useState<ToolCall[]>(calls);
  const [form, setForm] = useState<PatchFormState>(emptyPatchForm);
  const [preview, setPreview] = useState<ProposePatchResponse | null>(null);
  const [applyResult, setApplyResult] = useState<ApplyPatchResponse | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [loading, setLoading] = useState<"preview" | "apply" | "review" | "">("");
  const [error, setError] = useState("");
  const [issueContext, setIssueContext] = useState<IssuePrefill | null>(null);
  const [reviewResult, setReviewResult] = useState<PatchReviewResponse | null>(null);
  const agentId = step.agent_id || route?.agent_id || "";

  useEffect(() => {
    const handleFocus = (event: Event) => {
      const detail = (event as CustomEvent<{ stepId?: string; anchor?: string }>).detail;
      if (detail?.stepId === step.id && detail.anchor === "step-patch") {
        setOpen(true);
      }
    };

    window.addEventListener("aiw-focus-manual-action", handleFocus);
    return () => window.removeEventListener("aiw-focus-manual-action", handleFocus);
  }, [step.id]);

  useEffect(() => {
    setLocalCalls(calls);
  }, [calls]);

  // When a prefill arrives from GuidedFixWorkflow, open the form and pre-fill file_path.
  useEffect(() => {
    if (!externalPrefill) return;
    setForm((prev) => ({ ...prev, file_path: externalPrefill.file_path, old_text: "", new_text: "" }));
    setIssueContext(externalPrefill);
    setOpen(true);
    setPreview(null);
    setApplyResult(null);
    setConfirmed(false);
    setError("");
    onPrefillConsumed?.();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalPrefill]);

  // When a draft candidate prefill arrives from Context Patch Draft, open form with full data.
  useEffect(() => {
    if (!draftPrefill) return;
    setForm(draftPrefill);
    setOpen(true);
    setPreview(null);
    setApplyResult(null);
    setConfirmed(false);
    setError("");
    onDraftPrefillConsumed?.();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draftPrefill]);

  const refreshStepCalls = async () => {
    const next = await getStepToolCalls(run.id, step.id).catch(() => null);
    if (next) setLocalCalls(next.filter(isPatchCall));
    await onToolCallsChanged();
  };

  const update = <K extends keyof PatchFormState>(key: K, value: PatchFormState[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
    setPreview(null);
    setApplyResult(null);
    setReviewResult(null);
    setConfirmed(false);
    setError("");
  };

  const handleReview = async () => {
    if (!run.project_id) {
      setError("Run is not linked to a project.");
      return;
    }
    if (!form.file_path.trim()) {
      setError("File path is required.");
      return;
    }
    setLoading("review");
    setError("");
    setReviewResult(null);
    try {
      const result = await reviewProjectPatch(run.project_id, {
        run_id: run.id,
        step_id: step.id,
        agent_id: agentId,
        operations: [{ file_path: form.file_path, old_text: form.old_text, new_text: form.new_text }],
      });
      setReviewResult(result);
    } catch (e: any) {
      setError(readableError(e));
    } finally {
      setLoading("");
    }
  };

  const handlePreview = async () => {
    if (!run.project_id) {
      setError("Run is not linked to a project.");
      return;
    }
    if (!form.file_path.trim()) {
      setError("File path is required.");
      return;
    }
    setLoading("preview");
    setError("");
    try {
      const result = await proposeProjectPatch(run.project_id, {
        run_id: run.id,
        step_id: step.id,
        agent_id: agentId,
        operations: [patchOperationFromForm(form)],
      });
      setPreview(result);
      setApplyResult(null);
      setConfirmed(false);
      await refreshStepCalls();
    } catch (e: any) {
      setError(readableError(e));
    } finally {
      setLoading("");
    }
  };

  const handleApply = async () => {
    if (!run.project_id || !confirmed) return;
    setLoading("apply");
    setError("");
    try {
      const result = await applyProjectPatch(run.project_id, {
        run_id: run.id,
        step_id: step.id,
        agent_id: agentId,
        proposal_id: preview?.proposal_id || preview?.tool_call_id || "",
        expected_summary: preview?.summary || "",
        confirm: true,
        operations: [patchOperationFromForm(form)],
      });
      setApplyResult(result);
      await refreshStepCalls();
    } catch (e: any) {
      setError(readableError(e));
    } finally {
      setLoading("");
    }
  };

  const recent = localCalls.filter(isPatchCall).slice(0, 3);
  const canApply =
    Boolean(preview) &&
    preview!.files.length > 0 &&
    preview!.files.every((file) => file.status !== "error") &&
    confirmed &&
    loading === "";

  return (
    <div data-step-id={step.id} data-action-anchor="step-patch" className="mt-4 rounded border border-gray-800 bg-gray-900 p-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h5 className="text-sm font-medium text-gray-300">Step Patch Tools</h5>
          <p className="mt-1 text-xs text-gray-500">{recent.length} patch call(s) linked to this step.</p>
        </div>
        <button
          onClick={() => setOpen((current) => !current)}
          className="rounded bg-gray-800 px-3 py-1.5 text-xs hover:bg-gray-700"
        >
          {open ? "Hide" : "Create Patch Proposal"}
        </button>
      </div>

      {recent.length > 0 && (
        <div className="mt-3 space-y-2">
          {recent.map((call) => {
            const audit = patchAuditDetails(call);
            return (
              <div key={call.id} className="rounded bg-gray-950 px-3 py-2 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge status={call.status || "unknown"} />
                  <span className="rounded bg-gray-800 px-2 py-0.5 text-gray-400">{call.risk_level}</span>
                  <span className="font-mono text-gray-300">{call.tool_name}</span>
                </div>
                <p className="mt-1 text-gray-500">{summarizeToolOutput(call)}</p>
                {audit.proposalId && <p className="mt-1 font-mono text-gray-500">proposal: {audit.proposalId}</p>}
                {audit.appliedFromProposalId && (
                  <p className="mt-1 font-mono text-gray-500">applied from: {audit.appliedFromProposalId}</p>
                )}
                {call.error && <p className="mt-1 text-red-300">{truncate(call.error, 180)}</p>}
              </div>
            );
          })}
        </div>
      )}

      {open && (
        <div className="mt-4 space-y-3">
          <div className="rounded border border-gray-800 bg-gray-950 p-3 text-xs text-gray-400">
            <p className="font-medium text-gray-300">Recommended manual flow</p>
            <ol className="mt-2 list-decimal space-y-1 pl-4">
              <li>Use a draft or fill `file_path`, `old_text`, and `new_text` manually.</li>
              <li>Click Review Patch. `old_text` should match the current file exactly.</li>
              <li>If review is OK, Preview/Create Proposal.</li>
              <li>Apply only with the manual confirmation checkbox.</li>
            </ol>
          </div>
          {/* Prefill context banner */}
          {issueContext && (
            <div className="rounded border border-blue-800 bg-blue-950/20 p-2 space-y-1">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-blue-300">Issue context (pre-filled from analysis)</p>
                <button onClick={() => setIssueContext(null)} className="text-xs text-gray-500 hover:text-gray-300">dismiss</button>
              </div>
              <p className="text-xs text-gray-400">
                <span className="rounded bg-blue-900 px-1 py-0.5 text-blue-400 mr-1">{issueContext.context_kind}</span>
                <span className="font-mono">{issueContext.context_location}</span>
              </p>
              <p className="text-xs text-gray-300">{issueContext.context_message}</p>
              <p className="text-xs text-yellow-400 border-t border-blue-900 pt-1">
                ⚠ This only pre-fills proposal context. It does not generate or apply a fix.
              </p>
            </div>
          )}
          {error && (
            <div className="rounded border border-red-800 bg-red-950/30 p-2 text-xs text-red-300">{error}</div>
          )}
          <label className="block">
            <span className="mb-1 block text-xs text-gray-500">File path</span>
            <input
              value={form.file_path}
              onChange={(event) => update("file_path", event.target.value)}
              placeholder="src/example.ts"
              className="w-full rounded border border-gray-700 bg-gray-800 px-3 py-2 font-mono text-xs focus:border-emerald-500 focus:outline-none"
            />
          </label>
          <div className="grid gap-3 lg:grid-cols-2">
            <label className="block">
              <span className="mb-1 block text-xs text-gray-500">Old text</span>
              <textarea
                value={form.old_text}
                onChange={(event) => update("old_text", event.target.value)}
                rows={5}
                className="w-full resize-y rounded border border-gray-700 bg-gray-800 px-3 py-2 font-mono text-xs focus:border-emerald-500 focus:outline-none"
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs text-gray-500">New text</span>
              <textarea
                value={form.new_text}
                onChange={(event) => update("new_text", event.target.value)}
                rows={5}
                className="w-full resize-y rounded border border-gray-700 bg-gray-800 px-3 py-2 font-mono text-xs focus:border-emerald-500 focus:outline-none"
              />
            </label>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-xs text-gray-400">
            <label className="inline-flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.create_if_missing}
                onChange={(event) => update("create_if_missing", event.target.checked)}
              />
              Create if missing
            </label>
            <label className="inline-flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.replace_all}
                onChange={(event) => update("replace_all", event.target.checked)}
              />
              Replace all
            </label>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleReview}
              disabled={loading !== ""}
              className="rounded bg-gray-700 px-3 py-1.5 text-xs hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500"
            >
              {loading === "review" ? "Reviewing..." : "Review Patch"}
            </button>
            <button
              onClick={handlePreview}
              disabled={loading !== ""}
              className="rounded bg-emerald-700 px-3 py-1.5 text-xs hover:bg-emerald-600 disabled:bg-gray-700 disabled:text-gray-500"
            >
              {loading === "preview" ? "Previewing..." : "Preview Patch"}
            </button>
          </div>

          {reviewResult && (
            <PatchReviewPanel result={reviewResult} onDismiss={() => setReviewResult(null)} />
          )}

          {preview && (
            <div className="space-y-3 rounded border border-gray-800 bg-gray-950 p-3">
              <p className="text-xs text-gray-300">{preview.summary}</p>
              {preview.proposal_id && <p className="font-mono text-xs text-gray-500">proposal: {preview.proposal_id}</p>}
              {preview.files.map((file) => (
                <div key={file.path}>
                  <div className="mb-2 flex flex-wrap items-center gap-2 text-xs">
                    <span className={`rounded px-2 py-0.5 ${patchStatusClass(file.status)}`}>{file.status}</span>
                    <span className="font-mono text-gray-300">{file.path}</span>
                    {file.error && <span className="text-red-300">{file.error}</span>}
                  </div>
                  {file.diff && (
                    <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded bg-gray-900 p-2 text-xs text-gray-300">
                      {file.diff}
                    </pre>
                  )}
                </div>
              ))}
              <label className="flex items-start gap-2 text-xs text-yellow-200">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(event) => setConfirmed(event.target.checked)}
                  disabled={preview.files.some((file) => file.status === "error") || loading !== ""}
                />
                <span>I understand this will modify files in the selected project workspace.</span>
              </label>
              <button
                onClick={handleApply}
                disabled={!canApply}
                className="rounded bg-red-800 px-3 py-1.5 text-xs hover:bg-red-700 disabled:bg-gray-700 disabled:text-gray-500"
              >
                {loading === "apply" ? "Applying..." : "Apply Patch"}
              </button>
            </div>
          )}

          {applyResult && (
            <div className="rounded border border-emerald-900 bg-emerald-950/20 p-3 text-xs text-emerald-100">
              <p>{applyResult.summary}</p>
              {applyResult.applied_from_proposal_id && (
                <p className="mt-1 font-mono text-gray-400">applied from: {applyResult.applied_from_proposal_id}</p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function PatchReviewPanel({
  result,
  onDismiss,
}: {
  result: PatchReviewResponse;
  onDismiss: () => void;
}) {
  const borderColor =
    result.status === "blocked"
      ? "border-red-800"
      : result.status === "warning"
      ? "border-yellow-800"
      : "border-emerald-800";
  const bgColor =
    result.status === "blocked"
      ? "bg-red-950/20"
      : result.status === "warning"
      ? "bg-yellow-950/20"
      : "bg-emerald-950/20";
  const statusLabel =
    result.status === "blocked"
      ? "🔴 BLOCKED"
      : result.status === "warning"
      ? "⚠ WARNING"
      : "✓ OK";
  const statusColor =
    result.status === "blocked"
      ? "text-red-300"
      : result.status === "warning"
      ? "text-yellow-300"
      : "text-emerald-300";

  const severityColor = (s: PatchReviewIssue["severity"]) =>
    s === "blocker" ? "text-red-400" : s === "warning" ? "text-yellow-300" : "text-blue-300";
  const severityBg = (s: PatchReviewIssue["severity"]) =>
    s === "blocker" ? "bg-red-900" : s === "warning" ? "bg-yellow-900" : "bg-blue-900";

  return (
    <div className={`rounded border ${borderColor} ${bgColor} p-3 space-y-2`}>
      <div className="flex items-center justify-between">
        <span className={`text-xs font-semibold ${statusColor}`}>{statusLabel} — Patch Review</span>
        <button onClick={onDismiss} className="text-xs text-gray-500 hover:text-gray-300">dismiss</button>
      </div>
      <p className="text-xs text-gray-300">{result.summary}</p>

      <div className="flex flex-wrap gap-3 text-xs">
        <span className={result.safe_to_create_proposal ? "text-emerald-400" : "text-red-400"}>
          {result.safe_to_create_proposal ? "✓ Safe to create proposal" : "✗ Unsafe to create proposal"}
        </span>
        <span className={result.safe_to_apply ? "text-emerald-400" : "text-red-400"}>
          {result.safe_to_apply ? "✓ Safe to apply" : "✗ Unsafe to apply"}
        </span>
      </div>

      {result.issues.length > 0 && (
        <div className="space-y-1">
          {result.issues.map((issue, i) => (
            <div key={i} className="flex flex-wrap items-start gap-2 rounded bg-gray-900 px-2 py-1.5 text-xs">
              <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${severityBg(issue.severity)} ${severityColor(issue.severity)}`}>
                {issue.severity}
              </span>
              <span className="rounded bg-gray-800 px-1.5 py-0.5 text-gray-400">{issue.code}</span>
              <span className="text-gray-300 flex-1">{issue.message}</span>
            </div>
          ))}
        </div>
      )}

      {result.status === "blocked" && (
        <p className="text-xs text-red-300 border-t border-red-900 pt-1">
          Resolve the blocker(s) above before creating a proposal or applying this patch.
        </p>
      )}
    </div>
  );
}

// ── Patch Workflow Panel ──────────────────────────────────────────────────────

const WORKFLOW_MODE_LABELS: Record<WorkflowAutomationMode, string> = {
  manual: "Manual",
  guided: "Guided",
  safe_prep: "Safe Prep",
};

const WORKFLOW_MODE_DESCRIPTIONS: Record<WorkflowAutomationMode, string> = {
  manual: "Actions only focus existing UI. No direct workflow execution.",
  guided: "Individual read-only actions can run. Manual actions stay manual.",
  safe_prep: "Run Safe Prep can gather context, build bundle, create draft, then stop.",
};

const WORKFLOW_MODE_OPTIONS: Array<{ value: WorkflowAutomationMode; label: string }> = [
  { value: "manual", label: WORKFLOW_MODE_LABELS.manual },
  { value: "guided", label: WORKFLOW_MODE_LABELS.guided },
  { value: "safe_prep", label: WORKFLOW_MODE_LABELS.safe_prep },
];

const WORKFLOW_MODE_POLICY_LINES = WORKFLOW_BOUNDARY_SUMMARY_LINES;

type PatchWorkflowRefresh = () => void | Promise<void>;

type PatchWorkflowPanelProps = {
  runId: string;
  steps: RunStep[];
  plan: PatchWorkflowPlanResponse | null;
  activeStepId: string | null;
  loading: boolean;
  error: string;
  workflowMode: WorkflowAutomationMode;
  onWorkflowModeChange: (mode: WorkflowAutomationMode) => void;
  onRefresh: PatchWorkflowRefresh;
  onActiveStepChange: (stepId: string | null) => void;
  onGuidedRefresh?: PatchWorkflowRefresh;
  onToolCallsRefresh?: PatchWorkflowRefresh;
  onFocusManualAction: (stepId: string, actionType: string) => Promise<ManualFocusResult>;
  onUseDraft?: (stepId: string, candidate: ContextPatchDraftCandidate) => void;
};

function PatchWorkflowPanel({
  runId,
  steps,
  plan,
  activeStepId,
  loading,
  error,
  workflowMode,
  onWorkflowModeChange,
  onRefresh,
  onActiveStepChange,
  onGuidedRefresh,
  onToolCallsRefresh,
  onFocusManualAction,
  onUseDraft,
}: PatchWorkflowPanelProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-gray-200">Patch Workflow Planner</h3>
          <p className="mt-1 text-xs text-gray-500">
            Use this tab as the main operator cockpit. Diagnostics are still available in Tool Plan and Guided tabs.
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={loading}
          className="rounded bg-gray-800 px-3 py-2 text-sm hover:bg-gray-700 disabled:text-gray-500"
        >
          {loading ? "Loading..." : "Refresh Plan"}
        </button>
      </div>

      {error && (
        <div className="rounded border border-red-800 bg-red-950/20 p-3 text-sm text-red-300">{error}</div>
      )}

      {!plan && !loading && !error && (
        <p className="text-sm text-gray-500">Click "Refresh Plan" to analyse the workflow state for this run.</p>
      )}

      {plan && (
        <div className="space-y-2">
          <PatchWorkflowCockpitCard
            runId={runId}
            plan={plan}
            steps={steps}
            activeStepId={activeStepId}
            workflowMode={workflowMode}
            onWorkflowModeChange={onWorkflowModeChange}
            onActiveStepChange={onActiveStepChange}
            onRefresh={onRefresh}
            onGuidedRefresh={onGuidedRefresh}
            onToolCallsRefresh={onToolCallsRefresh}
          />
          <p className="text-xs text-gray-400">{plan.summary}</p>
          {plan.warnings.length > 0 && (
            <div className="space-y-1">
              {plan.warnings.map((w, i) => (
                <p key={i} className="text-xs text-yellow-400">⚠ {w}</p>
              ))}
            </div>
          )}
          {plan.steps.length === 0 ? (
            <p className="text-sm text-gray-500">No steps found for this run.</p>
          ) : (
            <div className="space-y-4">
              {plan.steps.map((stepPlan) => (
                <StepWorkflowCard
                  key={stepPlan.step_id}
                  runId={runId}
                  plan={stepPlan}
                  workflowMode={workflowMode}
                  onRefresh={onRefresh}
                  onGuidedRefresh={onGuidedRefresh}
                  onToolCallsRefresh={onToolCallsRefresh}
                  onFocusManualAction={onFocusManualAction}
                  onUseDraft={onUseDraft}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function PatchWorkflowCockpitCard({
  runId,
  plan,
  steps,
  activeStepId,
  workflowMode,
  onWorkflowModeChange,
  onActiveStepChange,
  onRefresh,
  onGuidedRefresh,
  onToolCallsRefresh,
}: {
  runId: string;
  plan: PatchWorkflowPlanResponse;
  steps: RunStep[];
  activeStepId: string | null;
  workflowMode: WorkflowAutomationMode;
  onWorkflowModeChange: (mode: WorkflowAutomationMode) => void;
  onActiveStepChange: (stepId: string | null) => void;
  onRefresh: PatchWorkflowRefresh;
  onGuidedRefresh?: PatchWorkflowRefresh;
  onToolCallsRefresh?: PatchWorkflowRefresh;
}) {
  const firstActionable = plan.steps.find((step) => {
    return step.recommended_next_action && step.recommended_next_action.action_type !== "done";
  });
  const pinnedStep = activeStepId ? plan.steps.find((step) => step.step_id === activeStepId) || null : null;
  const actionable = pinnedStep || firstActionable;
  const pinnedMissing = Boolean(activeStepId && !pinnedStep);
  const pinnedDone = Boolean(pinnedStep?.recommended_next_action?.action_type === "done" || pinnedStep?.status === "done");

  // ── Safe Prep runner state ──
  const [safePrepRunning, setSafePrepRunning] = useState(false);
  const [safePrepStep, setSafePrepStep] = useState<string>("");
  const [safePrepError, setSafePrepError] = useState<string>("");
  const [safePrepResult, setSafePrepResult] = useState<string>("");

  const SAFE_PREP_SEQUENCE = ["auto_gather_context", "build_context_bundle", "create_patch_draft"] as const;

  const safePrepStepLabel = (action: string) =>
    action === "auto_gather_context" ? "Gathering context..." :
    action === "build_context_bundle" ? "Building context bundle..." :
    action === "create_patch_draft" ? "Creating patch draft..." : action;

  const isManualOnly = actionable?.recommended_next_action
    ? MANUAL_WORKFLOW_ACTIONS.has(actionable.recommended_next_action.action_type)
    : false;

  const handleSafePrep = async () => {
    if (!actionable || safePrepRunning) return;
    setSafePrepRunning(true);
    setSafePrepError("");
    setSafePrepResult("");

    const stepId = actionable.step_id;
    const agentId = actionable.agent_id || undefined;
    const results: string[] = [];
    let currentPhase = "";

    try {
      // A. auto_gather_context
      currentPhase = "auto_gather_context";
      setSafePrepStep(currentPhase);
      const ctxRes = await runStepAutoContext(runId, stepId, {
        query: actionable.summary || stepId,
        max_tool_calls: 5,
        agent_id: agentId,
      });
      results.push(`Context: ${ctxRes.summary} (${ctxRes.tool_call_ids.length} tool calls, ${ctxRes.files_read.length} files)`);

      // B. build_context_bundle
      currentPhase = "build_context_bundle";
      setSafePrepStep(currentPhase);
      const bundleRes = await getRunStepContextBundle(runId, stepId);
      results.push(`Bundle: ${bundleRes.bundle.summary} (${bundleRes.bundle.files.length} files)`);

      // C. create_patch_draft
      currentPhase = "create_patch_draft";
      setSafePrepStep(currentPhase);
      const draftRes = await buildContextPatchDraft(runId, stepId, { agent_id: agentId });
      results.push(`Draft: ${draftRes.summary} (${draftRes.candidates.length} candidates)`);

      // D. Stop — done, refresh
      setSafePrepStep("");
      setSafePrepResult(results.join(" → "));
      await onRefresh();
      await onGuidedRefresh?.();
      await onToolCallsRefresh?.();
    } catch (e: any) {
      setSafePrepError(`Failed at "${currentPhase || "unknown"}": ${e.message ?? "Unknown error"}`);
    } finally {
      setSafePrepRunning(false);
      setSafePrepStep("");
    }
  };

  if (!actionable) {
    return (
      <div className="rounded border border-emerald-800 bg-emerald-950/20 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Current actionable step</p>
            <p className="mt-1 text-sm font-medium text-emerald-100">Workflow complete</p>
          </div>
          <span className="rounded bg-emerald-900/50 px-2 py-1 text-xs text-emerald-200">done</span>
        </div>
        <WorkflowStepPicker
          plan={plan}
          steps={steps}
          activeStepId={activeStepId}
          onActiveStepChange={onActiveStepChange}
        />
        <p className="mt-2 text-xs text-emerald-200">No action needed. All workflow steps are complete or have no pending recommendation.</p>
      </div>
    );
  }

  const action = actionable.recommended_next_action || {
    action_type: "done",
    title: "No action needed",
    description: "Selected step has no pending recommended action.",
    risk_level: "low" as const,
    requires_confirmation: false,
    enabled: false,
    blocked_reason: null,
  };
  const stepTitle = steps.find((step) => step.id === actionable.step_id)?.title || actionable.summary || actionable.step_id;

  return (
    <div className="rounded border border-emerald-800 bg-emerald-950/10 p-3">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Current actionable step</p>
          <p className="mt-1 truncate text-sm font-medium text-gray-100">{stepTitle}</p>
          <div className="mt-1 flex flex-wrap gap-2 text-xs text-gray-500">
            <span className="font-mono">{shortId(actionable.step_id)}</span>
            <span>{actionable.status}</span>
            {actionable.agent_id && <span>{actionable.agent_id}</span>}
          </div>
        </div>
        <div className="flex flex-wrap justify-end gap-2">
          <span className={`rounded px-2 py-1 text-xs ${actionModeClass(action.action_type)}`}>
            {actionModeLabel(action)}
          </span>
          <span className={`rounded px-2 py-1 text-xs ${riskPillClass(action.risk_level)}`}>
            {action.risk_level}
          </span>
        </div>
      </div>

      <WorkflowStepPicker
        plan={plan}
        steps={steps}
        activeStepId={activeStepId}
        onActiveStepChange={onActiveStepChange}
        showModeStatus
        pinnedStepExists={Boolean(pinnedStep)}
        pinnedMissing={pinnedMissing}
        pinnedDone={pinnedDone}
      />

      <WorkflowModeSelector
        mode={workflowMode}
        modes={WORKFLOW_MODE_OPTIONS}
        modeDescription={WORKFLOW_MODE_DESCRIPTIONS[workflowMode]}
        savedForRunLabel="Saved for this run."
        policyTitle="Automation boundary"
        policyLines={WORKFLOW_MODE_POLICY_LINES}
        onModeChange={onWorkflowModeChange}
      />

      {/* ── Safe Prep Runner ── */}
      <div className="mt-3 rounded border border-cyan-900/60 bg-cyan-950/10 p-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-cyan-400">Safe Prep</p>
            {isManualOnly ? (
              <p className="mt-1 text-xs text-yellow-400">
                Manual only · this step is already at a manual stage.
              </p>
            ) : workflowMode === "manual" ? (
              <p className="mt-1 text-xs text-red-400">
                Blocked by Manual mode · safe prep is disabled in Manual mode.
              </p>
            ) : workflowMode === "guided" && !safePrepRunning && !safePrepResult ? (
              <p className="mt-1 text-xs text-yellow-400">
                Switch to Safe Prep mode to run the full preparation sequence.
              </p>
            ) : safePrepRunning ? (
              <p className="mt-1 text-xs text-cyan-300 animate-pulse">{safePrepStepLabel(safePrepStep)}</p>
            ) : safePrepResult ? (
              <p className="mt-1 text-xs text-gray-300">{safePrepResult}</p>
            ) : (
              <p className="mt-1 text-xs text-emerald-400">
                Allowed · read-only context + draft preparation only. No apply, no proposal.
              </p>
            )}
          </div>
          <button
            onClick={handleSafePrep}
            disabled={safePrepRunning || isManualOnly || pinnedDone || workflowMode !== "safe_prep"}
            className="whitespace-nowrap rounded bg-cyan-800 px-3 py-1.5 text-xs font-medium text-white hover:bg-cyan-700 disabled:cursor-not-allowed disabled:bg-gray-800 disabled:text-gray-500"
          >
            {safePrepRunning ? `${SAFE_PREP_SEQUENCE.indexOf(safePrepStep as any) + 1}/${SAFE_PREP_SEQUENCE.length}` : "Run Safe Prep"}
          </button>
        </div>
        {safePrepError && (
          <div className="mt-2 rounded border border-red-800 bg-red-950/20 p-1.5 text-xs text-red-300">{safePrepError}</div>
        )}
      </div>

      <div className="mt-3 grid gap-3 md:grid-cols-[1fr_1fr]">
        <div className="rounded border border-gray-800 bg-gray-950/70 p-2">
          <p className="text-[11px] uppercase tracking-wide text-gray-500">Recommended next action</p>
          <p className="mt-1 text-sm font-medium text-gray-100">{action.title}</p>
          <p className="mt-1 text-xs text-gray-400">{actionInstruction(action.action_type)}</p>
        </div>
        <div className="rounded border border-gray-800 bg-gray-950/70 p-2">
          <p className="text-[11px] uppercase tracking-wide text-gray-500">Destination</p>
          <p className="mt-1 text-sm font-medium text-gray-100">{actionDestinationLabel(action.action_type)}</p>
          <p className="mt-1 text-xs text-gray-500">{actionSafetyLabel(action)}</p>
        </div>
      </div>
    </div>
  );
}

function StepWorkflowCard({
  runId,
  plan,
  workflowMode,
  onRefresh,
  onGuidedRefresh,
  onToolCallsRefresh,
  onFocusManualAction,
  onUseDraft,
}: {
  runId: string;
  plan: StepPatchWorkflowPlan;
  workflowMode: WorkflowAutomationMode;
  onRefresh: PatchWorkflowRefresh;
  onGuidedRefresh?: PatchWorkflowRefresh;
  onToolCallsRefresh?: PatchWorkflowRefresh;
  onFocusManualAction: (stepId: string, actionType: string) => Promise<ManualFocusResult>;
  onUseDraft?: (stepId: string, candidate: ContextPatchDraftCandidate) => void;
}) {
  const [open, setOpen] = useState(true);

  const overallColor =
    plan.status === "done"
      ? "border-emerald-800"
      : plan.status === "blocked"
      ? "border-red-800"
      : plan.status === "in_progress" || plan.status === "ready_for_review" || plan.status === "ready_for_tests"
      ? "border-blue-800"
      : "border-gray-800";

  const statusBadge =
    plan.status === "done" ? "✓ done" :
    plan.status === "blocked" ? "✗ blocked" :
    plan.status === "ready_for_review" ? "→ ready for review" :
    plan.status === "ready_for_tests" ? "→ ready for tests" :
    plan.status === "in_progress" ? "⟳ in progress" : "○ not started";

  const statusColor =
    plan.status === "done" ? "text-emerald-400" :
    plan.status === "blocked" ? "text-red-400" :
    plan.status === "in_progress" || plan.status === "ready_for_review" || plan.status === "ready_for_tests" ? "text-blue-400" :
    "text-gray-500";

  return (
    <div className={`rounded border ${overallColor} bg-gray-950`}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between px-4 py-3 text-sm text-gray-300 hover:text-gray-100"
      >
        <div className="flex items-center gap-3 min-w-0">
          <span className={`text-xs font-semibold ${statusColor}`}>{statusBadge}</span>
          <span className="font-medium truncate">{plan.step_id}</span>
          {plan.agent_id && <span className="text-xs text-gray-500 truncate">{plan.agent_id}</span>}
        </div>
        <span className="text-gray-600 ml-2">{open ? "▾" : "▸"}</span>
      </button>

      {open && (
        <div className="border-t border-gray-800 px-4 pb-4 space-y-4">
          <p className="mt-3 text-xs text-gray-400">{plan.summary}</p>

          {/* Stage checklist */}
          <div className="space-y-1.5">
            {plan.stages.map((stage) => (
              <WorkflowStageRow key={stage.stage_id} stage={stage} />
            ))}
          </div>

          {/* Recommended next action */}
          {plan.recommended_next_action && plan.recommended_next_action.action_type !== "done" && (
            <div className="space-y-3">
              <NextActionCard
                action={plan.recommended_next_action}
                actionModeClass={actionModeClass}
                actionModeLabel={actionModeLabel}
                actionDestinationLabel={actionDestinationLabel}
                actionInstruction={actionInstruction}
                actionSafetyLabel={actionSafetyLabel}
              />
              <WorkflowActionLauncher
                runId={runId}
                plan={plan}
                action={plan.recommended_next_action}
                workflowMode={workflowMode}
                workflowModeLabel={WORKFLOW_MODE_LABELS[workflowMode]}
                onRefresh={onRefresh}
                onGuidedRefresh={onGuidedRefresh}
                onToolCallsRefresh={onToolCallsRefresh}
                onFocusManualAction={onFocusManualAction}
                onUseDraft={onUseDraft}
                workflowActionKind={workflowActionKind}
                getWorkflowActionPolicy={getWorkflowActionPolicy}
                manualWorkflowButtonLabel={manualWorkflowButtonLabel}
                manualWorkflowHint={manualWorkflowHint}
                actionModeClass={actionModeClass}
                actionModeLabel={actionModeLabel}
                actionDestinationLabel={actionDestinationLabel}
                policyLabelClass={policyLabelClass}
              />
            </div>
          )}
          {plan.recommended_next_action?.action_type === "done" && (
            <div className="rounded border border-emerald-800 bg-emerald-950/20 px-3 py-2 text-xs text-emerald-300">
              ✓ Workflow complete — tests passing, no pending actions.
            </div>
          )}

          {plan.warnings.length > 0 && (
            <div className="space-y-1">
              {plan.warnings.map((w, i) => (
                <p key={i} className="text-xs text-yellow-400">⚠ {w}</p>
              ))}
            </div>
          )}
          {plan.blockers.length > 0 && (
            <div className="space-y-1">
              {plan.blockers.map((b, i) => (
                <p key={i} className="text-xs text-red-400">✗ {b}</p>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

type WorkflowActionKind = "read_only" | "manual" | "done" | "unsupported";

const MANUAL_WORKFLOW_ACTIONS = new Set<string>(WORKFLOW_MANUAL_ONLY_ACTION_TYPES);

function workflowActionKind(actionType: string): WorkflowActionKind {
  const boundary = getWorkflowActionBoundary(actionType);
  if (actionType === "done") return "done";
  if (boundary.executionKind === "direct_safe") return "read_only";
  if (boundary.executionKind === "manual_only") return "manual";
  return "unsupported";
}

function manualWorkflowHint(actionType: string): string {
  switch (actionType) {
    case "review_patch":
      return "Use the Patch Proposal form for this step and click Review Patch with the exact file_path, old_text, and new_text.";
    case "create_proposal":
    case "propose_patch":
      return "Review or edit the Patch Proposal form, then create the proposal manually. Nothing is submitted automatically.";
    case "apply_patch_manual":
    case "apply_patch":
      return "Open the manual apply controls. Applying a patch still requires explicit confirmation and confirm=true.";
    case "run_tests_manual":
    case "run_tests":
    case "run_command":
      return "Run tests manually from the existing safe command runner. This launcher does not start project commands automatically.";
    case "analyze_result":
      return "Open a failed command result and click Analyze there. This launcher needs a specific failed tool_call before analysis can run.";
    case "rollback_manual":
    case "rollback_patch":
      return "Use the existing rollback controls. Rollback remains manual and requires explicit confirmation.";
    default:
      return "Open the matching manual workflow section and continue from there.";
  }
}

function manualWorkflowButtonLabel(actionType: string): string {
  switch (actionType) {
    case "review_patch":
      return "Open Patch Form / Review Patch";
    case "create_proposal":
    case "propose_patch":
      return "Open Patch Proposal Form";
    case "apply_patch_manual":
    case "apply_patch":
      return "Open Manual Apply";
    case "run_tests_manual":
    case "run_tests":
    case "run_command":
      return "Open Command Runner";
    case "analyze_result":
      return "Open Failed Command Result";
    case "rollback_manual":
    case "rollback_patch":
      return "Open Rollback Controls";
    default:
      return "Show Manual Instructions";
  }
}

// ── Workflow Approval Policy Matrix ──────────────────────────────────────────

type WorkflowActionPolicyDecision = {
  allowed: boolean;
  execution: "direct" | "draft_only" | "manual_only" | "blocked";
  riskLevel: "low" | "medium" | "high";
  requiresConfirmation: boolean;
  label: string;
  reason: string;
};

function getWorkflowActionPolicy(
  actionType: string,
  mode: WorkflowAutomationMode,
): WorkflowActionPolicyDecision {
  const boundary = getWorkflowActionBoundary(actionType);
  const kind = workflowActionKind(actionType);

  // Done / completed
  if (actionType === "done" || kind === "done") {
    return { allowed: false, execution: "blocked", riskLevel: "low", requiresConfirmation: false, label: "Complete", reason: "Step is already complete." };
  }

  // Manual-only actions — same in all modes
  if (kind === "manual") {
    const isHighRisk = actionType.includes("apply") || actionType.includes("rollback");
    const isMediumRisk = actionType.includes("test") || actionType.includes("run_command");
    const risk: "low" | "medium" | "high" = isHighRisk ? "high" : isMediumRisk ? "medium" : "low";
    const confirm = isHighRisk || isMediumRisk;
    return {
      allowed: true,
      execution: "manual_only",
      riskLevel: risk,
      requiresConfirmation: confirm,
      label: confirm ? "Confirm required · manual only" : "Manual only · opens form",
      reason: manualWorkflowHint(actionType),
    };
  }

  // Read-only / draft actions — mode-dependent
  if (kind === "read_only") {
    if (mode === "manual") {
      return {
        allowed: false,
        execution: "blocked",
        riskLevel: "low",
        requiresConfirmation: false,
        label: "Blocked by Manual mode",
        reason: "Switch to Guided or Safe Prep to run read-only preparation.",
      };
    }
    const isDraft = actionType === "create_patch_draft";
    return {
      allowed: true,
      execution: isDraft ? "draft_only" : "direct",
      riskLevel: isDraft ? "medium" : "low",
      requiresConfirmation: false,
      label: isDraft ? "Allowed now · draft only" : "Allowed now · read-only direct",
      reason: isDraft
        ? "Creates draft candidates. Does not create a proposal or apply any patch."
        : "Read-only action. No files modified.",
    };
  }

  // Unsupported / fallback
  return {
    allowed: false,
    execution: "blocked",
    riskLevel: boundary.riskLevel,
    requiresConfirmation: boundary.requiresConfirmation,
    label: boundary.executionKind === "approval_required_future" ? "Future approval boundary" : "Blocked",
    reason: boundary.reason || "This action type is not connected to a launcher.",
  };
}

function policyLabelClass(policy: WorkflowActionPolicyDecision): string {
  if (!policy.allowed) return "text-red-400";
  if (policy.execution === "manual_only") return "text-yellow-400";
  if (policy.execution === "draft_only") return "text-amber-300";
  return "text-emerald-400";
}

function actionModeLabel(action: PatchWorkflowNextAction): string {
  const type = action.action_type;
  if (type === "done") return "complete";
  if (type === "create_patch_draft") return "draft-only";
  if (type === "auto_gather_context" || type === "build_context_bundle") return "read-only direct";
  if (action.requires_confirmation || type.includes("apply") || type.includes("rollback")) return "confirm required";
  return "manual required";
}

function actionModeClass(actionType: string): string {
  if (actionType === "create_patch_draft") return "bg-amber-900/50 text-amber-300";
  if (actionType === "auto_gather_context" || actionType === "build_context_bundle") return "bg-blue-900/50 text-blue-300";
  if (actionType.includes("apply") || actionType.includes("rollback")) return "bg-red-900/50 text-red-300";
  return "bg-gray-800 text-gray-300";
}

function riskPillClass(risk: PatchWorkflowNextAction["risk_level"]): string {
  if (risk === "high") return "bg-red-900/50 text-red-300";
  if (risk === "medium") return "bg-yellow-900/50 text-yellow-300";
  return "bg-emerald-900/50 text-emerald-300";
}

function actionDestinationLabel(actionType: string): string {
  switch (actionType) {
    case "auto_gather_context":
    case "build_context_bundle":
    case "create_patch_draft":
      return "Runs here";
    case "review_patch":
    case "create_proposal":
    case "propose_patch":
    case "apply_patch_manual":
    case "apply_patch":
      return "Opens Timeline → Step Patch Tools";
    case "run_tests_manual":
    case "run_tests":
    case "run_command":
      return "Opens Timeline → Guided Fix Workflow";
    case "analyze_result":
      return "Opens Tool Calls → failed run-command";
    case "rollback_manual":
    case "rollback_patch":
      return "Opens Tool Calls → rollback-capable apply-patch";
    case "done":
      return "No action needed";
    default:
      return "Manual only";
  }
}

function actionInstruction(actionType: string): string {
  switch (actionType) {
    case "auto_gather_context":
      return "Click to gather read-only context for this step.";
    case "build_context_bundle":
      return "Click to summarize existing read-only tool calls.";
    case "create_patch_draft":
      return "Click to create candidates, then use one in the patch form.";
    case "review_patch":
      return "Open Step Patch Tools, check file_path, old_text, and new_text, then click Review Patch.";
    case "create_proposal":
    case "propose_patch":
      return "Review/edit fields, then create proposal manually.";
    case "apply_patch_manual":
    case "apply_patch":
      return "Use existing apply controls and confirm manually.";
    case "run_tests_manual":
    case "run_tests":
    case "run_command":
      return "Use Guided Fix Workflow or safe command runner.";
    case "analyze_result":
      return "Open failed run-command in Tool Calls and analyze manually.";
    case "rollback_manual":
    case "rollback_patch":
      return "Open rollback-capable apply-patch call and confirm manually.";
    case "done":
      return "No action needed.";
    default:
      return "Continue manually from the matching workflow section.";
  }
}

function actionSafetyLabel(action: PatchWorkflowNextAction): string {
  switch (action.action_type) {
    case "auto_gather_context":
    case "build_context_bundle":
      return "Runs now · read-only · no file changes";
    case "create_patch_draft":
      return "Creates draft only · no proposal/apply";
    case "review_patch":
    case "create_proposal":
    case "propose_patch":
      return "Manual · opens form · does not create proposal automatically";
    case "apply_patch_manual":
    case "apply_patch":
      return "Manual · requires confirm=true · no auto-apply";
    case "run_tests_manual":
    case "run_tests":
    case "run_command":
      return "Manual · use safe command runner · no auto-run";
    case "analyze_result":
      return "Manual · focus failed command · no auto-analyze";
    case "rollback_manual":
    case "rollback_patch":
      return "Manual · requires confirm=true · no auto-rollback";
    case "done":
      return "No action needed";
    default:
      return action.requires_confirmation ? "Manual · confirmation required" : "Manual only";
  }
}

function shortId(value: string): string {
  return value.length > 12 ? `${value.slice(0, 12)}…` : value;
}

function ExpandableOutput({
  value,
  previewMax,
  muted,
}: {
  value: string;
  previewMax: number;
  muted?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const needsTruncation = value.length > previewMax;
  const display = open || !needsTruncation ? value : value.slice(0, previewMax) + "...";
  const textColor = muted ? "text-gray-500" : "text-gray-300";

  return (
    <div className="mt-3">
      <pre
        className={`max-h-[400px] overflow-auto whitespace-pre-wrap rounded bg-gray-900 p-3 text-xs ${textColor}`}
      >
        {display}
      </pre>
      {needsTruncation && (
        <button
          onClick={() => setOpen(!open)}
          className="mt-1 text-xs text-emerald-400 hover:text-emerald-300"
        >
          {open ? "Show less" : "Show full output"}
        </button>
      )}
    </div>
  );
}

function toolCallTime(call: ToolCall): string {
  return call.completed_at || call.finished_at || call.created_at || "";
}

function isFailedRunCommandCall(call: ToolCall): boolean {
  if (call.tool_name !== "run-command") return false;
  const output = parseJsonObject(call.output_json);
  return (call.returncode !== null && call.returncode !== 0) || output.timed_out === true;
}

function isTimedOutToolCall(call: ToolCall): boolean {
  const output = parseJsonObject(call.output_json);
  return output.timed_out === true;
}

function isReadSearchContextTool(toolName: string): boolean {
  return [
    "list-files",
    "list_files",
    "read-file",
    "read_file",
    "search-code",
    "search_code",
    "auto-context",
    "auto_gather_context",
    "context-bundle",
    "context_patch_draft",
  ].includes(toolName);
}

function isRollbackCapableApplyPatchCall(call: ToolCall): boolean {
  if (call.tool_name !== "apply-patch") return false;
  const output = parseJsonObject(call.output_json);
  const rollbackData = output.rollback_data;
  return Array.isArray(rollbackData) &&
    rollbackData.some((entry) => {
      return Boolean(
        entry &&
        typeof entry === "object" &&
        "rollback_supported" in entry &&
        (entry as { rollback_supported?: unknown }).rollback_supported
      );
    });
}

function summarizeToolOutput(call: ToolCall): string {
  const raw = call.output_json?.trim();
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (call.tool_name === "propose-patch" || call.tool_name === "apply-patch") {
        return truncate(parsed.summary || `${parsed.files?.length ?? 0} patch file(s)`, 240);
      }
      if (Array.isArray(parsed.files)) return `${parsed.files.length} files listed`;
      if (Array.isArray(parsed.matches)) return `${parsed.matches.length} matches found`;
      if (typeof parsed.content === "string") {
        const path = typeof parsed.path === "string" ? `${parsed.path}: ` : "";
        return `${path}${parsed.content.length} characters read`;
      }
      if (typeof parsed.stdout === "string") return truncate(parsed.stdout || "(empty stdout)", 240);
      return truncate(JSON.stringify(parsed), 240);
    } catch {
      return truncate(raw, 240);
    }
  }
  return truncate(call.stdout || call.stderr || call.command || "(no output)", 240);
}

function patchAuditDetails(call: ToolCall): {
  agentId: string;
  proposalId: string;
  appliedFromProposalId: string;
} {
  const input = parseJsonObject(call.input_json);
  const output = parseJsonObject(call.output_json);
  return {
    agentId: stringValue(input.agent_id),
    proposalId: stringValue(output.proposal_id || input.proposal_id),
    appliedFromProposalId: stringValue(output.applied_from_proposal_id || input.proposal_id),
  };
}

function groupPatchCallsByStep(calls: ToolCall[]): Record<string, ToolCall[]> {
  return calls.filter(isPatchCall).reduce<Record<string, ToolCall[]>>((acc, call) => {
    if (!call.step_id) return acc;
    acc[call.step_id] = acc[call.step_id] || [];
    acc[call.step_id].push(call);
    return acc;
  }, {});
}

function isPatchCall(call: ToolCall): boolean {
  return call.tool_name === "propose-patch" || call.tool_name === "apply-patch";
}

function patchStatusClass(status: string): string {
  if (status === "create" || status === "created") return "bg-blue-900 text-blue-300";
  if (status === "modify" || status === "modified") return "bg-emerald-900 text-emerald-300";
  if (status === "unchanged") return "bg-gray-800 text-gray-300";
  if (status === "error") return "bg-red-900 text-red-300";
  return "bg-gray-800 text-gray-300";
}

function patchOperationFromForm(form: PatchFormState) {
  return {
    file_path: form.file_path.trim(),
    old_text: form.old_text,
    new_text: form.new_text,
    create_if_missing: form.create_if_missing,
    replace_all: form.replace_all,
  };
}

function parseJsonObject(raw: string): Record<string, unknown> {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function stringValue(value: unknown): string {
  return typeof value === "string" ? value : "";
}

function truncate(value: string, max: number): string {
  return value.length > max ? `${value.slice(0, max)}...` : value;
}

function readableError(error: unknown): string {
  return error instanceof Error ? error.message : "Unable to load data.";
}

function isNotFoundError(error: unknown): boolean {
  return error instanceof Error && (error.message.includes("API 404") || error.message.includes("Run not found"));
}

// ── Guided Execution Panel ─────────────────────────────────────────────────────

const RISK_CHIP: Record<string, string> = {
  low:    "bg-green-900/40 text-green-300",
  medium: "bg-yellow-900/40 text-yellow-300",
  high:   "bg-red-900/40 text-red-300",
};

const ACTION_TYPE_ICON: Record<string, string> = {
  read_context:   "📄",
  search_code:    "🔍",
  propose_patch:  "✏️",
  apply_patch:    "⚡",
  run_tests:      "🧪",
  analyze_result: "🔬",
  review_diff:    "👁️",
  rollback_patch: "↩️",
  done:           "✅",
};

function GuidedActionCard({
  action,
  isNext,
}: {
  action: GuidedStepAction;
  isNext: boolean;
}) {
  const icon = ACTION_TYPE_ICON[action.action_type] ?? "⚙️";
  const riskClass = RISK_CHIP[action.risk_level] ?? RISK_CHIP.low;

  return (
    <div
      className={`rounded border p-3 text-xs ${
        isNext
          ? "border-emerald-700 bg-emerald-950/30"
          : action.enabled
          ? "border-gray-700 bg-gray-900"
          : "border-gray-800 bg-gray-900/50 opacity-50"
      }`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm">{icon}</span>
        <span className={`font-medium ${isNext ? "text-emerald-300" : "text-gray-200"}`}>
          {action.title}
          {isNext && (
            <span className="ml-2 rounded bg-emerald-800/60 px-1.5 py-0.5 text-xs text-emerald-200">
              Recommended next
            </span>
          )}
        </span>
        <span className={`ml-auto rounded px-1.5 py-0.5 ${riskClass}`}>
          {action.risk_level}
        </span>
        {action.requires_confirmation && (
          <span className="rounded bg-orange-900/40 px-1.5 py-0.5 text-orange-300">
            confirm required
          </span>
        )}
      </div>

      {action.description && (
        <p className="mt-1.5 text-gray-400">{action.description}</p>
      )}
      {action.reason && (
        <p className="mt-1 text-gray-500 italic">{action.reason}</p>
      )}
      {!action.enabled && action.blocked_reason && (
        <p className="mt-1 text-red-400">Blocked: {action.blocked_reason}</p>
      )}
      {action.tool_name && (
        <p className="mt-1 font-mono text-gray-600">tool: {action.tool_name}</p>
      )}
    </div>
  );
}

const AUTO_READ_SAFE_ACTIONS = new Set(["list_files", "search_code", "read_file", "read_context"]);

function ContextFileCard({ file }: { file: StepContextFile }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="rounded border border-gray-800 bg-gray-900 px-2 py-1.5">
      <div className="flex items-center gap-2">
        <span className="font-mono text-gray-300 truncate flex-1">{file.file_path}</span>
        {file.read && (
          <span className="rounded bg-emerald-900/40 px-1 py-0.5 text-xs text-emerald-400">read</span>
        )}
        {file.match_count > 0 && (
          <span className="rounded bg-indigo-900/40 px-1 py-0.5 text-xs text-indigo-400">
            {file.match_count} match{file.match_count !== 1 ? "es" : ""}
          </span>
        )}
        {file.snippets.length > 0 && (
          <button
            onClick={() => setExpanded((v) => !v)}
            className="text-xs text-gray-500 hover:text-gray-300"
          >
            {expanded ? "▴ hide" : "▾ snippets"}
          </button>
        )}
      </div>
      {file.reason && <p className="mt-0.5 text-xs text-gray-600 italic">{file.reason}</p>}
      {expanded && file.snippets.length > 0 && (
        <div className="mt-1 space-y-1">
          {file.snippets.map((s, i) => (
            <pre key={i} className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400 whitespace-pre-wrap overflow-x-auto max-h-40">
              {s}
            </pre>
          ))}
        </div>
      )}
    </div>
  );
}

function GuidedStepCard({
  stepPlan,
  stepTitle,
  runId,
  onAutoReadDone,
  bundle,
  bundleLoading,
  onLoadBundle,
  onUseDraft,
}: {
  stepPlan: GuidedStepExecutionPlan;
  stepTitle: string;
  runId: string;
  onAutoReadDone: () => void;
  bundle: StepContextBundle | null;
  bundleLoading: boolean;
  onLoadBundle: () => void;
  onUseDraft: (candidate: ContextPatchDraftCandidate) => void;
}) {
  const [open, setOpen] = useState(false);
  const [autoReadResult, setAutoReadResult] = useState<AutoStepReadResponse | null>(null);
  const [autoReadRunning, setAutoReadRunning] = useState(false);
  const [autoReadError, setAutoReadError] = useState("");
  const [autoCtxResult, setAutoCtxResult] = useState<AutoContextGatherResponse | null>(null);
  const [autoCtxRunning, setAutoCtxRunning] = useState(false);
  const [autoCtxError, setAutoCtxError] = useState("");
  const [patchDraft, setPatchDraft] = useState<ContextPatchDraftResponse | null>(null);
  const [draftRunning, setDraftRunning] = useState(false);
  const [draftError, setDraftError] = useState("");
  const nextAction = stepPlan.recommended_next_action;
  const safeNextAction =
    nextAction && AUTO_READ_SAFE_ACTIONS.has(nextAction.action_type) ? nextAction : null;

  // Show "Auto Gather Context" when next action is a read op, or when very few context calls exist
  const contextCallCount = stepPlan.actions.filter(
    (a) => AUTO_READ_SAFE_ACTIONS.has(a.action_type)
  ).length;
  const showAutoCtxButton =
    safeNextAction !== null ||
    (nextAction && ["search_code", "read_context", "list_files"].includes(nextAction.action_type)) ||
    contextCallCount === 0;

  const handleCreateDraft = async () => {
    setDraftRunning(true);
    setDraftError("");
    setPatchDraft(null);
    try {
      const res = await buildContextPatchDraft(runId, stepPlan.step_id, {});
      setPatchDraft(res);
    } catch (e: any) {
      setDraftError(e.message ?? "Failed to build patch draft");
    } finally {
      setDraftRunning(false);
    }
  };

  const handleAutoContext = async () => {
    setAutoCtxRunning(true);
    setAutoCtxError("");
    setAutoCtxResult(null);
    try {
      const res = await runStepAutoContext(runId, stepPlan.step_id, {
        query: stepTitle,
        max_tool_calls: 5,
      });
      setAutoCtxResult(res);
      onAutoReadDone(); // refreshes tool calls + guided plan
    } catch (e: any) {
      setAutoCtxError(e.message ?? "Auto context gather failed");
    } finally {
      setAutoCtxRunning(false);
    }
  };

  const handleAutoRead = async () => {
    if (!safeNextAction) return;
    setAutoReadRunning(true);
    setAutoReadError("");
    setAutoReadResult(null);
    try {
      // For read_file/read_context: need file_path — show blocked if missing
      if (
        (safeNextAction.action_type === "read_file" || safeNextAction.action_type === "read_context") &&
        !safeNextAction.tool_name
      ) {
        setAutoReadError("Cannot auto-run read_file: no file path known for this step.");
        return;
      }
      const res = await runStepAutoRead(runId, stepPlan.step_id, {
        step_id: stepPlan.step_id,
        action_type: safeNextAction.action_type === "read_context" ? "read_file" : safeNextAction.action_type,
        query: safeNextAction.action_type === "search_code" ? stepTitle : "",
        file_path: safeNextAction.tool_name ?? "",
        run_id: runId,
      });
      setAutoReadResult(res);
      onAutoReadDone();
    } catch (e: any) {
      setAutoReadError(e.message ?? "Auto-read failed");
    } finally {
      setAutoReadRunning(false);
    }
  };

  return (
    <div className="rounded border border-gray-800 bg-gray-950">
      <button
        className="flex w-full items-center gap-3 px-4 py-3 text-left"
        onClick={() => setOpen((v) => !v)}
      >
        <span className="text-xs text-gray-500">{open ? "▾" : "▸"}</span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-gray-200">{stepTitle}</p>
          <p className="mt-0.5 text-xs text-gray-500">{stepPlan.status_summary}</p>
        </div>
        {nextAction && nextAction.action_type !== "done" && (
          <span className="shrink-0 rounded bg-emerald-900/50 px-2 py-0.5 text-xs text-emerald-300">
            {ACTION_TYPE_ICON[nextAction.action_type] ?? "⚙️"} {nextAction.title}
          </span>
        )}
        {nextAction?.action_type === "done" && (
          <span className="shrink-0 rounded bg-gray-800 px-2 py-0.5 text-xs text-gray-400">
            ✅ Done
          </span>
        )}
        {stepPlan.task_type && (
          <span className="shrink-0 rounded bg-gray-800 px-2 py-0.5 font-mono text-xs text-gray-500">
            {stepPlan.task_type}
          </span>
        )}
      </button>

      {open && (
        <div className="border-t border-gray-800 px-4 pb-4 pt-3 space-y-2">
          {stepPlan.warnings.length > 0 && (
            <div className="mb-2">
              {stepPlan.warnings.map((w, i) => (
                <p key={i} className="text-xs text-yellow-400">{w}</p>
              ))}
            </div>
          )}
          {stepPlan.actions.map((action) => (
            <GuidedActionCard
              key={action.action_id}
              action={action}
              isNext={nextAction?.action_id === action.action_id}
            />
          ))}

          {/* Safe Auto Read/Search button — only for read-only actions */}
          {safeNextAction && (
            <div className="mt-3 rounded border border-sky-900 bg-sky-950/20 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-sky-300">🔍 Safe Auto Read/Search</span>
                <span className="rounded bg-sky-900/50 px-1.5 py-0.5 text-xs text-sky-400">
                  read-only · no file changes
                </span>
              </div>
              <p className="mt-1 text-xs text-sky-500">
                Runs <code className="font-mono text-sky-400">{safeNextAction.action_type}</code> automatically.
                No patch, no command, no apply.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button
                  onClick={handleAutoRead}
                  disabled={autoReadRunning}
                  className="rounded bg-sky-800 px-3 py-1 text-xs font-medium text-sky-100 hover:bg-sky-700 disabled:opacity-50"
                >
                  {autoReadRunning ? "Running…" : `Run ${safeNextAction.action_type} (read-only)`}
                </button>
              </div>
              {autoReadError && (
                <p className="mt-2 text-xs text-red-400">⚠ {autoReadError}</p>
              )}
              {autoReadResult && (
                <div className="mt-2 rounded bg-gray-900 px-2 py-2 text-xs space-y-0.5">
                  <p className="text-gray-400">
                    Status: <span className={autoReadResult.status === "completed" ? "text-emerald-400" : "text-red-400"}>{autoReadResult.status}</span>
                  </p>
                  {autoReadResult.summary && (
                    <p className="text-gray-300">{autoReadResult.summary}</p>
                  )}
                  {autoReadResult.tool_call_id && (
                    <p className="font-mono text-gray-600">tool_call: {autoReadResult.tool_call_id}</p>
                  )}
                  {autoReadResult.warnings.length > 0 && (
                    <div>
                      {autoReadResult.warnings.map((w, i) => (
                        <p key={i} className="text-yellow-400">{w}</p>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Context Bundle — aggregated view of read-only tool calls */}
          <div className="mt-3 rounded border border-gray-700 bg-gray-950 px-3 py-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-medium text-gray-300">📦 Context Bundle</span>
              <button
                onClick={onLoadBundle}
                disabled={bundleLoading}
                className="rounded bg-gray-700 px-2 py-1 text-xs text-gray-300 hover:bg-gray-600 disabled:opacity-50"
              >
                {bundleLoading ? "Loading…" : "Build Context Bundle"}
              </button>
            </div>

            {!bundle && !bundleLoading && (
              <p className="mt-1.5 text-xs text-gray-600">
                No context yet. Run <span className="text-violet-400">Auto Gather Context</span> first, then build the bundle.
              </p>
            )}

            {bundle && bundle.status === "empty" && (
              <p className="mt-1.5 text-xs text-gray-500">
                {bundle.warnings[0] ?? "No read-only context collected yet."}
              </p>
            )}

            {bundle && bundle.status !== "empty" && (
              <div className="mt-2 space-y-1 text-xs">
                <p className="text-gray-400">{bundle.summary}</p>
                {bundle.queries.length > 0 && (
                  <p className="text-gray-500">
                    Queries: {bundle.queries.join(", ")}
                  </p>
                )}
                {bundle.files.length > 0 && (
                  <div className="space-y-1.5 mt-1">
                    {bundle.files.map((f, i) => (
                      <ContextFileCard key={i} file={f} />
                    ))}
                  </div>
                )}
                {bundle.warnings.length > 0 && (
                  <div className="mt-1">
                    {bundle.warnings.map((w, i) => (
                      <p key={i} className="text-yellow-400">{w}</p>
                    ))}
                  </div>
                )}
                {bundle.next_recommended_action && (
                  <p className="text-violet-400 mt-1">
                    Next: {bundle.next_recommended_action}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Context Patch Draft — build candidates from context bundle */}
          {bundle && bundle.status !== "empty" && (
            <div className="mt-3 rounded border border-amber-900 bg-amber-950/20 px-3 py-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-amber-300">✏️ Patch Draft from Context</span>
                  <span className="rounded bg-amber-900/50 px-1.5 py-0.5 text-xs text-amber-500">
                    draft only · no auto-apply
                  </span>
                </div>
                <button
                  onClick={handleCreateDraft}
                  disabled={draftRunning}
                  className="rounded bg-amber-800 px-2 py-1 text-xs text-amber-100 hover:bg-amber-700 disabled:opacity-50"
                >
                  {draftRunning ? "Building…" : "Create Patch Draft from Context"}
                </button>
              </div>

              {draftError && (
                <p className="mt-2 text-xs text-red-400">⚠ {draftError}</p>
              )}

              {patchDraft && (
                <div className="mt-2 space-y-2 text-xs">
                  <p className="rounded bg-amber-950/60 px-2 py-1 text-amber-300 font-medium">
                    ⚠ Draft only — review and edit before creating proposal.
                  </p>
                  <p className="text-gray-400">{patchDraft.summary}</p>
                  {patchDraft.warnings.map((w, i) => (
                    <p key={i} className="text-yellow-400">{w}</p>
                  ))}
                  {patchDraft.candidates.map((c, i) => (
                    <div
                      key={i}
                      className={`rounded border px-2 py-2 space-y-1 ${
                        i === patchDraft.recommended_candidate_index
                          ? "border-amber-700 bg-amber-950/40"
                          : "border-gray-800 bg-gray-900"
                      }`}
                    >
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-gray-300 truncate">{c.file_path}</span>
                        <span className="rounded bg-gray-800 px-1.5 py-0.5 text-gray-400">
                          {Math.round(c.confidence * 100)}% confidence
                        </span>
                        {i === patchDraft.recommended_candidate_index && (
                          <span className="rounded bg-amber-800/60 px-1.5 py-0.5 text-amber-200">
                            recommended
                          </span>
                        )}
                      </div>
                      <p className="text-gray-500 italic">{c.reason}</p>
                      {c.old_text && (
                        <div>
                          <p className="text-gray-600 mb-0.5">old_text (to find):</p>
                          <pre className="rounded bg-gray-950 px-2 py-1 text-gray-400 whitespace-pre-wrap overflow-x-auto max-h-24 text-xs">
                            {c.old_text.slice(0, 300)}{c.old_text.length > 300 ? "…" : ""}
                          </pre>
                        </div>
                      )}
                      {c.warnings.map((w, wi) => (
                        <p key={wi} className="text-yellow-500">{w}</p>
                      ))}
                      <button
                        onClick={() => onUseDraft(c)}
                        className="mt-1 rounded bg-emerald-900 px-2 py-1 text-xs text-emerald-200 hover:bg-emerald-800"
                      >
                        Use in Patch Proposal form →
                      </button>
                    </div>
                  ))}
                  {patchDraft.next_recommended_action && (
                    <p className="text-amber-500">Next: {patchDraft.next_recommended_action}</p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Auto Gather Context button — bounded read-only workflow */}
          {showAutoCtxButton && (
            <div className="mt-3 rounded border border-violet-900 bg-violet-950/20 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-violet-300">🧩 Auto Gather Context</span>
                <span className="rounded bg-violet-900/50 px-1.5 py-0.5 text-xs text-violet-400">
                  read-only · max 5 tool calls · no file changes
                </span>
              </div>
              <p className="mt-1 text-xs text-violet-500">
                Runs list_files → search_code → read_file automatically (up to 5 calls).
                No patch, no command, no apply.
              </p>
              <div className="mt-2">
                <button
                  onClick={handleAutoContext}
                  disabled={autoCtxRunning}
                  className="rounded bg-violet-800 px-3 py-1 text-xs font-medium text-violet-100 hover:bg-violet-700 disabled:opacity-50"
                >
                  {autoCtxRunning ? "Gathering context…" : "Auto Gather Context (read-only)"}
                </button>
              </div>
              {autoCtxError && (
                <p className="mt-2 text-xs text-red-400">⚠ {autoCtxError}</p>
              )}
              {autoCtxResult && (
                <div className="mt-2 rounded bg-gray-900 px-2 py-2 text-xs space-y-1">
                  <p className="text-gray-400">
                    Status:{" "}
                    <span className={autoCtxResult.status === "completed" ? "text-emerald-400" : "text-yellow-400"}>
                      {autoCtxResult.status}
                    </span>
                  </p>
                  {autoCtxResult.summary && (
                    <p className="text-gray-300">{autoCtxResult.summary}</p>
                  )}
                  {autoCtxResult.searched_queries.length > 0 && (
                    <p className="text-gray-500">
                      Queries: {autoCtxResult.searched_queries.join(", ")}
                    </p>
                  )}
                  {autoCtxResult.files_read.length > 0 && (
                    <div>
                      <p className="text-gray-500">Files read:</p>
                      {autoCtxResult.files_read.map((f, i) => (
                        <p key={i} className="font-mono text-gray-400 pl-2">
                          {f.file_path}{" "}
                          <span className="text-gray-600 not-italic">— {f.reason}</span>
                        </p>
                      ))}
                    </div>
                  )}
                  {autoCtxResult.next_recommended_action && (
                    <p className="text-violet-400">
                      Next: {autoCtxResult.next_recommended_action}
                    </p>
                  )}
                  {autoCtxResult.warnings.length > 0 && (
                    <div>
                      {autoCtxResult.warnings.map((w, i) => (
                        <p key={i} className="text-yellow-400">{w}</p>
                      ))}
                    </div>
                  )}
                  <p className="font-mono text-gray-700">
                    tool_calls: {autoCtxResult.tool_call_ids.length}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function GuidedExecutionPanel({
  plan,
  loading,
  error,
  steps,
  runId,
  onRefresh,
  onAutoReadDone,
  contextBundles,
  bundleLoading,
  onLoadBundle,
  onUseDraft,
}: {
  plan: GuidedExecutionPlanResponse | null;
  loading: boolean;
  error: string;
  steps: RunStep[];
  runId: string;
  onRefresh: () => void;
  onAutoReadDone: () => void;
  contextBundles: Record<string, StepContextBundle>;
  bundleLoading: Record<string, boolean>;
  onLoadBundle: (stepId: string) => void;
  onUseDraft: (stepId: string, candidate: ContextPatchDraftCandidate) => void;
}) {
  const stepTitleMap = Object.fromEntries(steps.map((s) => [s.id, s.title]));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-gray-200">Guided Execution</h3>
          <p className="mt-0.5 text-xs text-gray-500">
            Recommended next manual action per step. Nothing runs automatically.
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={loading}
          className="rounded bg-gray-700 px-3 py-1.5 text-xs text-gray-200 hover:bg-gray-600 disabled:opacity-50"
        >
          {loading ? "Loading…" : "Refresh Plan"}
        </button>
      </div>

      {error && (
        <p className="rounded bg-red-950/30 px-3 py-2 text-xs text-red-300">{error}</p>
      )}

      {!plan && !loading && !error && (
        <p className="text-sm text-gray-500">
          Click "Refresh Plan" to load guided execution recommendations.
        </p>
      )}

      {plan && (
        <>
          {plan.warnings.length > 0 && (
            <div className="rounded border border-yellow-800 bg-yellow-950/20 px-3 py-2">
              {plan.warnings.map((w, i) => (
                <p key={i} className="text-xs text-yellow-300">{w}</p>
              ))}
            </div>
          )}

          {plan.steps.length === 0 ? (
            <p className="text-sm text-gray-500">No steps found for this run.</p>
          ) : (
            <div className="space-y-2">
              {plan.steps.map((stepPlan) => (
                <GuidedStepCard
                  key={stepPlan.step_id}
                  stepPlan={stepPlan}
                  stepTitle={stepTitleMap[stepPlan.step_id] ?? stepPlan.step_id}
                  runId={runId}
                  onAutoReadDone={onAutoReadDone}
                  bundle={contextBundles[stepPlan.step_id] ?? null}
                  bundleLoading={bundleLoading[stepPlan.step_id] ?? false}
                  onLoadBundle={() => onLoadBundle(stepPlan.step_id)}
                  onUseDraft={(c) => onUseDraft(stepPlan.step_id, c)}
                />
              ))}
            </div>
          )}

          <p className="text-xs text-gray-600">{plan.summary}</p>
        </>
      )}
    </div>
  );
}

// ── Tool Plan Panel ────────────────────────────────────────────────────────────

const TOOL_CHIP_COLORS: Record<string, string> = {
  "read-file":             "bg-blue-900/50 text-blue-300",
  "search-code":           "bg-indigo-900/50 text-indigo-300",
  "propose-patch":         "bg-yellow-900/50 text-yellow-300",
  "apply-patch":           "bg-orange-900/50 text-orange-300",
  "git-diff":              "bg-teal-900/50 text-teal-300",
  "run-command":           "bg-purple-900/50 text-purple-300",
  "analyze-command-result":"bg-pink-900/50 text-pink-300",
};

const TOOL_HINTS: Record<string, string> = {
  "read-file":             "Read a file from the project workspace",
  "search-code":           "Search for symbols or patterns in the codebase",
  "propose-patch":         "Preview a patch before applying",
  "apply-patch":           "Apply a patch (requires manual confirm)",
  "git-diff":              "Inspect uncommitted git changes",
  "run-command":           "Run a safe project command (test/build/lint)",
  "analyze-command-result":"Analyze command output for issues",
};

function ToolPlanPanel({
  plan,
  loading,
  error,
  onRefresh,
}: {
  plan: StepToolPlanResponse | null;
  loading: boolean;
  error: string;
  onRefresh: () => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-gray-200">Recommended Tools per Step</h3>
          <p className="mt-0.5 text-xs text-gray-500">
            Advisory only — no tool runs automatically.
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={loading}
          className="rounded bg-gray-700 px-3 py-1.5 text-xs text-gray-200 hover:bg-gray-600 disabled:opacity-50"
        >
          {loading ? "Loading…" : "Refresh Tool Plan"}
        </button>
      </div>

      {error && (
        <p className="rounded bg-red-950/30 px-3 py-2 text-xs text-red-300">{error}</p>
      )}

      {!plan && !loading && !error && (
        <p className="text-sm text-gray-500">
          Click "Refresh Tool Plan" to load recommendations for this run's steps.
        </p>
      )}

      {plan && (
        <>
          {plan.warnings.length > 0 && (
            <div className="rounded border border-yellow-800 bg-yellow-950/20 px-3 py-2">
              {plan.warnings.map((w, i) => (
                <p key={i} className="text-xs text-yellow-300">{w}</p>
              ))}
            </div>
          )}

          {plan.recommendations.length === 0 ? (
            <p className="text-sm text-gray-500">No steps found for this run.</p>
          ) : (
            <div className="space-y-3">
              {plan.recommendations.map((rec) => (
                <div
                  key={rec.step_id}
                  className="rounded border border-gray-800 bg-gray-950 p-3"
                >
                  <div className="mb-2 flex flex-wrap items-center gap-2">
                    <span className="rounded bg-gray-800 px-2 py-0.5 font-mono text-xs text-gray-400">
                      {rec.task_type || "unknown"}
                    </span>
                    {rec.agent_id && (
                      <span className="text-xs text-gray-500">{rec.agent_id}</span>
                    )}
                    <span className="ml-auto text-xs text-gray-600">
                      confidence {Math.round(rec.confidence * 100)}%
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {rec.recommended_tools.map((tool) => (
                      <span
                        key={tool}
                        title={TOOL_HINTS[tool] ?? tool}
                        className={`rounded px-2 py-0.5 text-xs font-mono cursor-default ${
                          TOOL_CHIP_COLORS[tool] ?? "bg-gray-800 text-gray-300"
                        }`}
                      >
                        {tool}
                      </span>
                    ))}
                  </div>

                  {rec.reason && (
                    <p className="mt-2 text-xs text-gray-500">{rec.reason}</p>
                  )}

                  {rec.warnings.length > 0 && (
                    <ul className="mt-1 space-y-0.5">
                      {rec.warnings.map((w, i) => (
                        <li key={i} className="text-xs text-yellow-400">{w}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          )}

          <p className="text-xs text-gray-600">{plan.summary}</p>
        </>
      )}
    </div>
  );
}
