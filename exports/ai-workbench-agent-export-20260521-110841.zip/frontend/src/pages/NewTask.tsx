import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { analyzeProjectIntake, createRun, draftProjectBrief, getProjects, previewIntakePlan } from "../api/client";
import type {
  DevelopmentPlanPhase,
  DevelopmentPlanPreviewResponse,
  Project,
  ProjectBriefDraftResponse,
  ProjectBriefSection,
  ProjectIntakeQuestion,
  ProjectIntakeResponse,
  RunMode,
} from "../types";

export default function NewTask() {
  const [prompt, setPrompt] = useState("");
  const [mode, setMode] = useState<RunMode>("offline");
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectId, setProjectId] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [error, setError] = useState("");
  const [intakeLoading, setIntakeLoading] = useState(false);
  const [intakeError, setIntakeError] = useState("");
  const [intakeResult, setIntakeResult] = useState<ProjectIntakeResponse | null>(null);
  const [briefLoading, setBriefLoading] = useState(false);
  const [briefError, setBriefError] = useState("");
  const [briefResult, setBriefResult] = useState<ProjectBriefDraftResponse | null>(null);
  const [planLoading, setPlanLoading] = useState(false);
  const [planError, setPlanError] = useState("");
  const [planResult, setPlanResult] = useState<DevelopmentPlanPreviewResponse | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    getProjects()
      .then((items) => {
        setProjects(items);
        setProjectId((current) => current || items[0]?.id || "");
      })
      .catch((e: any) => setError(e.message))
      .finally(() => setLoadingProjects(false));
  }, []);

  const selectedProject = useMemo(
    () => projects.find((project) => project.id === projectId) || null,
    [projectId, projects],
  );

  const canStart = Boolean(prompt.trim() && projectId && !loading);
  const canAnalyze = Boolean(prompt.trim() && !intakeLoading);
  const canDraftBrief = Boolean(prompt.trim() && !briefLoading);
  const canPreviewPlan = Boolean(prompt.trim() && !planLoading);

  const handleAnalyzeIdea = async () => {
    if (!canAnalyze) return;
    setIntakeLoading(true);
    setIntakeError("");
    try {
      const result = await analyzeProjectIntake({ idea: prompt });
      setIntakeResult(result);
    } catch (e: any) {
      setIntakeError(e.message);
    } finally {
      setIntakeLoading(false);
    }
  };

  const handleDraftBrief = async () => {
    if (!canDraftBrief) return;
    setBriefLoading(true);
    setBriefError("");
    try {
      const result = await draftProjectBrief({ idea: prompt });
      setBriefResult(result);
    } catch (e: any) {
      setBriefError(e.message);
    } finally {
      setBriefLoading(false);
    }
  };

  const handlePreviewPlan = async () => {
    if (!canPreviewPlan) return;
    setPlanLoading(true);
    setPlanError("");
    try {
      const result = await previewIntakePlan({
        idea: prompt,
        brief_markdown: briefResult?.brief_markdown,
      });
      setPlanResult(result);
    } catch (e: any) {
      setPlanError(e.message);
    } finally {
      setPlanLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!canStart) return;
    setLoading(true);
    setError("");
    try {
      const run = await createRun({ prompt, mode, project_id: projectId });
      navigate(`/runs/${run.id}`);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="text-2xl font-bold">New Task</h2>
        <p className="mt-1 text-sm text-gray-500">Every run must be tied to a validated project profile.</p>
      </div>

      <section className="rounded border border-gray-800 bg-gray-900 p-4">
        <label className="block text-sm text-gray-400 mb-2">Project</label>
        {loadingProjects ? (
          <p className="text-sm text-gray-500">Loading projects...</p>
        ) : projects.length === 0 ? (
          <div className="rounded border border-yellow-900 bg-yellow-950/20 p-3 text-sm text-yellow-300">
            Create a project profile before starting a task.
          </div>
        ) : (
          <>
            <select
              value={projectId}
              onChange={(event) => setProjectId(event.target.value)}
              className="w-full rounded border border-gray-700 bg-gray-800 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
            >
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
            {selectedProject && (
              <div className="mt-3 grid grid-cols-1 gap-2 text-xs text-gray-500 sm:grid-cols-2">
                <Info label="Path" value={selectedProject.path} />
                <Info label="Stack" value={selectedProject.stack || "unspecified"} />
                <Info label="Test" value={selectedProject.test_command || "not configured"} />
                <Info label="Build" value={selectedProject.build_command || "not configured"} />
              </div>
            )}
          </>
        )}
      </section>

      <div>
        <label className="block text-sm text-gray-400 mb-2">Task Description</label>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe what you want the AI agents to do..."
          rows={6}
          className="w-full bg-gray-900 border border-gray-700 rounded p-3 text-sm focus:outline-none focus:border-emerald-500 resize-y"
        />
      </div>

      <section className="rounded border border-gray-800 bg-gray-900 p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-gray-200">Project Intake</h3>
            <p className="mt-1 text-xs text-gray-500">
              These questions are advisory. You can answer them in the task prompt or continue with defaults.
            </p>
            <p className="mt-1 text-xs text-gray-600">
              Intake analysis is read-only. It does not create a run, execute tools, or call providers.
            </p>
            <p className="mt-1 text-xs text-gray-600">
              Brief draft is read-only. It does not create a run, execute tools, or call providers.
            </p>
            <p className="mt-1 text-xs text-gray-600">
              Plan preview is read-only. It does not create a run, assign agents, execute tools, or call providers.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleAnalyzeIdea}
              disabled={!canAnalyze}
              className="rounded bg-gray-800 px-3 py-2 text-xs font-medium text-gray-200 transition-colors hover:bg-gray-700 disabled:cursor-not-allowed disabled:bg-gray-800 disabled:text-gray-600"
            >
              {intakeLoading ? "Analyzing..." : "Analyze idea"}
            </button>
            <button
              onClick={handleDraftBrief}
              disabled={!canDraftBrief}
              className="rounded bg-gray-800 px-3 py-2 text-xs font-medium text-gray-200 transition-colors hover:bg-gray-700 disabled:cursor-not-allowed disabled:bg-gray-800 disabled:text-gray-600"
            >
              {briefLoading ? "Drafting..." : "Draft brief"}
            </button>
            <button
              onClick={handlePreviewPlan}
              disabled={!canPreviewPlan}
              className="rounded bg-gray-800 px-3 py-2 text-xs font-medium text-gray-200 transition-colors hover:bg-gray-700 disabled:cursor-not-allowed disabled:bg-gray-800 disabled:text-gray-600"
            >
              {planLoading ? "Previewing..." : "Preview plan"}
            </button>
          </div>
        </div>

        {intakeError && (
          <p className="mt-3 rounded border border-red-800 bg-red-950/20 px-3 py-2 text-xs text-red-300">
            {intakeError}
          </p>
        )}

        {intakeResult && <IntakeResultPanel result={intakeResult} />}
        {briefError && (
          <p className="mt-3 rounded border border-red-800 bg-red-950/20 px-3 py-2 text-xs text-red-300">
            {briefError}
          </p>
        )}
        {briefResult && <BriefDraftPanel result={briefResult} />}
        {planError && (
          <p className="mt-3 rounded border border-red-800 bg-red-950/20 px-3 py-2 text-xs text-red-300">
            {planError}
          </p>
        )}
        {planResult && <PlanPreviewPanel result={planResult} />}
      </section>

      <div>
        <label className="block text-sm text-gray-400 mb-2">Mode</label>
        <div className="flex flex-wrap gap-3">
          {(["offline", "hybrid", "cloud"] as RunMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`px-4 py-2 rounded text-sm border transition-colors ${
                mode === m
                  ? "border-emerald-500 bg-emerald-900/30 text-emerald-300"
                  : "border-gray-700 text-gray-400 hover:border-gray-500"
              }`}
            >
              {m.charAt(0).toUpperCase() + m.slice(1)}
            </button>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-2">
          {mode === "offline" && "Uses only local Ollama. No external API calls."}
          {mode === "hybrid" && "Local-first with cloud fallback when needed."}
          {mode === "cloud" && "Uses cloud providers when explicitly enabled."}
        </p>
      </div>

      {error && <p className="text-red-400 text-sm">{error}</p>}

      <button
        onClick={handleSubmit}
        disabled={!canStart}
        className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-700 disabled:text-gray-500 rounded text-sm font-medium transition-colors"
      >
        {loading ? "Starting..." : "Start Task"}
      </button>
    </div>
  );
}

function PlanPreviewPanel({ result }: { result: DevelopmentPlanPreviewResponse }) {
  return (
    <div className="mt-4 space-y-4 border-t border-gray-800 pt-4">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={`rounded px-2 py-1 text-xs font-medium ${
            result.ready_to_start
              ? "bg-emerald-900/50 text-emerald-300"
              : "bg-yellow-900/40 text-yellow-300"
          }`}
        >
          {result.ready_to_start ? "Ready to start" : "Needs input"}
        </span>
        <span className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400">
          {formatLabel(result.mode)}
        </span>
        <span className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400">
          {formatLabel(result.target_type)}
        </span>
      </div>

      <div className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
        <p className="text-xs font-medium text-gray-300">{result.title}</p>
        <p className="mt-1 text-sm text-gray-400">{result.summary}</p>
        <p className="mt-2 text-xs text-gray-500">
          Intake ready: {result.source_readiness.intake_ready_to_plan ? "yes" : "no"} | Brief ready:{" "}
          {result.source_readiness.brief_ready_to_plan ? "yes" : "no"}
        </p>
        {result.recommended_next_step && (
          <p className="mt-2 text-xs text-emerald-400">{result.recommended_next_step}</p>
        )}
      </div>

      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Plan phases</p>
        <div className="space-y-2">
          {result.phases.map((phase) => (
            <PlanPhaseCard key={phase.id} phase={phase} />
          ))}
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <IntakeList title="Required inputs" items={result.required_inputs} empty="No required inputs detected." />
        <IntakeList title="Plan assumptions" items={result.assumptions} empty="No assumptions detected." />
        <IntakeList title="Plan risks" items={result.risks} empty="No major risks detected." />
        <IntakeList title="Recommended agents" items={result.recommended_agent_ids} empty="No agents recommended." />
      </div>
    </div>
  );
}

function PlanPhaseCard({ phase }: { phase: DevelopmentPlanPhase }) {
  return (
    <article className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
      <div className="flex flex-wrap items-center gap-2">
        <span className={`rounded px-2 py-0.5 text-[11px] font-medium ${planPhaseStatusClass(phase.status)}`}>
          {formatLabel(phase.status)}
        </span>
        <span className={`rounded px-2 py-0.5 text-[11px] font-medium ${priorityClass(phase.priority)}`}>
          {phase.priority}
        </span>
        {phase.suggested_agent_id && (
          <span className="rounded bg-gray-900 px-2 py-0.5 text-[11px] text-gray-500">
            {phase.suggested_agent_id}
          </span>
        )}
      </div>
      <p className="mt-2 text-sm font-medium text-gray-200">{phase.title}</p>
      <p className="mt-1 text-xs text-gray-500">{phase.description}</p>
      {phase.depends_on.length > 0 && (
        <p className="mt-2 text-xs text-gray-600">Depends on: {phase.depends_on.join(", ")}</p>
      )}
      {phase.deliverables.length > 0 && (
        <div className="mt-2">
          <p className="text-[11px] font-medium uppercase tracking-wide text-gray-600">Deliverables</p>
          <ul className="mt-1 space-y-1 text-xs text-gray-400">
            {phase.deliverables.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      )}
      {phase.risks.length > 0 && (
        <div className="mt-2">
          <p className="text-[11px] font-medium uppercase tracking-wide text-gray-600">Risks</p>
          <ul className="mt-1 space-y-1 text-xs text-yellow-300">
            {phase.risks.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      )}
    </article>
  );
}

function BriefDraftPanel({ result }: { result: ProjectBriefDraftResponse }) {
  return (
    <div className="mt-4 space-y-4 border-t border-gray-800 pt-4">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={`rounded px-2 py-1 text-xs font-medium ${
            result.ready_to_plan
              ? "bg-emerald-900/50 text-emerald-300"
              : "bg-yellow-900/40 text-yellow-300"
          }`}
        >
          {result.ready_to_plan ? "Ready to plan" : "Needs clarification"}
        </span>
        <span className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400">
          {formatLabel(result.mode)}
        </span>
        <span className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400">
          {formatLabel(result.target_type)}
        </span>
      </div>

      <div className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
        <p className="text-xs font-medium text-gray-300">{result.title}</p>
        <p className="mt-1 text-sm text-gray-400">{result.summary}</p>
        {result.recommended_next_step && (
          <p className="mt-2 text-xs text-emerald-400">{result.recommended_next_step}</p>
        )}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {result.sections.map((section) => (
          <BriefSectionCard key={section.title} section={section} />
        ))}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <IntakeList title="Brief assumptions" items={result.assumptions} empty="No assumptions detected." />
        <IntakeList title="Brief missing information" items={result.missing_information} empty="No major gaps detected." />
      </div>

      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Open questions</p>
        {result.open_questions.length === 0 ? (
          <p className="rounded border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-gray-500">
            No open questions returned.
          </p>
        ) : (
          <div className="space-y-2">
            {result.open_questions.map((question) => (
              <IntakeQuestionCard key={question.id} question={question} />
            ))}
          </div>
        )}
      </div>

      <div className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
        <p className="text-xs font-medium text-gray-300">Brief markdown preview</p>
        <pre className="mt-2 max-h-96 overflow-auto whitespace-pre-wrap rounded bg-gray-900 p-3 text-xs leading-relaxed text-gray-400">
          {result.brief_markdown}
        </pre>
      </div>
    </div>
  );
}

function BriefSectionCard({ section }: { section: ProjectBriefSection }) {
  return (
    <article className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
      <div className="flex flex-wrap items-center gap-2">
        <p className="text-xs font-medium text-gray-300">{section.title}</p>
        <span className={`rounded px-2 py-0.5 text-[11px] font-medium ${sectionStatusClass(section.status)}`}>
          {section.status}
        </span>
      </div>
      <p className="mt-2 text-xs text-gray-400">{section.content}</p>
      {section.notes && <p className="mt-2 text-xs text-gray-600">{section.notes}</p>}
    </article>
  );
}

function IntakeResultPanel({ result }: { result: ProjectIntakeResponse }) {
  return (
    <div className="mt-4 space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={`rounded px-2 py-1 text-xs font-medium ${
            result.ready_to_plan
              ? "bg-emerald-900/50 text-emerald-300"
              : "bg-yellow-900/40 text-yellow-300"
          }`}
        >
          {result.ready_to_plan ? "Ready to plan" : "Needs clarification"}
        </span>
        <span className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400">
          {formatLabel(result.mode)}
        </span>
        <span className="rounded bg-gray-950 px-2 py-1 text-xs text-gray-400">
          confidence: {result.confidence}
        </span>
      </div>

      <div className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
        <p className="text-xs font-medium text-gray-300">Summary</p>
        <p className="mt-1 text-sm text-gray-400">{result.summary}</p>
        {result.recommended_next_step && (
          <p className="mt-2 text-xs text-emerald-400">{result.recommended_next_step}</p>
        )}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <IntakeList title="Assumptions" items={result.assumptions} empty="No assumptions detected." />
        <IntakeList title="Missing information" items={result.missing_information} empty="No major gaps detected." />
      </div>

      {result.mode === "existing_project" && <ExistingProjectChecklist questions={result.questions} />}

      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Clarifying questions</p>
        {result.questions.length === 0 ? (
          <p className="rounded border border-gray-800 bg-gray-950 px-3 py-2 text-xs text-gray-500">
            No clarifying questions returned.
          </p>
        ) : (
          <div className="space-y-2">
            {result.questions.map((question) => (
              <IntakeQuestionCard key={question.id} question={question} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const EXISTING_PROJECT_CHECKLIST = [
  {
    label: "Project location/path",
    keywords: ["project files", "path", "repository url", "located"],
  },
  {
    label: "Stack/frameworks",
    keywords: ["tech stack", "framework"],
  },
  {
    label: "What already works",
    keywords: ["already works", "current state"],
  },
  {
    label: "What is broken",
    keywords: ["broken", "incomplete", "fixed first"],
  },
  {
    label: "Next development goal",
    keywords: ["next goal", "built or improved"],
  },
  {
    label: "Dev/build/test commands",
    keywords: ["dev/build commands", "development mode", "test command", "run them"],
  },
  {
    label: "DB/env/local services",
    keywords: ["database", "environment variables", "local services"],
  },
  {
    label: "Git status/history",
    keywords: ["git history", "branch structure"],
  },
  {
    label: "Dangerous files/secrets",
    keywords: ["not be modified", ".env", "secrets", "credentials", "ignored"],
  },
  {
    label: "Deployment target",
    keywords: ["deployment target", "hosting environment"],
  },
];

function ExistingProjectChecklist({ questions }: { questions: ProjectIntakeQuestion[] }) {
  const items = EXISTING_PROJECT_CHECKLIST.map((item) => ({
    ...item,
    question: findChecklistQuestion(questions, item.keywords),
  }));

  return (
    <div className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">
          Existing Project Onboarding Checklist
        </p>
        <span className="rounded bg-gray-900 px-2 py-0.5 text-[11px] text-gray-500">Advisory</span>
      </div>
      <p className="mt-2 text-xs text-gray-600">
        Existing project onboarding is advisory only. It does not scan files, create a run, execute tools, or call providers.
      </p>
      <div className="mt-3 grid gap-2 md:grid-cols-2">
        {items.map((item) => (
          <div key={item.label} className="rounded border border-gray-800 bg-gray-900 px-3 py-2">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`rounded px-2 py-0.5 text-[11px] font-medium ${
                  item.question ? priorityClass(item.question.priority) : "bg-gray-800 text-gray-500"
                }`}
              >
                {item.question ? item.question.priority : "not returned"}
              </span>
              <p className="text-xs font-medium text-gray-300">{item.label}</p>
            </div>
            {item.question ? (
              <p className="mt-1 text-xs text-gray-500">{item.question.question}</p>
            ) : (
              <p className="mt-1 text-xs text-gray-600">
                Not included in the current intake response.
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function findChecklistQuestion(
  questions: ProjectIntakeQuestion[],
  keywords: string[],
): ProjectIntakeQuestion | undefined {
  return questions.find((question) => {
    const haystack = `${question.question} ${question.why_it_matters}`.toLowerCase();
    return keywords.some((keyword) => haystack.includes(keyword));
  });
}

function IntakeList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
      <p className="text-xs font-medium text-gray-300">{title}</p>
      {items.length === 0 ? (
        <p className="mt-1 text-xs text-gray-600">{empty}</p>
      ) : (
        <ul className="mt-1 space-y-1 text-xs text-gray-400">
          {items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

function IntakeQuestionCard({ question }: { question: ProjectIntakeQuestion }) {
  return (
    <article className="rounded border border-gray-800 bg-gray-950 px-3 py-2">
      <div className="flex flex-wrap items-center gap-2">
        <span className={`rounded px-2 py-0.5 text-[11px] font-medium ${priorityClass(question.priority)}`}>
          {question.priority}
        </span>
        <span className="rounded bg-gray-900 px-2 py-0.5 text-[11px] text-gray-500">
          {formatLabel(question.category)}
        </span>
      </div>
      <p className="mt-2 text-sm font-medium text-gray-200">{question.question}</p>
      <p className="mt-1 text-xs text-gray-500">{question.why_it_matters}</p>
      {question.suggested_default && (
        <p className="mt-2 rounded bg-gray-900 px-2 py-1 text-xs text-gray-400">
          Suggested default: {question.suggested_default}
        </p>
      )}
      {question.options && question.options.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {question.options.map((option) => (
            <span key={option} className="rounded bg-gray-900 px-2 py-0.5 text-[11px] text-gray-500">
              {option}
            </span>
          ))}
        </div>
      )}
    </article>
  );
}

function priorityClass(priority: ProjectIntakeQuestion["priority"]): string {
  if (priority === "required") return "bg-red-900/40 text-red-300";
  if (priority === "recommended") return "bg-yellow-900/40 text-yellow-300";
  return "bg-gray-800 text-gray-400";
}

function sectionStatusClass(status: ProjectBriefSection["status"]): string {
  if (status === "confirmed") return "bg-emerald-900/40 text-emerald-300";
  if (status === "missing") return "bg-red-900/40 text-red-300";
  return "bg-yellow-900/40 text-yellow-300";
}

function planPhaseStatusClass(status: DevelopmentPlanPhase["status"]): string {
  if (status === "ready") return "bg-emerald-900/40 text-emerald-300";
  if (status === "blocked") return "bg-red-900/40 text-red-300";
  return "bg-yellow-900/40 text-yellow-300";
}

function formatLabel(value: string): string {
  return value.replace(/_/g, " ");
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 rounded bg-gray-950 px-3 py-2">
      <span className="text-gray-600">{label}</span>
      <p className="mt-1 truncate font-mono text-gray-400">{value}</p>
    </div>
  );
}
