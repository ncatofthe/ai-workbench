"""Tests for project_intake.py — deterministic project intake question generator.

Pure unit tests — no DB, no LLM, no network, no side effects.
"""

from __future__ import annotations

import asyncio
import inspect
import unittest

import src.orchestrator.project_intake as project_intake_module
from src.orchestrator.project_intake import (
    DevelopmentPlanPhaseStatus,
    DevelopmentPlanPreviewRequest,
    DevelopmentPlanPreviewResponse,
    MAX_TOTAL,
    ProjectBriefDraftRequest,
    ProjectBriefDraftResponse,
    ProjectBriefSectionStatus,
    ProjectIntakeMode,
    ProjectIntakeRequest,
    ProjectIntakeResponse,
    ProjectMaturityGoal,
    ProjectTargetType,
    QuestionCategory,
    QuestionPriority,
    analyze_project_intake,
    detect_intake_mode,
    detect_maturity_goal,
    detect_target_type,
    draft_development_plan,
    draft_project_brief,
)


class TestDetectIntakeMode(unittest.TestCase):
    """Mode detection — new vs existing project."""

    def test_explicit_mode_overrides_detection(self):
        req = ProjectIntakeRequest(idea="anything", mode=ProjectIntakeMode.EXISTING_PROJECT)
        self.assertEqual(detect_intake_mode(req), ProjectIntakeMode.EXISTING_PROJECT)

    def test_existing_project_attached_flag(self):
        req = ProjectIntakeRequest(idea="some idea", existing_project_attached=True)
        self.assertEqual(detect_intake_mode(req), ProjectIntakeMode.EXISTING_PROJECT)

    def test_existing_keyword_russian(self):
        req = ProjectIntakeRequest(idea="Уже есть проект на Django, нужно доработать")
        self.assertEqual(detect_intake_mode(req), ProjectIntakeMode.EXISTING_PROJECT)

    def test_existing_keyword_english(self):
        req = ProjectIntakeRequest(idea="I have an existing React app that needs refactoring")
        self.assertEqual(detect_intake_mode(req), ProjectIntakeMode.EXISTING_PROJECT)

    def test_existing_project_onboarding_phrases(self):
        phrases = [
            "у меня уже есть проект на Laravel",
            "полуготовый проект нужно довести до MVP",
            "продолжить разработку CRM",
            "доработать существующий проект",
            "загрузить папку проекта и продолжить",
            "existing project with a broken test suite",
            "continue an existing app",
        ]

        for phrase in phrases:
            with self.subTest(phrase=phrase):
                self.assertEqual(
                    detect_intake_mode(ProjectIntakeRequest(idea=phrase)),
                    ProjectIntakeMode.EXISTING_PROJECT,
                )

    def test_new_project_default(self):
        req = ProjectIntakeRequest(idea="Build a task management web app")
        self.assertEqual(detect_intake_mode(req), ProjectIntakeMode.NEW_PROJECT)


class TestDetectTargetType(unittest.TestCase):
    """Target type detection from idea text."""

    def test_web_app(self):
        self.assertEqual(detect_target_type("Build a React dashboard"), ProjectTargetType.WEB_APP)

    def test_mobile_app(self):
        self.assertEqual(detect_target_type("Flutter мобильное приложение"), ProjectTargetType.MOBILE_APP)

    def test_api_service(self):
        self.assertEqual(detect_target_type("Build a REST API microservice"), ProjectTargetType.API_SERVICE)

    def test_cli_tool(self):
        self.assertEqual(detect_target_type("Command-line utility for file processing"), ProjectTargetType.CLI_TOOL)

    def test_automation(self):
        self.assertEqual(detect_target_type("Telegram bot для уведомлений"), ProjectTargetType.AUTOMATION)

    def test_desktop(self):
        self.assertEqual(detect_target_type("Electron desktop app"), ProjectTargetType.DESKTOP_APP)

    def test_unknown(self):
        self.assertEqual(detect_target_type("I want to build something cool"), ProjectTargetType.UNKNOWN)


class TestDetectMaturityGoal(unittest.TestCase):
    """Maturity goal detection from idea text."""

    def test_mvp(self):
        self.assertEqual(detect_maturity_goal("Build an MVP for a startup"), ProjectMaturityGoal.MVP)

    def test_full_product(self):
        self.assertEqual(detect_maturity_goal("Full production system"), ProjectMaturityGoal.FULL_PRODUCT)

    def test_diploma(self):
        self.assertEqual(detect_maturity_goal("Дипломный проект для университета"), ProjectMaturityGoal.DIPLOMA)

    def test_prototype(self):
        self.assertEqual(detect_maturity_goal("Quick proof of concept demo"), ProjectMaturityGoal.PROTOTYPE)

    def test_internal_tool(self):
        self.assertEqual(detect_maturity_goal("Internal tool для команды"), ProjectMaturityGoal.INTERNAL_TOOL)

    def test_unknown(self):
        self.assertEqual(detect_maturity_goal("I want to build something"), ProjectMaturityGoal.UNKNOWN)


class TestAnalyzeProjectIntake(unittest.TestCase):
    """Full intake analysis — entry point tests."""

    def test_vague_idea_returns_many_questions_not_ready(self):
        """A vague idea should produce required questions and not be ready to plan."""
        resp = analyze_project_intake(ProjectIntakeRequest(idea="Хочу сделать что-то"))
        self.assertIsInstance(resp, ProjectIntakeResponse)
        self.assertFalse(resp.ready_to_plan)
        self.assertEqual(resp.confidence, "low")
        self.assertGreater(len(resp.questions), 3)
        required = [q for q in resp.questions if q.priority == QuestionPriority.REQUIRED]
        self.assertGreater(len(required), 0)

    def test_detailed_web_app_idea(self):
        """A detailed web app idea should detect type and have fewer missing fields."""
        idea = (
            "Build a React web dashboard with JWT auth, PostgreSQL database, "
            "file uploads to S3, Stripe billing, Tailwind design, "
            "deployed on AWS with full CI/CD pipeline. MVP version."
        )
        resp = analyze_project_intake(ProjectIntakeRequest(idea=idea))
        self.assertEqual(resp.detected_target_type, ProjectTargetType.WEB_APP)
        self.assertEqual(resp.detected_maturity_goal, ProjectMaturityGoal.MVP)
        self.assertEqual(resp.mode, ProjectIntakeMode.NEW_PROJECT)
        # Many signals detected → fewer missing items
        self.assertIn("Auth/login mentioned", " ".join(resp.assumptions))
        self.assertIn("Payments mentioned", " ".join(resp.assumptions))

    def test_existing_project_detection(self):
        """Existing project keywords should trigger existing mode questions."""
        resp = analyze_project_intake(
            ProjectIntakeRequest(idea="У меня уже есть Django проект, нужно продолжить разработку")
        )
        self.assertEqual(resp.mode, ProjectIntakeMode.EXISTING_PROJECT)
        self.assertFalse(resp.ready_to_plan)
        categories = {q.category for q in resp.questions}
        self.assertIn(QuestionCategory.EXISTING_PROJECT, categories)

    def test_existing_project_onboarding_questions_cover_core_context(self):
        resp = analyze_project_intake(
            ProjectIntakeRequest(idea="Доработать существующий проект, часть функций уже готова")
        )
        question_text = " ".join(q.question.lower() for q in resp.questions)

        self.assertEqual(resp.mode, ProjectIntakeMode.EXISTING_PROJECT)
        self.assertLessEqual(len(resp.questions), MAX_TOTAL)
        self.assertIn("where are the project files", question_text)
        self.assertIn("tech stack", question_text)
        self.assertIn("what already works", question_text)
        self.assertIn("broken", question_text)
        self.assertIn("next goal", question_text)
        self.assertIn("dev/build commands", question_text)
        self.assertIn("database", question_text)
        self.assertIn("environment variables", question_text)
        self.assertIn("git history", question_text)
        self.assertIn("not be modified", question_text)
        self.assertIn("tests exist", question_text)
        self.assertIn("deployment target", question_text)
        self.assertIn(".env", question_text)

    def test_bounded_question_count(self):
        """Total questions must never exceed MAX_TOTAL."""
        # Use a maximally signal-rich idea to trigger as many optional questions as possible
        idea = (
            "Build a React SPA web dashboard with JWT auth login, PostgreSQL database, "
            "S3 file upload photos, Stripe payment subscription billing, email notifications, "
            "external API integration Zapier webhook, pytest unit tests CI/CD, "
            "Docker deploy Kubernetes AWS, Figma design responsive Tailwind theme, "
            "MVP minimum viable product"
        )
        resp = analyze_project_intake(ProjectIntakeRequest(idea=idea))
        self.assertLessEqual(len(resp.questions), MAX_TOTAL)

    def test_known_stack_suppresses_stack_question(self):
        """Providing known_stack should suppress the tech stack question."""
        resp_no_stack = analyze_project_intake(
            ProjectIntakeRequest(idea="Build a web app")
        )
        resp_with_stack = analyze_project_intake(
            ProjectIntakeRequest(idea="Build a web app", known_stack=["React", "FastAPI"])
        )
        stack_qs_no = [q for q in resp_no_stack.questions if q.category == QuestionCategory.TECH_STACK]
        stack_qs_with = [q for q in resp_with_stack.questions if q.category == QuestionCategory.TECH_STACK]
        self.assertGreater(len(stack_qs_no), 0)
        self.assertEqual(len(stack_qs_with), 0)

    def test_signal_keywords_trigger_questions(self):
        """Signal keywords (payments, uploads) should trigger relevant questions."""
        resp = analyze_project_intake(
            ProjectIntakeRequest(idea="Web app with Stripe payment and file upload photos")
        )
        categories = {q.category for q in resp.questions}
        self.assertIn(QuestionCategory.PAYMENTS_BILLING, categories)
        self.assertIn(QuestionCategory.FILES_UPLOADS, categories)

    def test_response_serializes_to_json(self):
        """Pydantic model should serialize cleanly."""
        resp = analyze_project_intake(ProjectIntakeRequest(idea="A simple web app"))
        data = resp.model_dump()
        self.assertIn("mode", data)
        self.assertIn("questions", data)
        self.assertIn("ready_to_plan", data)
        self.assertIn("confidence", data)
        self.assertIn("summary", data)
        for q in data["questions"]:
            self.assertIn("id", q)
            self.assertIn("category", q)
            self.assertIn("priority", q)
            self.assertIn("question", q)
            self.assertIn("why_it_matters", q)

    def test_question_ids_are_unique(self):
        """Every question should have a unique ID."""
        resp = analyze_project_intake(ProjectIntakeRequest(idea="Build a React dashboard with auth"))
        ids = [q.id for q in resp.questions]
        self.assertEqual(len(ids), len(set(ids)))


class TestReadinessHeuristic(unittest.TestCase):
    """Test the ready_to_plan / confidence logic."""

    def test_very_detailed_idea_is_ready(self):
        """An extremely detailed idea with many signals should be ready to plan."""
        idea = (
            "Build an MVP React web dashboard with JWT authentication and role-based access control, "
            "PostgreSQL database for data storage, user file uploads with S3-compatible storage, "
            "responsive Tailwind CSS design with dark theme support, "
            "deployed locally first then to Docker containers on a VPS with CI/CD pipeline."
        )
        resp = analyze_project_intake(
            ProjectIntakeRequest(idea=idea, known_stack=["React", "FastAPI", "PostgreSQL"])
        )
        self.assertTrue(resp.ready_to_plan)
        self.assertEqual(resp.confidence, "high")

    def test_existing_project_never_ready(self):
        """Existing projects are never immediately ready (need answers)."""
        resp = analyze_project_intake(
            ProjectIntakeRequest(
                idea="I already have a React app with auth and PostgreSQL deployed on AWS",
                mode=ProjectIntakeMode.EXISTING_PROJECT,
                known_stack=["React", "FastAPI"],
            )
        )
        self.assertFalse(resp.ready_to_plan)
        self.assertEqual(resp.confidence, "low")


class TestMissingInformation(unittest.TestCase):
    """Missing information field correctness."""

    def test_vague_idea_has_missing_info(self):
        resp = analyze_project_intake(ProjectIntakeRequest(idea="Сделай приложение"))
        self.assertGreater(len(resp.missing_information), 0)

    def test_specific_idea_fewer_missing(self):
        idea = "React web app with JWT auth and PostgreSQL database for MVP"
        resp = analyze_project_intake(ProjectIntakeRequest(idea=idea))
        # Should not have "Target platform not specified"
        self.assertNotIn("Target platform not specified", resp.missing_information)
        self.assertNotIn("Auth requirements not mentioned", resp.missing_information)
        self.assertNotIn("Database/storage requirements not mentioned", resp.missing_information)


class TestProjectBriefDraft(unittest.TestCase):
    """Deterministic project brief draft generation."""

    def test_vague_idea_produces_missing_sections_and_open_questions(self):
        resp = draft_project_brief(ProjectBriefDraftRequest(idea="Сделай приложение"))

        self.assertIsInstance(resp, ProjectBriefDraftResponse)
        self.assertFalse(resp.ready_to_plan)
        self.assertEqual(resp.readiness, "needs_clarification")
        self.assertGreater(len(resp.open_questions), 0)
        self.assertLessEqual(len(resp.open_questions), MAX_TOTAL)
        self.assertTrue(any(section.status == ProjectBriefSectionStatus.MISSING for section in resp.sections))
        self.assertIn("## Open questions", resp.brief_markdown)

    def test_detailed_idea_produces_useful_sections(self):
        idea = (
            "Build an MVP React web dashboard with JWT auth, PostgreSQL database, "
            "Tailwind responsive UI, Docker deployment, and pytest CI checks."
        )
        resp = draft_project_brief(
            ProjectBriefDraftRequest(
                idea=idea,
                known_stack=["React", "FastAPI", "PostgreSQL"],
            )
        )

        titles = {section.title for section in resp.sections}
        self.assertIn("Product idea", titles)
        self.assertIn("Tech stack", titles)
        self.assertIn("Quality/testing", titles)
        self.assertTrue(resp.ready_to_plan)
        self.assertIn("React, FastAPI, PostgreSQL", resp.brief_markdown)
        self.assertIn("Project Brief Draft", resp.brief_markdown)

    def test_existing_project_wording_sets_existing_mode(self):
        resp = draft_project_brief(
            ProjectBriefDraftRequest(
                idea="I already have a Django project and need to continue development",
                known_stack=["Django", "PostgreSQL"],
            )
        )

        self.assertEqual(resp.mode, ProjectIntakeMode.EXISTING_PROJECT)
        self.assertFalse(resp.ready_to_plan)
        self.assertEqual(resp.readiness, "needs_clarification")

    def test_response_serializes(self):
        resp = draft_project_brief(ProjectBriefDraftRequest(idea="React web app with JWT auth and PostgreSQL database for MVP"))
        data = resp.model_dump()

        self.assertIn("brief_markdown", data)
        self.assertIn("sections", data)
        self.assertIn("open_questions", data)
        self.assertIn("ready_to_plan", data)

    def test_brief_draft_endpoint_returns_structured_response(self):
        from src.api import routes

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        resp = loop.run_until_complete(routes.post_project_intake_brief_draft(
            ProjectBriefDraftRequest(idea="React web app with JWT auth and PostgreSQL database for MVP")
        ))

        self.assertIsInstance(resp, ProjectBriefDraftResponse)
        self.assertIn("# Project Brief Draft", resp.brief_markdown)
        self.assertLessEqual(len(resp.open_questions), MAX_TOTAL)


class TestDevelopmentPlanPreview(unittest.TestCase):
    """Deterministic development plan preview generation."""

    def test_vague_new_project_not_ready_and_has_required_inputs(self):
        resp = draft_development_plan(DevelopmentPlanPreviewRequest(idea="Сделай приложение"))

        self.assertIsInstance(resp, DevelopmentPlanPreviewResponse)
        self.assertFalse(resp.ready_to_start)
        self.assertGreater(len(resp.required_inputs), 0)
        self.assertTrue(any(phase.status != DevelopmentPlanPhaseStatus.READY for phase in resp.phases))
        self.assertIn("product-manager", resp.recommended_agent_ids)

    def test_detailed_web_app_returns_meaningful_phases(self):
        idea = (
            "Build an MVP React web dashboard for admins and regular users with JWT auth, "
            "PostgreSQL database, Tailwind responsive UI, Docker deployment, and pytest CI checks."
        )
        resp = draft_development_plan(
            DevelopmentPlanPreviewRequest(
                idea=idea,
                known_stack=["React", "FastAPI", "PostgreSQL"],
                answers={"target_users": "Admins and regular users"},
            )
        )

        phase_ids = {phase.id for phase in resp.phases}
        self.assertTrue(resp.ready_to_start)
        self.assertIn("architecture-design", phase_ids)
        self.assertIn("backend-api", phase_ids)
        self.assertIn("frontend-ui", phase_ids)
        self.assertIn("auth-rbac", phase_ids)
        self.assertIn("testing-qa", phase_ids)
        self.assertIn("deployment", phase_ids)
        self.assertIn("documentation-final-report", phase_ids)
        self.assertIn("frontend-developer", resp.recommended_agent_ids)
        self.assertIn("backend-developer", resp.recommended_agent_ids)

    def test_existing_project_wording_returns_existing_project_phases(self):
        resp = draft_development_plan(
            DevelopmentPlanPreviewRequest(
                idea="I already have a Django project and need to continue development of billing",
                existing_project_attached=True,
                known_stack=["Django", "PostgreSQL"],
                user_goal="Continue billing feature development",
            )
        )

        phase_ids = {phase.id for phase in resp.phases}
        self.assertEqual(resp.mode, ProjectIntakeMode.EXISTING_PROJECT)
        self.assertIn("project-inventory", phase_ids)
        self.assertIn("stack-profile-detection", phase_ids)
        self.assertIn("safe-command-validation", phase_ids)
        self.assertIn("existing-code-risk-audit", phase_ids)
        self.assertIn("context-gathering", phase_ids)
        self.assertIn("patch-proposal-review", phase_ids)
        self.assertIn("manual-apply", phase_ids)
        self.assertIn("test-fix-loop", phase_ids)
        self.assertIn("final-verification-report", phase_ids)
        self.assertIn("qa-expert", resp.recommended_agent_ids)

    def test_response_serializes(self):
        resp = draft_development_plan(
            DevelopmentPlanPreviewRequest(idea="React web app with JWT auth and PostgreSQL database for MVP")
        )
        data = resp.model_dump()

        self.assertIn("phases", data)
        self.assertIn("required_inputs", data)
        self.assertIn("recommended_agent_ids", data)
        self.assertIn("source_readiness", data)

    def test_plan_preview_endpoint_returns_structured_response(self):
        from src.api import routes

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        resp = loop.run_until_complete(routes.post_project_intake_plan_preview(
            DevelopmentPlanPreviewRequest(idea="React web app with JWT auth and PostgreSQL database for MVP")
        ))

        self.assertIsInstance(resp, DevelopmentPlanPreviewResponse)
        self.assertGreater(len(resp.phases), 0)
        self.assertIn("testing-qa", {phase.id for phase in resp.phases})

    def test_intake_module_has_no_db_tool_provider_usage(self):
        source = inspect.getsource(project_intake_module)

        self.assertNotIn("src.storage", source)
        self.assertNotIn("src.project_tools", source)
        self.assertNotIn("src.providers", source)
        self.assertNotIn("create_run(", source)
        self.assertNotIn("create_project(", source)
        self.assertNotIn("create_tool_call(", source)


if __name__ == "__main__":
    unittest.main()
