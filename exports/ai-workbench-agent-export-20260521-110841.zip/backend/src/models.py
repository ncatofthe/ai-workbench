"""Core domain models for AI Workbench."""

from __future__ import annotations

import enum
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator


# ── Enums ────────────────────────────────────────────────────────────────────

class RunStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    WAITING_APPROVAL = "waiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


class ApprovalStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class ProviderType(str, enum.Enum):
    OLLAMA = "ollama"
    CODEX = "codex"
    CLAUDE = "claude"


class RunMode(str, enum.Enum):
    OFFLINE = "offline"
    HYBRID = "hybrid"
    CLOUD = "cloud"


class ProviderMode(str, enum.Enum):
    LOCAL = "local"
    HYBRID = "hybrid"
    CLOUD = "cloud"


# ── Models ───────────────────────────────────────────────────────────────────

class Project(BaseModel):
    id: str = Field(default="")
    name: str
    path: str = ""
    description: str = ""
    stack: str = ""
    package_manager: str = ""
    test_command: str = ""
    build_command: str = ""
    safe_commands: list[str] = Field(default_factory=list)
    blocked_commands: list[str] = Field(default_factory=list)
    ignore_paths: list[str] = Field(default_factory=list)
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str | None = None


class AgentInfo(BaseModel):
    id: str
    name: str
    role: str
    description: str
    provider: ProviderType = ProviderType.OLLAMA
    instructions_file: str = ""
    category: str = "core-development"
    skills: list[str] = Field(default_factory=list)
    default_tools: list[str] = Field(default_factory=list)
    model_profile: str = "planning_reasoning"
    default_model: str = ""
    fast_model: str = ""
    reasoning_model: str = ""
    can_edit_files: bool = False
    can_run_commands: bool = False
    risk_level: str = "low"
    enabled: bool = True
    best_for: list[str] = Field(default_factory=list)


class Task(BaseModel):
    id: str = Field(default="")
    project_id: str = ""
    prompt: str
    mode: RunMode = RunMode.OFFLINE
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())


class Run(BaseModel):
    id: str = Field(default="")
    task_id: str = ""
    project_id: str = ""
    project_path: str = ""
    current_step_id: str = ""
    agent_id: str = ""
    status: RunStatus = RunStatus.PENDING
    mode: RunMode = RunMode.OFFLINE
    prompt: str = ""
    plan: str = ""
    result: str = ""
    logs: list[str] = Field(default_factory=list)
    artifacts: list[str] = Field(default_factory=list)
    run_dir: str = ""
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    finished_at: str | None = None


class ApprovalRequest(BaseModel):
    id: str = Field(default="")
    run_id: str
    action: str
    command: str = ""
    description: str = ""
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    resolved_at: str | None = None


class RunStep(BaseModel):
    id: str = Field(default="")
    run_id: str
    parent_step_id: str = ""
    agent_id: str = ""
    status: str = RunStatus.PENDING.value
    title: str
    input: str = ""
    output: str = ""
    error: str = ""
    started_at: str = ""
    finished_at: str = ""
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())


class ToolCall(BaseModel):
    id: str = Field(default="")
    run_id: str = ""
    project_id: str = ""
    step_id: str = ""
    tool_name: str
    command: str = ""
    cwd: str = ""
    status: str = ""
    approval_id: str = ""
    stdout: str = ""
    stderr: str = ""
    returncode: int | None = None
    report_path: str = ""
    started_at: str = ""
    finished_at: str = ""
    input_json: str = ""
    output_json: str = ""
    error: str = ""
    risk_level: str = "low"
    completed_at: str | None = None
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())

    @field_validator(
        "run_id",
        "project_id",
        "step_id",
        "command",
        "cwd",
        "status",
        "approval_id",
        "stdout",
        "stderr",
        "report_path",
        "started_at",
        "finished_at",
        "input_json",
        "output_json",
        "error",
        "risk_level",
        mode="before",
    )
    @classmethod
    def _empty_string_for_null(cls, value: object) -> object:
        return "" if value is None else value


class RunAgentAssignment(BaseModel):
    id: str = Field(default="")
    run_id: str
    agent_id: str
    assigned_role: str = ""
    reason: str = ""
    confidence: float = 0.0
    status: str = "selected"
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())


class AgentSelectionResult(BaseModel):
    selected_agents: list[RunAgentAssignment] = Field(default_factory=list)
    team_size: int = 0
    recommended_execution_mode: RunMode = RunMode.OFFLINE
    detected_stack: list[str] = Field(default_factory=list)
    signals: dict[str, Any] = Field(default_factory=dict)


class Artifact(BaseModel):
    id: str = Field(default="")
    run_id: str
    name: str
    path: str
    artifact_type: str = "file"
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())


class ModelProvider(BaseModel):
    name: ProviderType
    enabled: bool = True
    base_url: str = ""
    default_model: str = ""
    config: dict[str, Any] = Field(default_factory=dict)


class ModelRegistryItem(BaseModel):
    id: str
    provider: str
    display_name: str
    family: str
    capabilities: list[str] = Field(default_factory=list)
    context_window: int = 0
    memory_tier: str = "small"
    recommended_for: list[str] = Field(default_factory=list)
    installed: bool = False
    enabled: bool = True
    max_parallel: int = 1
    notes: str = ""


class ModelProfile(BaseModel):
    id: str
    primary_model: str
    fast_model: str = ""
    reasoning_model: str = ""
    fallback_model: str = ""
    allowed_providers: list[str] = Field(default_factory=list)
    preferred_provider: str = "local_ollama"
    max_parallel: int = 1
    local_only_default: bool = True
    description: str = ""


class ProviderInfo(BaseModel):
    id: str
    display_name: str
    kind: str
    enabled: bool = False
    available: bool = False
    local: bool = False
    requires_approval: bool = True
    supports_execution: bool = False
    modes: list[ProviderMode] = Field(default_factory=list)
    notes: str = ""


class ProviderStatus(BaseModel):
    id: str
    enabled: bool
    available: bool
    status: str
    models: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class ModelRouteRequest(BaseModel):
    agent_id: str = ""
    task_type: str = "planning"
    model_profile: str = ""
    provider_mode: ProviderMode = ProviderMode.LOCAL
    available_models: list[str] = Field(default_factory=list)
    project_privacy_level: str = "private"
    hardware_memory_gb: float | None = None
    user_preference_model: str = ""
    user_preference_provider: str = ""


class ModelRouteResult(BaseModel):
    selected_model: str
    selected_provider: str
    fallback_model: str = ""
    reason: str
    confidence: float
    warnings: list[str] = Field(default_factory=list)
    model_profile: str = ""
    task_type: str = ""


class ModelRouteDecision(BaseModel):
    id: str = Field(default="")
    run_id: str
    step_id: str | None = None
    agent_id: str
    task_type: str
    model_profile: str
    selected_model: str
    selected_provider: str
    fallback_model: str = ""
    fallback_provider: str | None = None
    provider_mode: ProviderMode = ProviderMode.LOCAL
    reason: str
    confidence: float
    warnings: list[str] = Field(default_factory=list)
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str | None = None


class ModelRouteDecisionResponse(BaseModel):
    run_id: str
    count: int
    persisted: bool = False
    decisions: list[ModelRouteDecision] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class ProviderModeUpdate(BaseModel):
    provider_mode: ProviderMode


# ── API Schemas ──────────────────────────────────────────────────────────────

class CreateProjectRequest(BaseModel):
    name: str
    path: str
    description: str = ""
    stack: str = ""
    package_manager: str = ""
    test_command: str = ""
    build_command: str = ""
    safe_commands: list[str] = Field(default_factory=list)
    blocked_commands: list[str] = Field(default_factory=list)
    ignore_paths: list[str] = Field(default_factory=list)


class UpdateProjectRequest(BaseModel):
    name: str | None = None
    path: str | None = None
    description: str | None = None
    stack: str | None = None
    package_manager: str | None = None
    test_command: str | None = None
    build_command: str | None = None
    safe_commands: list[str] | None = None
    blocked_commands: list[str] | None = None
    ignore_paths: list[str] | None = None


class CreateRunRequest(BaseModel):
    prompt: str
    project_id: str = ""
    project_path: str = ""
    mode: RunMode = RunMode.OFFLINE


class ApprovalDecision(BaseModel):
    reason: str = ""


class ToolContextRequest(BaseModel):
    run_id: str = ""
    step_id: str = ""
    agent_id: str = ""


class ListFilesRequest(ToolContextRequest):
    path: str = "."
    max_files: int = 500


class ReadFileRequest(ToolContextRequest):
    path: str
    max_chars: int = 200_000


class SearchCodeRequest(ToolContextRequest):
    query: str
    path: str = "."
    max_results: int = 100


class PatchOperation(BaseModel):
    file_path: str
    old_text: str = ""
    new_text: str = ""
    create_if_missing: bool = False
    replace_all: bool = False


class ProposePatchRequest(ToolContextRequest):
    operations: list[PatchOperation] = Field(default_factory=list)


class ProposedPatchFile(BaseModel):
    path: str
    status: str
    diff: str = ""
    error: str = ""


class ProposePatchResponse(BaseModel):
    files: list[ProposedPatchFile] = Field(default_factory=list)
    summary: str = ""
    warnings: list[str] = Field(default_factory=list)
    proposal_id: str = ""


class ApplyPatchRequest(ToolContextRequest):
    operations: list[PatchOperation] = Field(default_factory=list)
    confirm: bool = False
    expected_summary: str = ""
    proposal_id: str = ""


class AppliedPatchFile(BaseModel):
    path: str
    status: str
    error: str = ""


class ApplyPatchResponse(BaseModel):
    files: list[AppliedPatchFile] = Field(default_factory=list)
    summary: str = ""
    git_status: str = ""
    git_diff_stat: str = ""
    warnings: list[str] = Field(default_factory=list)
    applied_from_proposal_id: str = ""


class RollbackPatchRequest(ToolContextRequest):
    tool_call_id: str
    confirm: bool = False


class RolledBackFile(BaseModel):
    path: str
    operation: str  # "modified" | "created"
    status: str     # "restored" | "deleted" | "skipped" | "conflict" | "error"
    reason: str = ""


class RollbackPatchResponse(BaseModel):
    rolled_back_files: list[RolledBackFile] = Field(default_factory=list)
    skipped_files: list[RolledBackFile] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    git_status: str = ""
    git_diff_stat: str = ""
    tool_call_id: str = ""


class UpdateRunAgentAssignmentRequest(BaseModel):
    assigned_role: str | None = None
    reason: str | None = None
    confidence: float | None = None
    status: str | None = None


# ── Orchestrator Tool Planning ────────────────────────────────────────────────

class StepToolRecommendation(BaseModel):
    step_id: str
    agent_id: str = ""
    task_type: str = ""
    recommended_tools: list[str] = Field(default_factory=list)
    reason: str = ""
    confidence: float = 1.0
    warnings: list[str] = Field(default_factory=list)


class StepToolPlanResponse(BaseModel):
    run_id: str
    recommendations: list[StepToolRecommendation] = Field(default_factory=list)
    summary: str = ""
    warnings: list[str] = Field(default_factory=list)


# ── Orchestrator Guided Execution ─────────────────────────────────────────────

class GuidedStepAction(BaseModel):
    step_id: str
    action_id: str                     # unique identifier within the plan
    action_type: str                   # read_context | search_code | propose_patch |
                                       # apply_patch | run_tests | analyze_result |
                                       # review_diff | rollback_patch | done
    tool_name: str = ""                # mapped project tool, if any
    title: str
    description: str = ""
    reason: str = ""
    requires_confirmation: bool = False
    risk_level: str = "low"            # low | medium | high
    enabled: bool = True
    blocked_reason: str = ""
    related_tool_call_id: str = ""
    related_proposal_id: str = ""


class GuidedStepExecutionPlan(BaseModel):
    run_id: str
    step_id: str
    agent_id: str = ""
    task_type: str = ""
    recommended_next_action: GuidedStepAction | None = None
    actions: list[GuidedStepAction] = Field(default_factory=list)
    status_summary: str = ""
    warnings: list[str] = Field(default_factory=list)


class GuidedExecutionPlanResponse(BaseModel):
    run_id: str
    steps: list[GuidedStepExecutionPlan] = Field(default_factory=list)
    summary: str = ""
    warnings: list[str] = Field(default_factory=list)


class ClarificationAnswerRequest(BaseModel):
    answers: str


# ── Safe Auto Read/Search ─────────────────────────────────────────────────────

# Only these action types are permitted for auto-execution.
AUTO_READ_ALLOWED_ACTIONS: frozenset[str] = frozenset({
    "list_files",
    "read_file",
    "search_code",
})

# Explicitly blocked — these must never be auto-executed.
AUTO_READ_BLOCKED_ACTIONS: frozenset[str] = frozenset({
    "propose_patch",
    "apply_patch",
    "rollback_patch",
    "run_command",
    "analyze_result",
    "run_tests",
})


class AutoStepReadRequest(BaseModel):
    step_id: str
    action_type: str          # list_files | read_file | search_code
    query: str = ""           # for search_code
    file_path: str = ""       # for read_file
    limit: int = 100          # max_results / max_files
    run_id: str = ""
    agent_id: str = ""


class AutoStepReadResponse(BaseModel):
    run_id: str
    step_id: str
    action_type: str
    tool_call_id: str
    status: str               # completed | failed | blocked
    summary: str = ""
    result: dict = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


# ── Auto Context Gathering ────────────────────────────────────────────────────

AUTO_CONTEXT_MAX_HARD_CAP: int = 8
AUTO_CONTEXT_DEFAULT_MAX: int = 5


class AutoContextGatherRequest(BaseModel):
    max_tool_calls: int = AUTO_CONTEXT_DEFAULT_MAX
    query: str = ""
    include_file_patterns: list[str] = Field(default_factory=list)
    exclude_file_patterns: list[str] = Field(default_factory=list)
    agent_id: str = ""


class AutoContextGatheredFile(BaseModel):
    file_path: str
    reason: str
    source_tool_call_id: str = ""


class AutoContextGatherResponse(BaseModel):
    run_id: str
    step_id: str
    status: str                    # completed | partial | failed
    summary: str = ""
    tool_call_ids: list[str] = Field(default_factory=list)
    searched_queries: list[str] = Field(default_factory=list)
    files_considered: list[str] = Field(default_factory=list)
    files_read: list[AutoContextGatheredFile] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    next_recommended_action: str = ""


# ── Step Context Bundle ───────────────────────────────────────────────────────

# Limits to keep responses lean
BUNDLE_MAX_FILES: int = 5
BUNDLE_MAX_SNIPPETS_PER_FILE: int = 3
BUNDLE_MAX_SNIPPET_CHARS: int = 800


class StepContextFile(BaseModel):
    file_path: str
    source_tool_call_ids: list[str] = Field(default_factory=list)
    reason: str | None = None
    snippets: list[str] = Field(default_factory=list)
    read: bool = False
    match_count: int = 0


class StepContextBundle(BaseModel):
    run_id: str
    step_id: str
    agent_id: str | None = None
    task_type: str | None = None
    status: str                    # ok | partial | empty
    summary: str = ""
    queries: list[str] = Field(default_factory=list)
    files: list[StepContextFile] = Field(default_factory=list)
    tool_call_ids: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    next_recommended_action: str | None = None


class StepContextBundleResponse(BaseModel):
    bundle: StepContextBundle


# ── Agent-assisted Patch Proposal from Context ────────────────────────────────

DRAFT_PLACEHOLDER_NEW_TEXT: str = "TODO: replace with intended change"
DRAFT_MAX_OLD_TEXT_CHARS: int = 1200


class ContextPatchDraftRequest(BaseModel):
    preferred_file_path: str | None = None
    preferred_snippet_index: int | None = None
    intent: str | None = None
    agent_id: str | None = None


class ContextPatchDraftCandidate(BaseModel):
    file_path: str
    old_text: str
    new_text: str
    reason: str
    confidence: float
    source_tool_call_ids: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class ContextPatchDraftResponse(BaseModel):
    run_id: str
    step_id: str
    status: str                        # ok | no_context | partial
    summary: str = ""
    candidates: list[ContextPatchDraftCandidate] = Field(default_factory=list)
    recommended_candidate_index: int | None = None
    warnings: list[str] = Field(default_factory=list)
    next_recommended_action: str | None = None


# ── Patch Proposal Review ────────────────────────────────────────────────────

class PatchReviewOperation(BaseModel):
    file_path: str
    old_text: str = ""
    new_text: str = ""


class PatchReviewRequest(BaseModel):
    operations: list[PatchReviewOperation] = Field(default_factory=list)
    run_id: str | None = None
    step_id: str | None = None
    agent_id: str | None = None


class PatchReviewIssue(BaseModel):
    severity: str               # "info" | "warning" | "blocker"
    code: str
    message: str
    file_path: str | None = None
    operation_index: int | None = None


class PatchReviewOperationResult(BaseModel):
    operation_index: int
    file_path: str
    status: str                 # "ok" | "warning" | "blocked"
    old_text_found: bool = False
    old_text_occurrences: int = 0
    estimated_diff_lines: int = 0
    issues: list[PatchReviewIssue] = Field(default_factory=list)


class PatchReviewResponse(BaseModel):
    status: str                 # "ok" | "warning" | "blocked"
    summary: str = ""
    operation_results: list[PatchReviewOperationResult] = Field(default_factory=list)
    issues: list[PatchReviewIssue] = Field(default_factory=list)
    safe_to_create_proposal: bool = False
    safe_to_apply: bool = False


# ── Approval-gated Patch Workflow Orchestrator ────────────────────────────────

class PatchWorkflowStage(BaseModel):
    stage_id: str
    title: str
    status: str             # "not_started" | "ready" | "blocked" | "completed" | "warning"
    summary: str = ""
    related_tool_call_ids: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    blockers: list[str] = Field(default_factory=list)


class PatchWorkflowNextAction(BaseModel):
    action_type: str        # auto_gather_context | build_context_bundle | create_patch_draft |
                            # review_patch | create_proposal | apply_patch_manual |
                            # run_tests_manual | analyze_result | rollback_manual | done
    title: str
    description: str
    risk_level: str         # "low" | "medium" | "high"
    requires_confirmation: bool = False
    enabled: bool = True
    blocked_reason: str | None = None


class StepPatchWorkflowPlan(BaseModel):
    run_id: str
    step_id: str
    agent_id: str | None = None
    task_type: str | None = None
    status: str             # "not_started" | "in_progress" | "blocked" | "ready_for_review" | "ready_for_tests" | "done"
    summary: str = ""
    stages: list[PatchWorkflowStage] = Field(default_factory=list)
    recommended_next_action: PatchWorkflowNextAction | None = None
    warnings: list[str] = Field(default_factory=list)
    blockers: list[str] = Field(default_factory=list)


class PatchWorkflowPlanResponse(BaseModel):
    run_id: str
    steps: list[StepPatchWorkflowPlan] = Field(default_factory=list)
    summary: str = ""
    warnings: list[str] = Field(default_factory=list)


# ── Config ────────────────────────────────────────────────────────────────────

class ConfigUpdate(BaseModel):
    default_mode: RunMode | None = None
    provider_mode: ProviderMode | None = None
    ollama_base_url: str | None = None
    ollama_model: str | None = None
    codex_enabled: bool | None = None
    claude_enabled: bool | None = None


# ── Safe Test Command Runner ──────────────────────────────────────────────────

class ProjectCommandKind(str, enum.Enum):
    TEST = "test"
    BUILD = "build"
    LINT = "lint"
    TYPECHECK = "typecheck"


class RunProjectCommandRequest(BaseModel):
    command_kind: ProjectCommandKind
    run_id: str = ""
    step_id: str = ""
    agent_id: str = ""
    timeout_seconds: int = 120


class RunProjectCommandResponse(BaseModel):
    command_kind: str
    command: str
    cwd: str
    returncode: int
    stdout: str
    stderr: str
    duration_ms: int
    timed_out: bool
    tool_call_id: str = ""


# ── Test Result Analysis ──────────────────────────────────────────────────────

class CommandIssue(BaseModel):
    kind: str  # test_failure | assertion_error | traceback | type_error | lint_error | build_error | timeout | unknown
    file_path: str | None = None
    line: int | None = None
    message: str = ""
    raw_excerpt: str = ""


class CommandAnalysisRequest(BaseModel):
    tool_call_id: str = ""
    stdout: str = ""
    stderr: str = ""
    returncode: int | None = None
    command_kind: str = ""
    run_id: str = ""
    step_id: str = ""
    agent_id: str = ""


class CommandAnalysisResponse(BaseModel):
    status: str  # passed | failed | timed_out | unknown
    summary: str
    issues: list[CommandIssue] = Field(default_factory=list)
    suggested_next_actions: list[str] = Field(default_factory=list)
    can_create_fix_proposal: bool = False
    source_tool_call_id: str = ""
