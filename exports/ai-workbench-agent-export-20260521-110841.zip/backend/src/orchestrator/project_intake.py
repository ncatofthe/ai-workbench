"""Project intake question generator for AI Workbench.

Pure deterministic module — no DB access, no LLM calls, no tool execution,
no side effects.  Accepts a raw project idea and returns structured questions
the operator should answer before plan generation begins.
"""

from __future__ import annotations

import enum
import re
import uuid
from typing import Optional

from pydantic import BaseModel, Field


# ── Enums ────────────────────────────────────────────────────────────────────


class ProjectIntakeMode(str, enum.Enum):
    NEW_PROJECT = "new_project"
    EXISTING_PROJECT = "existing_project"
    UNKNOWN = "unknown"


class ProjectTargetType(str, enum.Enum):
    WEB_APP = "web_app"
    MOBILE_APP = "mobile_app"
    DESKTOP_APP = "desktop_app"
    API_SERVICE = "api_service"
    CLI_TOOL = "cli_tool"
    AUTOMATION = "automation"
    UNKNOWN = "unknown"


class ProjectMaturityGoal(str, enum.Enum):
    MVP = "mvp"
    FULL_PRODUCT = "full_product"
    DIPLOMA = "diploma"
    PROTOTYPE = "prototype"
    INTERNAL_TOOL = "internal_tool"
    UNKNOWN = "unknown"


class QuestionCategory(str, enum.Enum):
    PRODUCT_GOAL = "product_goal"
    USERS_ROLES = "users_roles"
    PLATFORM = "platform"
    TECH_STACK = "tech_stack"
    DATA_STORAGE = "data_storage"
    AUTH_SECURITY = "auth_security"
    INTEGRATIONS = "integrations"
    FILES_UPLOADS = "files_uploads"
    PAYMENTS_BILLING = "payments_billing"
    NOTIFICATIONS = "notifications"
    UI_DESIGN = "ui_design"
    DEPLOYMENT = "deployment"
    EXISTING_PROJECT = "existing_project"
    CONSTRAINTS = "constraints"
    QUALITY_TESTING = "quality_testing"


class QuestionPriority(str, enum.Enum):
    REQUIRED = "required"
    RECOMMENDED = "recommended"
    OPTIONAL = "optional"


class ProjectBriefSectionStatus(str, enum.Enum):
    CONFIRMED = "confirmed"
    ASSUMED = "assumed"
    MISSING = "missing"


# ── Models ───────────────────────────────────────────────────────────────────


class ProjectIntakeQuestion(BaseModel):
    id: str = Field(default_factory=lambda: f"q-{uuid.uuid4().hex[:8]}")
    category: QuestionCategory
    priority: QuestionPriority
    question: str
    why_it_matters: str
    suggested_default: Optional[str] = None
    options: Optional[list[str]] = None


class ProjectIntakeRequest(BaseModel):
    idea: str
    mode: Optional[ProjectIntakeMode] = None
    existing_project_attached: Optional[bool] = None
    known_stack: Optional[list[str]] = None
    known_constraints: Optional[list[str]] = None
    user_goal: Optional[str] = None


class ProjectIntakeResponse(BaseModel):
    mode: ProjectIntakeMode
    detected_target_type: ProjectTargetType
    detected_maturity_goal: ProjectMaturityGoal
    summary: str
    assumptions: list[str] = Field(default_factory=list)
    missing_information: list[str] = Field(default_factory=list)
    questions: list[ProjectIntakeQuestion] = Field(default_factory=list)
    ready_to_plan: bool = False
    recommended_next_step: str = ""
    confidence: str = "low"


class ProjectBriefSection(BaseModel):
    title: str
    content: str
    status: ProjectBriefSectionStatus
    notes: Optional[str] = None


class ProjectBriefDraftRequest(ProjectIntakeRequest):
    answers: Optional[dict[str, str]] = None


class ProjectBriefDraftResponse(BaseModel):
    title: str
    mode: ProjectIntakeMode
    target_type: ProjectTargetType
    maturity_goal: ProjectMaturityGoal
    readiness: str
    summary: str
    brief_markdown: str
    sections: list[ProjectBriefSection] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    missing_information: list[str] = Field(default_factory=list)
    open_questions: list[ProjectIntakeQuestion] = Field(default_factory=list)
    recommended_next_step: str = ""
    ready_to_plan: bool = False


class DevelopmentPlanPhaseStatus(str, enum.Enum):
    READY = "ready"
    NEEDS_INPUT = "needs_input"
    BLOCKED = "blocked"


class DevelopmentPlanPhase(BaseModel):
    id: str
    title: str
    description: str
    priority: QuestionPriority
    status: DevelopmentPlanPhaseStatus
    suggested_agent_id: Optional[str] = None
    depends_on: list[str] = Field(default_factory=list)
    deliverables: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


class DevelopmentPlanSourceReadiness(BaseModel):
    intake_ready_to_plan: bool
    brief_ready_to_plan: bool


class DevelopmentPlanPreviewRequest(ProjectBriefDraftRequest):
    brief_markdown: Optional[str] = None


class DevelopmentPlanPreviewResponse(BaseModel):
    title: str
    mode: ProjectIntakeMode
    target_type: ProjectTargetType
    maturity_goal: ProjectMaturityGoal
    ready_to_start: bool
    summary: str
    phases: list[DevelopmentPlanPhase] = Field(default_factory=list)
    required_inputs: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    recommended_agent_ids: list[str] = Field(default_factory=list)
    recommended_next_step: str = ""
    source_readiness: DevelopmentPlanSourceReadiness


# ── Keyword detection helpers ────────────────────────────────────────────────

_LOWER = re.IGNORECASE

_EXISTING_PROJECT_PATTERNS = [
    re.compile(
        r"(у\s+меня\s+уже\s+есть|уже\s+есть|полуготов|существующ|загрузить\s+папк|"
        r"existing\s+project|existing\s+app|continue\s+an\s+existing|already\s+have|"
        r"continue|продолж|доработ|refactor|мигрир|legacy|перепис)",
        _LOWER,
    ),
]

_TARGET_TYPE_KEYWORDS: dict[ProjectTargetType, list[re.Pattern[str]]] = {
    ProjectTargetType.WEB_APP: [re.compile(r"(web|сайт|dashboard|spa|react|vue|angular|frontend|landing|portal|crm|erp|cms)", _LOWER)],
    ProjectTargetType.MOBILE_APP: [re.compile(r"(mobile|ios|android|flutter|react.native|мобильн|приложени)", _LOWER)],
    ProjectTargetType.DESKTOP_APP: [re.compile(r"(desktop|electron|tauri|gtk|qt|настольн)", _LOWER)],
    ProjectTargetType.API_SERVICE: [re.compile(r"(api|microservice|rest|graphql|grpc|backend.only|сервис|бэкенд)", _LOWER)],
    ProjectTargetType.CLI_TOOL: [re.compile(r"(cli|command.line|terminal|консол|утилит|скрипт)", _LOWER)],
    ProjectTargetType.AUTOMATION: [re.compile(r"(automat|бот|scraper|pipeline|cron|scheduler|парсер|telegram.bot)", _LOWER)],
}

_MATURITY_KEYWORDS: dict[ProjectMaturityGoal, list[re.Pattern[str]]] = {
    ProjectMaturityGoal.MVP: [re.compile(r"(mvp|minimum.viable|минимальн|быстр|простой.вариант)", _LOWER)],
    ProjectMaturityGoal.FULL_PRODUCT: [re.compile(r"(full|production|продакшн|полноценн|масштаб)", _LOWER)],
    ProjectMaturityGoal.DIPLOMA: [re.compile(r"(диплом|курсов|thesis|universit|учебн)", _LOWER)],
    ProjectMaturityGoal.PROTOTYPE: [re.compile(r"(prototype|прототип|proof.of.concept|poc|демо)", _LOWER)],
    ProjectMaturityGoal.INTERNAL_TOOL: [re.compile(r"(internal|внутренн|для.команды|для.себя|in.house)", _LOWER)],
}

_SIGNAL_KEYWORDS: dict[str, list[re.Pattern[str]]] = {
    "auth": [re.compile(r"(auth|login|регистрац|пользовател|роли|rbac|jwt|oauth|sso)", _LOWER)],
    "payments": [re.compile(r"(pay|billing|оплат|подписк|stripe|платёж|invoice|subscription)", _LOWER)],
    "uploads": [re.compile(r"(upload|file|загруз|файл|image|photo|s3|storage|фото)", _LOWER)],
    "notifications": [re.compile(r"(notif|email|sms|push|уведомлен|рассылк|webhook)", _LOWER)],
    "integrations": [re.compile(r"(integrat|api.extern|third.party|внешн|интеграц|zapier|webhook)", _LOWER)],
    "database": [re.compile(r"(database|postgres|mysql|mongo|sqlite|redis|бд|база.данн|хранени)", _LOWER)],
    "testing": [re.compile(r"(test|pytest|jest|ci.cd|тест|quality|lint)", _LOWER)],
    "deployment": [re.compile(r"(deploy|docker|k8s|kubernetes|vercel|heroku|aws|деплой|хостинг|vps)", _LOWER)],
    "ui": [re.compile(r"(ui|design|figma|tailwind|дизайн|макет|responsive|тема)", _LOWER)],
}


def _text_matches(text: str, patterns: list[re.Pattern[str]]) -> bool:
    return any(p.search(text) for p in patterns)


def _detect_signals(text: str) -> set[str]:
    return {key for key, pats in _SIGNAL_KEYWORDS.items() if _text_matches(text, pats)}


# ── Mode detection ───────────────────────────────────────────────────────────


def detect_intake_mode(req: ProjectIntakeRequest) -> ProjectIntakeMode:
    if req.mode is not None:
        return req.mode
    if req.existing_project_attached:
        return ProjectIntakeMode.EXISTING_PROJECT
    text = req.idea.lower()
    if any(p.search(text) for p in _EXISTING_PROJECT_PATTERNS):
        return ProjectIntakeMode.EXISTING_PROJECT
    return ProjectIntakeMode.NEW_PROJECT


def detect_target_type(text: str) -> ProjectTargetType:
    for target, patterns in _TARGET_TYPE_KEYWORDS.items():
        if _text_matches(text, patterns):
            return target
    return ProjectTargetType.UNKNOWN


def detect_maturity_goal(text: str) -> ProjectMaturityGoal:
    for goal, patterns in _MATURITY_KEYWORDS.items():
        if _text_matches(text, patterns):
            return goal
    return ProjectMaturityGoal.UNKNOWN


# ── Question bank ────────────────────────────────────────────────────────────


def _new_project_questions(text: str, signals: set[str], known_stack: list[str]) -> list[ProjectIntakeQuestion]:
    """Generate questions for a new project idea."""
    qs: list[ProjectIntakeQuestion] = []

    # Required core questions
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.PRODUCT_GOAL,
        priority=QuestionPriority.REQUIRED,
        question="What is the main goal of this product? What problem does it solve?",
        why_it_matters="Defines scope and priorities for the plan.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.USERS_ROLES,
        priority=QuestionPriority.REQUIRED,
        question="Who are the users? Are there different roles (admin, regular user, manager)?",
        why_it_matters="Drives auth, permissions, and UI structure.",
        suggested_default="Admin + regular user",
        options=["Single user", "Admin + regular user", "Multi-role (3+)", "Public (no auth)"],
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.PLATFORM,
        priority=QuestionPriority.REQUIRED,
        question="What platform should this run on?",
        why_it_matters="Determines tech stack and architecture.",
        suggested_default="Web app",
        options=["Web app", "Mobile app", "Desktop app", "API/backend only", "CLI tool", "Bot/automation"],
    ))

    if not known_stack:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.TECH_STACK,
            priority=QuestionPriority.REQUIRED,
            question="Do you have a preferred tech stack, or should we choose one?",
            why_it_matters="Affects all implementation decisions.",
            suggested_default="React + FastAPI + SQLite (local prototype)",
            options=["React + FastAPI", "Next.js + Node", "Vue + Django", "Let the system choose"],
        ))

    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.CONSTRAINTS,
        priority=QuestionPriority.REQUIRED,
        question="Is this an MVP/prototype or a full production product?",
        why_it_matters="Defines depth of implementation and quality requirements.",
        suggested_default="MVP",
        options=["MVP / prototype", "Full product", "Diploma / academic", "Internal tool"],
    ))

    # Recommended questions based on missing signals
    if "database" not in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.DATA_STORAGE,
            priority=QuestionPriority.RECOMMENDED,
            question="What data needs to be stored? Any preference for database type?",
            why_it_matters="Determines persistence layer and data model.",
            suggested_default="SQLite for prototype, PostgreSQL for production",
        ))

    if "auth" not in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.AUTH_SECURITY,
            priority=QuestionPriority.RECOMMENDED,
            question="Does the app need authentication and authorization?",
            why_it_matters="Affects security architecture and user management.",
            suggested_default="JWT/session auth with admin/user roles",
            options=["No auth needed", "Simple login", "Role-based access", "OAuth/SSO"],
        ))

    if "ui" not in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.UI_DESIGN,
            priority=QuestionPriority.RECOMMENDED,
            question="Any design requirements? Figma mockups, brand colors, responsive?",
            why_it_matters="Guides frontend implementation approach.",
            suggested_default="Clean default theme, responsive, no custom design",
        ))

    if "deployment" not in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.DEPLOYMENT,
            priority=QuestionPriority.RECOMMENDED,
            question="Where should this be deployed?",
            why_it_matters="Affects infrastructure and CI/CD decisions.",
            suggested_default="Local development first",
            options=["Local dev only", "VPS / self-hosted", "Cloud (AWS/GCP/Azure)", "Vercel/Heroku/Railway"],
        ))

    # Optional questions triggered by signal keywords
    if "payments" in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.PAYMENTS_BILLING,
            priority=QuestionPriority.RECOMMENDED,
            question="What payment features are needed? Subscriptions, one-time, invoicing?",
            why_it_matters="Payment integration is complex and affects data model.",
            options=["One-time payments", "Subscriptions", "Invoicing", "Not sure yet"],
        ))

    if "uploads" in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.FILES_UPLOADS,
            priority=QuestionPriority.OPTIONAL,
            question="What types of files will users upload? Size limits?",
            why_it_matters="Affects storage strategy and backend configuration.",
            suggested_default="Images up to 10MB, local storage for prototype",
        ))

    if "notifications" in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.NOTIFICATIONS,
            priority=QuestionPriority.OPTIONAL,
            question="What notification channels are needed?",
            why_it_matters="Adds integration complexity.",
            options=["Email only", "Email + push", "SMS", "In-app only"],
        ))

    if "integrations" in signals:
        qs.append(ProjectIntakeQuestion(
            category=QuestionCategory.INTEGRATIONS,
            priority=QuestionPriority.OPTIONAL,
            question="Which external services or APIs need to be integrated?",
            why_it_matters="Third-party integrations require API keys, error handling, and testing.",
        ))

    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.QUALITY_TESTING,
        priority=QuestionPriority.OPTIONAL,
        question="What level of testing is expected?",
        why_it_matters="Determines test strategy and CI setup.",
        suggested_default="Backend unit tests + frontend typecheck/build",
        options=["Minimal (linting)", "Unit tests", "Unit + integration", "Full CI/CD pipeline"],
    ))

    return qs


def _existing_project_questions(text: str, signals: set[str]) -> list[ProjectIntakeQuestion]:
    """Generate questions for an existing project."""
    qs: list[ProjectIntakeQuestion] = []

    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.EXISTING_PROJECT,
        priority=QuestionPriority.REQUIRED,
        question="Where are the project files located? Provide the path or repository URL.",
        why_it_matters="Needed to scan and understand the current codebase.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.TECH_STACK,
        priority=QuestionPriority.REQUIRED,
        question="What tech stack does the project use?",
        why_it_matters="Determines which agents and tools to assign.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.EXISTING_PROJECT,
        priority=QuestionPriority.REQUIRED,
        question="What already works? What is the current state of the project?",
        why_it_matters="Helps prioritize what to build next vs. what to fix.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.EXISTING_PROJECT,
        priority=QuestionPriority.REQUIRED,
        question="What is broken or incomplete? What needs to be fixed first?",
        why_it_matters="Identifies blockers before new development.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.PRODUCT_GOAL,
        priority=QuestionPriority.REQUIRED,
        question="What is the next goal? What should be built or improved?",
        why_it_matters="Defines scope for the next planning cycle.",
    ))

    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.QUALITY_TESTING,
        priority=QuestionPriority.RECOMMENDED,
        question="Do tests exist? How do you run them (test command)?",
        why_it_matters="Needed for safe changes — run tests before and after modifications.",
        suggested_default="pytest for Python, npm test for JS/TS",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.EXISTING_PROJECT,
        priority=QuestionPriority.RECOMMENDED,
        question="How do you run the project in development mode (dev/build commands)?",
        why_it_matters="Required for verifying changes work correctly.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.DATA_STORAGE,
        priority=QuestionPriority.RECOMMENDED,
        question="What database, environment variables, or local services are required to run the project?",
        why_it_matters="Prevents unsafe assumptions about DB setup, migrations, .env files, and local dependencies.",
        suggested_default="Document required DB/local services and keep secrets out of chat.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.CONSTRAINTS,
        priority=QuestionPriority.RECOMMENDED,
        question="Are there files or areas that should NOT be modified?",
        why_it_matters="Prevents accidental changes to critical or protected code.",
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.EXISTING_PROJECT,
        priority=QuestionPriority.RECOMMENDED,
        question="Is there Git history? Should we respect existing branch structure?",
        why_it_matters="Affects how changes are staged and reviewed.",
        options=["Yes, use Git", "No Git", "Not sure"],
    ))
    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.DEPLOYMENT,
        priority=QuestionPriority.RECOMMENDED,
        question="Is there an existing deployment target or hosting environment?",
        why_it_matters="Deployment context affects environment assumptions and verification scope.",
        suggested_default="Local development first unless deployment is already configured.",
    ))

    qs.append(ProjectIntakeQuestion(
        category=QuestionCategory.AUTH_SECURITY,
        priority=QuestionPriority.OPTIONAL,
        question="Are there .env files, secrets, or credentials that should be ignored?",
        why_it_matters="Prevents accidental exposure of sensitive data.",
        suggested_default="Ignore .env, *.key, *.pem files",
    ))

    return qs


# ── Bounded output ───────────────────────────────────────────────────────────

MAX_REQUIRED = 8
MAX_RECOMMENDED = 7
MAX_OPTIONAL = 5
MAX_TOTAL = 15


def _bound_questions(qs: list[ProjectIntakeQuestion]) -> list[ProjectIntakeQuestion]:
    required = [q for q in qs if q.priority == QuestionPriority.REQUIRED][:MAX_REQUIRED]
    recommended = [q for q in qs if q.priority == QuestionPriority.RECOMMENDED][:MAX_RECOMMENDED]
    optional = [q for q in qs if q.priority == QuestionPriority.OPTIONAL][:MAX_OPTIONAL]
    bounded = required + recommended + optional
    return bounded[:MAX_TOTAL]


# ── Ready-to-plan heuristic ─────────────────────────────────────────────────


def _assess_readiness(
    mode: ProjectIntakeMode,
    target: ProjectTargetType,
    maturity: ProjectMaturityGoal,
    signals: set[str],
    known_stack: list[str],
    idea_words: int,
) -> tuple[bool, str, str]:
    """Return (ready_to_plan, confidence, recommended_next_step)."""

    score = 0
    if target != ProjectTargetType.UNKNOWN:
        score += 1
    if maturity != ProjectMaturityGoal.UNKNOWN:
        score += 1
    if known_stack:
        score += 1
    if "auth" in signals:
        score += 1
    if "database" in signals:
        score += 1
    if idea_words >= 30:
        score += 1

    if mode == ProjectIntakeMode.EXISTING_PROJECT:
        # Existing projects always need answers before planning
        return False, "low", "Answer the questions above to help the system understand your existing project."

    if score >= 5:
        return True, "high", "Enough information to generate an initial plan. You can still refine answers."
    if score >= 3:
        return False, "medium", "Answer the required questions to improve the plan quality."
    return False, "low", "The idea is too vague. Answer at least the required questions before planning."


# ── Main entry point ─────────────────────────────────────────────────────────


def analyze_project_intake(req: ProjectIntakeRequest) -> ProjectIntakeResponse:
    """Analyze a raw project idea and return structured intake questions.

    Pure function — no DB, no LLM, no tools, no side effects.
    """

    text = req.idea.strip()
    idea_words = len(text.split())
    mode = detect_intake_mode(req)
    target = detect_target_type(text)
    maturity = detect_maturity_goal(text)
    signals = _detect_signals(text)
    known_stack = req.known_stack or []

    # Generate questions
    if mode == ProjectIntakeMode.EXISTING_PROJECT:
        raw_questions = _existing_project_questions(text, signals)
    else:
        raw_questions = _new_project_questions(text, signals, known_stack)

    questions = _bound_questions(raw_questions)

    # Build assumptions
    assumptions: list[str] = []
    if target != ProjectTargetType.UNKNOWN:
        assumptions.append(f"Target platform: {target.value.replace('_', ' ')}")
    if maturity != ProjectMaturityGoal.UNKNOWN:
        assumptions.append(f"Maturity goal: {maturity.value.replace('_', ' ')}")
    if known_stack:
        assumptions.append(f"Known stack: {', '.join(known_stack)}")
    if not known_stack and mode == ProjectIntakeMode.NEW_PROJECT:
        assumptions.append("Default stack assumption: React + FastAPI + SQLite for local prototype")
    if "auth" in signals:
        assumptions.append("Auth/login mentioned — will include authentication architecture")
    if "payments" in signals:
        assumptions.append("Payments mentioned — will include billing integration planning")

    # Build missing information
    missing: list[str] = []
    if target == ProjectTargetType.UNKNOWN:
        missing.append("Target platform not specified")
    if maturity == ProjectMaturityGoal.UNKNOWN:
        missing.append("Project maturity/scope not specified (MVP vs full product)")
    if not known_stack and mode == ProjectIntakeMode.NEW_PROJECT:
        missing.append("Tech stack not specified")
    if "auth" not in signals and mode == ProjectIntakeMode.NEW_PROJECT:
        missing.append("Auth requirements not mentioned")
    if "database" not in signals and mode == ProjectIntakeMode.NEW_PROJECT:
        missing.append("Database/storage requirements not mentioned")

    ready, confidence, next_step = _assess_readiness(
        mode, target, maturity, signals, known_stack, idea_words,
    )

    summary_prefix = "Existing project continuation" if mode == ProjectIntakeMode.EXISTING_PROJECT else "New project"
    summary = (
        f"{summary_prefix}. "
        f"Detected: {target.value.replace('_', ' ')} / {maturity.value.replace('_', ' ')}. "
        f"{len(questions)} questions generated ({len([q for q in questions if q.priority == QuestionPriority.REQUIRED])} required)."
    )

    return ProjectIntakeResponse(
        mode=mode,
        detected_target_type=target,
        detected_maturity_goal=maturity,
        summary=summary,
        assumptions=assumptions,
        missing_information=missing,
        questions=questions,
        ready_to_plan=ready,
        recommended_next_step=next_step,
        confidence=confidence,
    )


# ── Project Brief Draft ───────────────────────────────────────────────────────


def _section(
    title: str,
    content: str,
    status: ProjectBriefSectionStatus,
    notes: Optional[str] = None,
) -> ProjectBriefSection:
    return ProjectBriefSection(title=title, content=content, status=status, notes=notes)


def _section_markdown(section: ProjectBriefSection) -> str:
    marker = section.status.value.capitalize()
    notes = f"\n\nNotes: {section.notes}" if section.notes else ""
    return f"## {section.title}\n\nStatus: {marker}\n\n{section.content}{notes}"


def _safe_default_stack(req: ProjectBriefDraftRequest, intake: ProjectIntakeResponse) -> tuple[str, ProjectBriefSectionStatus, str]:
    if req.known_stack:
        return ", ".join(req.known_stack), ProjectBriefSectionStatus.CONFIRMED, "Provided in request."
    if intake.mode == ProjectIntakeMode.NEW_PROJECT:
        return "React + FastAPI + SQLite for a local prototype.", ProjectBriefSectionStatus.ASSUMED, "Default assumption only."
    return "Missing: existing project stack needs to be provided.", ProjectBriefSectionStatus.MISSING, "Required for existing project onboarding."


def draft_project_brief(req: ProjectBriefDraftRequest) -> ProjectBriefDraftResponse:
    """Build a deterministic brief draft from intake analysis.

    Pure function — no DB, no LLM, no tools, no file scanning, no side effects.
    """

    intake = analyze_project_intake(ProjectIntakeRequest(
        idea=req.idea,
        mode=req.mode,
        existing_project_attached=req.existing_project_attached,
        known_stack=req.known_stack,
        known_constraints=req.known_constraints,
        user_goal=req.user_goal,
    ))
    text = req.idea.strip()
    signals = _detect_signals(text)
    answers = req.answers or {}

    target_label = intake.detected_target_type.value.replace("_", " ")
    maturity_label = intake.detected_maturity_goal.value.replace("_", " ")
    title = "Project Brief Draft"
    readiness = "ready_to_plan" if intake.ready_to_plan else "needs_clarification"

    product_goal = answers.get("product_goal") or req.user_goal or text
    sections: list[ProjectBriefSection] = [
        _section(
            "Product idea",
            product_goal,
            ProjectBriefSectionStatus.CONFIRMED if product_goal else ProjectBriefSectionStatus.MISSING,
            "Generated from the raw idea and optional user_goal.",
        ),
        _section(
            "Target users",
            answers.get("target_users", "Missing: target users and roles are not confirmed yet."),
            ProjectBriefSectionStatus.CONFIRMED if answers.get("target_users") else ProjectBriefSectionStatus.MISSING,
            "Answer the users/roles intake question to confirm this section.",
        ),
        _section(
            "Core functionality",
            f"Build around the stated idea: {text}",
            ProjectBriefSectionStatus.ASSUMED,
            "This is a draft interpretation, not a final feature list.",
        ),
        _section(
            "Data and entities",
            "Database/storage is mentioned; plan a persistence layer and core entities."
            if "database" in signals else "Missing: data model and storage requirements need clarification.",
            ProjectBriefSectionStatus.CONFIRMED if "database" in signals else ProjectBriefSectionStatus.MISSING,
        ),
        _section(
            "Auth and roles",
            "Authentication or roles are mentioned; include auth architecture and access rules."
            if "auth" in signals else "Missing: authentication and authorization requirements need clarification.",
            ProjectBriefSectionStatus.CONFIRMED if "auth" in signals else ProjectBriefSectionStatus.MISSING,
        ),
        _section(
            "UI/UX",
            "UI/design requirements are mentioned; reflect them in frontend planning."
            if "ui" in signals else "Assumed: clean responsive default UI unless a design system is provided.",
            ProjectBriefSectionStatus.CONFIRMED if "ui" in signals else ProjectBriefSectionStatus.ASSUMED,
        ),
    ]

    stack_content, stack_status, stack_notes = _safe_default_stack(req, intake)
    sections.append(_section("Tech stack", stack_content, stack_status, stack_notes))

    sections.extend([
        _section(
            "Deployment",
            "Deployment target is mentioned; include deployment and environment planning."
            if "deployment" in signals else "Assumed: local development first; deployment target is not confirmed.",
            ProjectBriefSectionStatus.CONFIRMED if "deployment" in signals else ProjectBriefSectionStatus.ASSUMED,
        ),
        _section(
            "Quality/testing",
            "Testing or CI is mentioned; include verification commands and test coverage."
            if "testing" in signals else "Assumed: backend unit tests plus frontend typecheck/build as baseline.",
            ProjectBriefSectionStatus.CONFIRMED if "testing" in signals else ProjectBriefSectionStatus.ASSUMED,
        ),
    ])

    if req.known_constraints:
        sections.append(_section(
            "Constraints",
            "; ".join(req.known_constraints),
            ProjectBriefSectionStatus.CONFIRMED,
            "Provided in request.",
        ))

    open_questions = intake.questions
    question_lines = [
        f"- [{q.priority.value}] {q.question}"
        for q in open_questions[:MAX_TOTAL]
    ]
    assumption_lines = [f"- {item}" for item in intake.assumptions] or ["- None confirmed yet."]
    missing_lines = [f"- {item}" for item in intake.missing_information] or ["- No major gaps detected."]

    brief_parts = [
        "# Project Brief Draft",
        "",
        f"Mode: {intake.mode.value}",
        f"Target: {target_label}",
        f"Maturity: {maturity_label}",
        f"Readiness: {readiness}",
        "",
        *[_section_markdown(section) for section in sections],
        "## Open questions",
        "",
        "\n".join(question_lines) if question_lines else "None.",
        "",
        "## Assumptions",
        "",
        "\n".join(assumption_lines),
        "",
        "## Missing information",
        "",
        "\n".join(missing_lines),
    ]

    return ProjectBriefDraftResponse(
        title=title,
        mode=intake.mode,
        target_type=intake.detected_target_type,
        maturity_goal=intake.detected_maturity_goal,
        readiness=readiness,
        summary=f"{intake.summary} Brief draft has {len(sections)} sections.",
        brief_markdown="\n".join(brief_parts),
        sections=sections,
        assumptions=intake.assumptions,
        missing_information=intake.missing_information,
        open_questions=open_questions,
        recommended_next_step=intake.recommended_next_step,
        ready_to_plan=intake.ready_to_plan,
    )


# ── Development Plan Preview ─────────────────────────────────────────────────


KNOWN_AGENT_IDS = {
    "orchestrator",
    "product-manager",
    "business-analyst",
    "architect",
    "api-designer",
    "frontend-developer",
    "backend-developer",
    "fullstack-developer",
    "react-specialist",
    "typescript-pro",
    "fastapi-developer",
    "node-specialist",
    "sql-pro",
    "postgres-pro",
    "mobile-developer",
    "qa-expert",
    "test-automator",
    "code-reviewer",
    "security-auditor",
    "devops-engineer",
    "technical-writer",
    "error-detective",
    "git-workflow-manager",
}


def _phase(
    *,
    id: str,
    title: str,
    description: str,
    priority: QuestionPriority,
    status: DevelopmentPlanPhaseStatus,
    suggested_agent_id: Optional[str] = None,
    depends_on: Optional[list[str]] = None,
    deliverables: Optional[list[str]] = None,
    risks: Optional[list[str]] = None,
) -> DevelopmentPlanPhase:
    agent_id = suggested_agent_id if suggested_agent_id in KNOWN_AGENT_IDS else suggested_agent_id
    return DevelopmentPlanPhase(
        id=id,
        title=title,
        description=description,
        priority=priority,
        status=status,
        suggested_agent_id=agent_id,
        depends_on=depends_on or [],
        deliverables=deliverables or [],
        risks=risks or [],
    )


def _dedupe(items: list[str]) -> list[str]:
    return list(dict.fromkeys(item for item in items if item))


def _agent_recommendations(phases: list[DevelopmentPlanPhase]) -> list[str]:
    base = ["orchestrator", "product-manager", "architect", "qa-expert", "technical-writer"]
    phase_agents = [phase.suggested_agent_id or "" for phase in phases]
    return _dedupe([*base, *phase_agents])


def _new_project_plan_phases(
    brief: ProjectBriefDraftResponse,
    signals: set[str],
    required_inputs: list[str],
) -> list[DevelopmentPlanPhase]:
    requirements_status = (
        DevelopmentPlanPhaseStatus.NEEDS_INPUT
        if required_inputs
        else DevelopmentPlanPhaseStatus.READY
    )
    architecture_status = (
        DevelopmentPlanPhaseStatus.READY
        if brief.target_type != ProjectTargetType.UNKNOWN
        else DevelopmentPlanPhaseStatus.NEEDS_INPUT
    )

    phases = [
        _phase(
            id="requirements-clarification",
            title="Requirements clarification",
            description="Confirm product goal, target users, platform, constraints, and MVP boundary before execution.",
            priority=QuestionPriority.REQUIRED,
            status=requirements_status,
            suggested_agent_id="product-manager",
            deliverables=["Confirmed scope", "Open questions answered", "Acceptance criteria"],
            risks=["Planning quality is limited until required inputs are answered"] if required_inputs else [],
        ),
        _phase(
            id="architecture-design",
            title="Architecture/design",
            description="Define system boundaries, frontend/backend split, data flow, and integration points.",
            priority=QuestionPriority.REQUIRED,
            status=architecture_status,
            suggested_agent_id="architect",
            depends_on=["requirements-clarification"],
            deliverables=["Architecture outline", "Module boundaries", "Implementation order"],
        ),
        _phase(
            id="data-model",
            title="Data model",
            description="Draft entities, relationships, persistence choices, and migration/testing approach.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.READY if "database" in signals else DevelopmentPlanPhaseStatus.NEEDS_INPUT,
            suggested_agent_id="postgres-pro" if "database" in signals else "backend-developer",
            depends_on=["architecture-design"],
            deliverables=["Entity list", "Storage model", "Validation rules"],
            risks=[] if "database" in signals else ["Storage requirements are not confirmed"],
        ),
        _phase(
            id="backend-api",
            title="Backend/API",
            description="Plan backend routes, validation, services, and API contracts.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="backend-developer",
            depends_on=["architecture-design", "data-model"],
            deliverables=["API contract", "Backend task list", "Error handling plan"],
        ),
        _phase(
            id="frontend-ui",
            title="Frontend/UI",
            description="Plan screens, client state, API integration, loading/error states, and responsive behavior.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="frontend-developer",
            depends_on=["architecture-design", "backend-api"],
            deliverables=["Screen list", "Component plan", "Client API usage"],
        ),
    ]

    if "auth" in signals:
        phases.append(_phase(
            id="auth-rbac",
            title="Auth/RBAC",
            description="Plan authentication, roles, permissions, and protected flows.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="security-auditor",
            depends_on=["backend-api", "frontend-ui"],
            deliverables=["Auth flow", "Role matrix", "Security checklist"],
            risks=["Auth and RBAC need focused security review"],
        ))

    if "uploads" in signals:
        phases.append(_phase(
            id="files-uploads",
            title="Files/uploads",
            description="Plan upload limits, storage, validation, and file safety boundaries.",
            priority=QuestionPriority.RECOMMENDED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="backend-developer",
            depends_on=["backend-api"],
            deliverables=["Upload contract", "Storage plan", "Validation rules"],
            risks=["File upload paths and content types require strict validation"],
        ))

    if "payments" in signals:
        phases.append(_phase(
            id="payments",
            title="Payments",
            description="Plan payment flows, billing state, webhook handling, and reconciliation.",
            priority=QuestionPriority.RECOMMENDED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="backend-developer",
            depends_on=["backend-api", "data-model"],
            deliverables=["Payment flow", "Billing data model", "Webhook safety checklist"],
            risks=["Payment integrations require explicit provider choice and careful testing"],
        ))

    if "notifications" in signals:
        phases.append(_phase(
            id="notifications",
            title="Notifications",
            description="Plan notification channels, event triggers, templates, and delivery failure handling.",
            priority=QuestionPriority.OPTIONAL,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="backend-developer",
            depends_on=["backend-api"],
            deliverables=["Notification events", "Channel plan", "Retry/failure behavior"],
        ))

    phases.extend([
        _phase(
            id="testing-qa",
            title="Testing/QA",
            description="Plan backend tests, frontend type/build checks, smoke tests, and regression coverage.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="qa-expert",
            depends_on=["backend-api", "frontend-ui"],
            deliverables=["Test strategy", "Verification commands", "Regression checklist"],
        ),
        _phase(
            id="deployment",
            title="Deployment",
            description="Plan local run instructions first, then deployment target and environment validation if needed.",
            priority=QuestionPriority.RECOMMENDED,
            status=DevelopmentPlanPhaseStatus.READY if "deployment" in signals else DevelopmentPlanPhaseStatus.NEEDS_INPUT,
            suggested_agent_id="devops-engineer",
            depends_on=["testing-qa"],
            deliverables=["Run/build commands", "Environment checklist", "Deployment notes"],
            risks=[] if "deployment" in signals else ["Deployment target is not confirmed"],
        ),
        _phase(
            id="documentation-final-report",
            title="Documentation/final report",
            description="Prepare setup notes, implementation summary, test results, and remaining gaps.",
            priority=QuestionPriority.RECOMMENDED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="technical-writer",
            depends_on=["testing-qa"],
            deliverables=["README/update notes", "Final report", "Known gaps"],
        ),
    ])

    return phases


def _existing_project_plan_phases(
    has_project_reference: bool,
    has_stack: bool,
    has_goal: bool,
) -> list[DevelopmentPlanPhase]:
    inventory_status = DevelopmentPlanPhaseStatus.READY if has_project_reference else DevelopmentPlanPhaseStatus.BLOCKED
    stack_status = DevelopmentPlanPhaseStatus.READY if has_stack else DevelopmentPlanPhaseStatus.NEEDS_INPUT
    goal_status = DevelopmentPlanPhaseStatus.READY if has_goal else DevelopmentPlanPhaseStatus.NEEDS_INPUT

    return [
        _phase(
            id="project-inventory",
            title="Project inventory",
            description="Identify project location, repository state, key folders, and safe working boundaries.",
            priority=QuestionPriority.REQUIRED,
            status=inventory_status,
            suggested_agent_id="orchestrator",
            deliverables=["Project path confirmed", "Workspace boundary", "Initial inventory"],
            risks=[] if has_project_reference else ["Existing project path or attachment is missing"],
        ),
        _phase(
            id="stack-profile-detection",
            title="Stack/profile detection",
            description="Confirm stack, package manager, test/build commands, and project profile metadata.",
            priority=QuestionPriority.REQUIRED,
            status=stack_status,
            suggested_agent_id="architect",
            depends_on=["project-inventory"],
            deliverables=["Stack profile", "Build command", "Test command"],
            risks=[] if has_stack else ["Known stack is missing"],
        ),
        _phase(
            id="safe-command-validation",
            title="Safe command validation",
            description="Validate dev/build/test commands manually before using them in a guided workflow.",
            priority=QuestionPriority.REQUIRED,
            status=stack_status,
            suggested_agent_id="qa-expert",
            depends_on=["stack-profile-detection"],
            deliverables=["Validated command list", "Baseline test status"],
        ),
        _phase(
            id="existing-code-risk-audit",
            title="Existing code risk audit",
            description="Review current architecture, risky areas, protected files, and change constraints.",
            priority=QuestionPriority.RECOMMENDED,
            status=stack_status,
            suggested_agent_id="code-reviewer",
            depends_on=["stack-profile-detection"],
            deliverables=["Risk notes", "Protected areas", "Review checklist"],
        ),
        _phase(
            id="current-goal-clarification",
            title="Current issue/goal clarification",
            description="Confirm what should be fixed or built next, plus acceptance criteria.",
            priority=QuestionPriority.REQUIRED,
            status=goal_status,
            suggested_agent_id="product-manager",
            depends_on=["project-inventory"],
            deliverables=["Goal statement", "Acceptance criteria", "Out-of-scope list"],
            risks=[] if has_goal else ["Current goal is not specific enough"],
        ),
        _phase(
            id="context-gathering",
            title="Context gathering",
            description="Use safe read-only context gathering before proposing changes.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.READY if has_project_reference and has_goal else DevelopmentPlanPhaseStatus.NEEDS_INPUT,
            suggested_agent_id="orchestrator",
            depends_on=["current-goal-clarification", "stack-profile-detection"],
            deliverables=["Relevant files", "Context bundle", "Open questions"],
        ),
        _phase(
            id="patch-proposal-review",
            title="Patch proposal/review",
            description="Prepare a patch proposal and static review without applying it automatically.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.NEEDS_INPUT,
            suggested_agent_id="code-reviewer",
            depends_on=["context-gathering"],
            deliverables=["Patch proposal", "Review findings"],
            risks=["Must remain manual approval gated"],
        ),
        _phase(
            id="manual-apply",
            title="Manual apply",
            description="Apply patch only after explicit manual confirmation in the controlled workflow.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.NEEDS_INPUT,
            suggested_agent_id="git-workflow-manager",
            depends_on=["patch-proposal-review"],
            deliverables=["Applied patch after approval", "Git diff summary"],
            risks=["No automatic apply in this preview flow"],
        ),
        _phase(
            id="test-fix-loop",
            title="Test/fix loop",
            description="Run configured checks manually, analyze failures, and prepare follow-up fix proposals.",
            priority=QuestionPriority.REQUIRED,
            status=DevelopmentPlanPhaseStatus.NEEDS_INPUT,
            suggested_agent_id="qa-expert",
            depends_on=["manual-apply"],
            deliverables=["Test results", "Failure analysis", "Fix proposal if needed"],
        ),
        _phase(
            id="final-verification-report",
            title="Final verification/report",
            description="Document changes, checks, residual risks, and next steps.",
            priority=QuestionPriority.RECOMMENDED,
            status=DevelopmentPlanPhaseStatus.READY,
            suggested_agent_id="technical-writer",
            depends_on=["test-fix-loop"],
            deliverables=["Final report", "Remaining gaps", "Recommended next slice"],
        ),
    ]


def draft_development_plan(req: DevelopmentPlanPreviewRequest) -> DevelopmentPlanPreviewResponse:
    """Build a deterministic development plan preview from intake and brief data.

    Pure function - no DB, no LLM, no tools, no agent selector, no file scanning.
    """

    brief = draft_project_brief(ProjectBriefDraftRequest(
        idea=req.idea,
        mode=req.mode,
        existing_project_attached=req.existing_project_attached,
        known_stack=req.known_stack,
        known_constraints=req.known_constraints,
        user_goal=req.user_goal,
        answers=req.answers,
    ))
    text = req.idea.strip()
    signals = _detect_signals(text)
    answers = req.answers or {}

    required_inputs = list(brief.missing_information)
    if brief.mode == ProjectIntakeMode.NEW_PROJECT and not answers.get("target_users"):
        required_inputs.append("Target users/roles not confirmed")
    if brief.mode == ProjectIntakeMode.NEW_PROJECT and len(text.split()) < 5:
        required_inputs.append("Core functionality is too vague")

    has_project_reference = bool(req.existing_project_attached)
    has_stack = bool(req.known_stack)
    has_goal = bool(req.user_goal or len(text.split()) >= 8)
    if brief.mode == ProjectIntakeMode.EXISTING_PROJECT:
        if not has_project_reference:
            required_inputs.append("Existing project path or attached project is required")
        if not has_stack:
            required_inputs.append("Existing project stack is required")
        if not has_goal:
            required_inputs.append("Current goal or issue is required")

    required_inputs = _dedupe(required_inputs)

    if brief.mode == ProjectIntakeMode.EXISTING_PROJECT:
        phases = _existing_project_plan_phases(has_project_reference, has_stack, has_goal)
    else:
        phases = _new_project_plan_phases(brief, signals, required_inputs)

    risks = _dedupe([
        risk
        for phase in phases
        for risk in phase.risks
    ])
    blocked_phases = [phase for phase in phases if phase.status == DevelopmentPlanPhaseStatus.BLOCKED]
    ready_to_start = bool(
        brief.ready_to_plan
        and not required_inputs
        and not blocked_phases
    )
    source_readiness = DevelopmentPlanSourceReadiness(
        intake_ready_to_plan=brief.ready_to_plan,
        brief_ready_to_plan=brief.ready_to_plan,
    )
    summary = (
        f"{brief.mode.value.replace('_', ' ')} plan preview with {len(phases)} phase(s). "
        f"Ready to start: {'yes' if ready_to_start else 'no'}."
    )
    recommended_next_step = (
        "Ready for a supervised planning run preview. This endpoint still does not create a run."
        if ready_to_start
        else "Answer required inputs before converting this preview into an executable plan."
    )

    return DevelopmentPlanPreviewResponse(
        title="Development Plan Preview",
        mode=brief.mode,
        target_type=brief.target_type,
        maturity_goal=brief.maturity_goal,
        ready_to_start=ready_to_start,
        summary=summary,
        phases=phases,
        required_inputs=required_inputs,
        assumptions=brief.assumptions,
        risks=risks,
        recommended_agent_ids=_agent_recommendations(phases),
        recommended_next_step=recommended_next_step,
        source_readiness=source_readiness,
    )
