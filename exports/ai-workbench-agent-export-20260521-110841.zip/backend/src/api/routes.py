"""API routes for AI Workbench."""

from __future__ import annotations

import asyncio
import json
import os
import shlex
import subprocess
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query

from src.agents.registry import get_all_agents, load_agent_instructions, select_agents_for_task
from src.models import (
    ApprovalDecision,
    ApprovalStatus,
    ApplyPatchRequest,
    ClarificationAnswerRequest,
    CommandAnalysisRequest,
    CommandAnalysisResponse,
    CommandIssue,
    ConfigUpdate,
    CreateProjectRequest,
    CreateRunRequest,
    ListFilesRequest,
    ModelRouteDecision,
    ModelRouteDecisionResponse,
    ModelRouteRequest,
    ProjectCommandKind,
    ProposePatchRequest,
    ProviderMode,
    ProviderStatus,
    ProviderModeUpdate,
    ReadFileRequest,
    RolledBackFile,
    RollbackPatchRequest,
    RollbackPatchResponse,
    RunProjectCommandRequest,
    RunProjectCommandResponse,
    RunStatus,
    SearchCodeRequest,
    AUTO_READ_ALLOWED_ACTIONS,
    AUTO_READ_BLOCKED_ACTIONS,
    AUTO_CONTEXT_MAX_HARD_CAP,
    AutoStepReadRequest,
    AutoStepReadResponse,
    AutoContextGatherRequest,
    AutoContextGatheredFile,
    AutoContextGatherResponse,
    ContextPatchDraftRequest,
    ContextPatchDraftResponse,
    StepContextBundle,
    StepContextBundleResponse,
    GuidedExecutionPlanResponse,
    GuidedStepExecutionPlan,
    StepToolPlanResponse,
    StepToolRecommendation,
    UpdateRunAgentAssignmentRequest,
    UpdateProjectRequest,
    PatchReviewRequest,
    PatchReviewResponse,
    PatchReviewOperation,
    PatchWorkflowPlanResponse,
)
from src.model_router import (
    build_context_patch_draft,
    review_patch_operations,
    build_patch_workflow_plan,
    build_guided_step_actions,
    build_step_context_bundle,
    infer_agent_for_step,
    infer_task_type_for_agent,
    infer_task_type_for_step,
    infer_tools_for_step,
    list_model_profiles,
    list_model_registry,
    list_providers,
    model_route_decision_from_result,
    route_model,
)
from src.orchestrator.cancellation import cancel_run_task, register_run_task
from src.orchestrator.workflow_policy import (
    WorkflowAutomationMode,
    WorkflowPolicyResponse,
    list_workflow_action_policies,
)
from src.orchestrator.project_intake import (
    DevelopmentPlanPreviewRequest,
    DevelopmentPlanPreviewResponse,
    ProjectBriefDraftRequest,
    ProjectBriefDraftResponse,
    ProjectIntakeRequest,
    ProjectIntakeResponse,
    analyze_project_intake,
    draft_development_plan,
    draft_project_brief,
)
from src.orchestrator.engine import (
    _execute_staged_steps,
    _persist_step_route_decisions,
    build_architecture_prompt,
    build_task_breakdown_prompt,
    execute_run,
    fallback_architecture,
    fallback_task_breakdown,
    format_staged_steps,
    stage_executable_task_steps,
)
from src.approvals.safety import check_command
from src.project_tools import analyze_command_result as _analyze_command
from src.project_tools import apply_project_patch
from src.project_tools import find_safe_command_for_kind
from src.project_tools import list_files as project_list_files
from src.project_tools import propose_project_patch
from src.project_tools import read_file as project_read_file
from src.project_tools import rollback_project_patch as _rollback_patch
from src.project_tools import run_project_command as _run_safe_command
from src.project_tools import search_code as project_search_code
from src.providers import claude_provider, codex, ollama
from src.storage.database import (
    create_approval,
    create_project,
    create_run,
    create_run_step,
    create_tool_call,
    delete_model_route_decisions_for_run,
    delete_step_route_decisions_for_run,
    find_pending_approval,
    get_approval,
    get_model_route_decisions_for_run,
    get_project,
    get_run,
    list_approvals,
    list_model_route_decisions_for_agents,
    list_model_route_decisions_for_steps,
    list_project_tool_calls,
    list_tool_calls_for_project,
    list_tool_calls_for_run,
    list_tool_calls_for_step,
    list_run_agent_assignments,
    list_run_steps,
    list_projects,
    list_runs,
    replace_run_agent_assignments,
    resolve_approval,
    upsert_model_route_decision,
    upsert_step_route_decision,
    update_tool_call,
    update_run_agent_assignment,
    update_project,
    update_run,
    update_run_step,
)
from src.utils.config import get_config, save_config
from src.utils.paths import PROJECT_ROOT, resolve_runtime_path

router = APIRouter()


# ── Health ───────────────────────────────────────────────────────────────────

@router.get("/health")
async def health():
    cfg = get_config()
    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    ollama_ok = await ollama.check_health(ollama_url)
    return {
        "status": "ok",
        "timestamp": datetime.now().isoformat(),
        "ollama": "connected" if ollama_ok else "disconnected",
    }


# ── Projects ─────────────────────────────────────────────────────────────────

@router.get("/api/projects")
async def get_projects():
    return list_projects()


@router.get("/api/projects/{project_id}")
async def get_project_detail(project_id: str):
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.post("/api/projects")
async def post_project(req: CreateProjectRequest):
    try:
        return create_project(
            name=req.name,
            path=req.path,
            description=req.description,
            stack=req.stack,
            package_manager=req.package_manager,
            test_command=req.test_command,
            build_command=req.build_command,
            safe_commands=req.safe_commands,
            blocked_commands=req.blocked_commands,
            ignore_paths=req.ignore_paths,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.patch("/api/projects/{project_id}")
async def patch_project(project_id: str, req: UpdateProjectRequest):
    try:
        project = update_project(project_id, **req.model_dump(exclude_unset=True))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


# ── Agents ───────────────────────────────────────────────────────────────────

@router.get("/api/agents")
async def get_agents():
    return get_all_agents()


@router.get("/api/agents/registry")
async def get_agent_registry():
    return get_all_agents()


# ── Models and Providers ─────────────────────────────────────────────────────

@router.get("/api/models/registry")
async def get_model_registry():
    cfg = get_config()
    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    available_models = await ollama.list_models(ollama_url)
    return list_model_registry(available_models, cfg)


@router.get("/api/models/profiles")
async def get_model_profiles():
    return list_model_profiles()


@router.post("/api/models/route")
async def post_model_route(req: ModelRouteRequest):
    cfg = get_config()
    route_request = req
    if not route_request.available_models:
        ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
        route_request = req.model_copy(update={"available_models": await ollama.list_models(ollama_url)})
    return route_model(route_request, cfg)


@router.get("/api/providers")
async def get_providers():
    return list_providers(get_config())


@router.get("/api/providers/status")
async def get_provider_status():
    cfg = get_config()
    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    local_models = await ollama.list_models(ollama_url)
    local_available = bool(local_models) or await ollama.check_health(ollama_url)
    codex_available = await codex.check_available()
    claude_available = await claude_provider.check_available()
    return [
        ProviderStatus(
            id="local_ollama",
            enabled=True,
            available=local_available,
            status="connected" if local_available else "disconnected",
            models=local_models,
            warnings=[] if local_available else ["Ollama is not reachable at the configured base URL."],
        ),
        ProviderStatus(
            id="chatgpt_codex",
            enabled=bool(cfg.get("codex", {}).get("enabled", False)),
            available=codex_available,
            status="available" if codex_available else "not_installed",
            models=["chatgpt-codex:default"] if codex_available else [],
            warnings=[] if codex_available else ["Codex CLI was not found on PATH."],
        ),
        ProviderStatus(
            id="claude_code",
            enabled=bool(cfg.get("claude", {}).get("enabled", False)),
            available=claude_available,
            status="available" if claude_available else "not_installed",
            models=["claude-code:sonnet"] if claude_available else [],
            warnings=[] if claude_available else ["Claude Code CLI was not found on PATH."],
        ),
        ProviderStatus(
            id="external_api",
            enabled=bool(cfg.get("external_api", {}).get("enabled", False)),
            available=False,
            status="not_configured",
            models=[],
            warnings=["External API adapters are metadata-only in this slice."],
        ),
    ]


@router.patch("/api/settings/provider-mode")
async def patch_provider_mode(req: ProviderModeUpdate):
    updated = save_config({"provider_mode": req.provider_mode.value})
    return {"provider_mode": updated.get("provider_mode", req.provider_mode.value)}


# ── Runs ─────────────────────────────────────────────────────────────────────

@router.get("/api/runs")
async def get_runs():
    return list_runs()


@router.post("/api/runs")
async def post_run(req: CreateRunRequest):
    if not req.project_id:
        raise HTTPException(status_code=400, detail="project_id is required")
    project = get_project(req.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if not project.path:
        raise HTTPException(status_code=400, detail="Project path is not configured")

    cfg = get_config()
    run = create_run(
        prompt=req.prompt,
        mode=req.mode.value,
        project_id=project.id,
        project_path=project.path,
    )
    selection = select_agents_for_task(
        prompt=req.prompt,
        project_name=project.name,
        project_path=project.path,
        project_stack=project.stack,
        package_manager=project.package_manager,
    )
    assigned_agents = replace_run_agent_assignments(
        run.id,
        selection["selected_agents"],
    )

    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    ollama_model = cfg.get("ollama", {}).get("default_model", "qwen2.5-coder:7b")

    task = asyncio.create_task(
        execute_run(
            run_id=run.id,
            prompt=req.prompt,
            mode=req.mode.value,
            run_dir=run.run_dir,
            project_id=project.id,
            project_name=project.name,
            project_path=project.path,
            project_stack=project.stack,
            selected_agents=[assignment.model_dump() for assignment in assigned_agents],
            provider_mode=cfg.get("provider_mode", "local"),
            ollama_base_url=ollama_url,
            ollama_model=ollama_model,
        )
    )
    register_run_task(run.id, task)
    return run


@router.get("/api/runs/{run_id}")
async def get_run_detail(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return run


@router.get("/api/runs/{run_id}/steps")
async def get_run_steps(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return list_run_steps(run_id)


@router.get("/api/runs/{run_id}/steps/tool-plan")
async def get_run_step_tool_plan(run_id: str) -> StepToolPlanResponse:
    """Return per-step tool recommendations for a run's staged steps.

    Read-only — no ToolCalls are created, no tools are executed, no files written.
    Resolution order for task_type per step:
    1. Persisted step-level route decision (if any).
    2. infer_task_type_for_step from step title / input / agent_id.
    """
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    steps = list_run_steps(run_id)
    if not steps:
        return StepToolPlanResponse(
            run_id=run_id,
            recommendations=[],
            summary="No steps found for this run.",
            warnings=[],
        )

    # Build a map of step_id → persisted route decision for fast lookup
    step_decisions = {
        d.step_id: d
        for d in list_model_route_decisions_for_steps(run_id)
        if d.step_id
    }

    recommendations: list[StepToolRecommendation] = []
    warnings: list[str] = []

    for step in steps:
        decision = step_decisions.get(step.id)
        agent_id = ""
        task_type = ""
        if decision:
            agent_id = decision.agent_id or step.agent_id or ""
            task_type = decision.task_type or ""
        else:
            agent_id = step.agent_id or ""

        rec = infer_tools_for_step(step, agent_id=agent_id, task_type=task_type)
        recommendations.append(rec)
        warnings.extend(rec.warnings)

    n = len(recommendations)
    summary = (
        f"Tool plan for {n} step(s). No tools are executed automatically."
    )
    return StepToolPlanResponse(
        run_id=run_id,
        recommendations=recommendations,
        summary=summary,
        warnings=list(dict.fromkeys(warnings)),  # deduplicate preserving order
    )


@router.get("/api/runs/{run_id}/guided-execution-plan")
async def get_run_guided_execution_plan(run_id: str) -> GuidedExecutionPlanResponse:
    """Return a guided execution plan for each staged step in the run.

    Read-only — no ToolCalls are created, no tools are executed, no files written.
    """
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    steps = list_run_steps(run_id)
    if not steps:
        return GuidedExecutionPlanResponse(
            run_id=run_id,
            steps=[],
            summary="No steps found for this run.",
            warnings=[],
        )

    step_decisions = {
        d.step_id: d
        for d in list_model_route_decisions_for_steps(run_id)
        if d.step_id
    }

    all_calls = list_tool_calls_for_run(run_id)

    step_plans: list[GuidedStepExecutionPlan] = []
    warnings: list[str] = []

    for step in steps:
        decision = step_decisions.get(step.id)
        agent_id = (decision.agent_id if decision else None) or step.agent_id or ""
        task_type = (decision.task_type if decision else None) or ""
        tool_plan = infer_tools_for_step(step, agent_id=agent_id, task_type=task_type)
        plan = build_guided_step_actions(step, tool_plan, all_calls, decision)
        step_plans.append(plan)
        warnings.extend(plan.warnings)

    n = len(step_plans)
    pending = sum(
        1 for p in step_plans
        if p.recommended_next_action
        and p.recommended_next_action.action_type != "done"
    )
    summary = (
        f"Guided plan for {n} step(s): {pending} with pending actions. "
        "No actions run automatically."
    )
    return GuidedExecutionPlanResponse(
        run_id=run_id,
        steps=step_plans,
        summary=summary,
        warnings=list(dict.fromkeys(warnings)),
    )


@router.get("/api/runs/{run_id}/patch-workflow-plan")
async def get_run_patch_workflow_plan(run_id: str) -> PatchWorkflowPlanResponse:
    """Return an approval-gated patch workflow plan for each step in the run.

    Read-only — analyses existing tool_call history, no ToolCalls created,
    no tools executed, no files written, no patches applied or rolled back.
    """
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    steps = list_run_steps(run_id)
    step_decisions = {
        d.step_id: d
        for d in list_model_route_decisions_for_steps(run_id)
        if d.step_id
    }
    all_calls = list_tool_calls_for_run(run_id)

    return build_patch_workflow_plan(
        run_id=run_id,
        steps=steps,
        tool_calls=all_calls,
        route_decisions=step_decisions,
    )


@router.post("/api/runs/{run_id}/steps/{step_id}/auto-read")
async def run_step_auto_read(
    run_id: str,
    step_id: str,
    req: AutoStepReadRequest,
) -> AutoStepReadResponse:
    """Execute a safe read-only tool for a staged step automatically.

    Permitted action types: list_files, read_file, search_code.
    Explicitly blocked: propose_patch, apply_patch, rollback_patch, run_command,
    analyze_result, run_tests, and any other non-read action.

    Creates a low-risk ToolCall record. Does not modify any project files.
    """
    # Safety gate — block before doing anything else
    if req.action_type in AUTO_READ_BLOCKED_ACTIONS:
        raise HTTPException(
            status_code=403,
            detail=(
                f"action_type '{req.action_type}' is not permitted for auto-read. "
                f"Only {sorted(AUTO_READ_ALLOWED_ACTIONS)} are allowed."
            ),
        )
    if req.action_type not in AUTO_READ_ALLOWED_ACTIONS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unknown action_type '{req.action_type}'. "
                f"Allowed: {sorted(AUTO_READ_ALLOWED_ACTIONS)}."
            ),
        )

    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    # Resolve step
    steps = list_run_steps(run_id)
    step = next((s for s in steps if s.id == step_id), None)
    if not step:
        raise HTTPException(status_code=404, detail="Step not found")

    # Resolve project
    if not run.project_id:
        raise HTTPException(status_code=400, detail="Run has no associated project")
    project = get_project(run.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    # Map action_type → tool_name and build tool-specific request
    tool_name_map = {
        "list_files": "list_files",
        "read_file": "read_file",
        "search_code": "search_code",
    }
    tool_name = tool_name_map[req.action_type]
    effective_agent_id = req.agent_id or step.agent_id or ""

    # Build input metadata
    input_meta: dict = {
        "action_type": req.action_type,
        "run_id": run_id,
        "step_id": step_id,
        "agent_id": effective_agent_id,
    }
    if req.action_type == "search_code":
        # Use query from request; fallback to step title
        query = req.query or step.title
        input_meta["query"] = query
        input_meta["limit"] = req.limit
    elif req.action_type == "read_file":
        if not req.file_path:
            raise HTTPException(
                status_code=400,
                detail="file_path is required for read_file action",
            )
        input_meta["file_path"] = req.file_path
    elif req.action_type == "list_files":
        input_meta["limit"] = req.limit

    started_at = datetime.now().isoformat()
    tool_call = create_tool_call(
        run_id=run_id,
        project_id=project.id,
        step_id=step_id,
        tool_name=tool_name,
        cwd=project.path,
        status="pending",
        input_json=json.dumps(input_meta, ensure_ascii=False),
        risk_level="low",
        started_at=started_at,
    )

    warnings: list[str] = []
    try:
        if req.action_type == "list_files":
            raw = project_list_files(project.path, path=".", max_files=req.limit)
        elif req.action_type == "read_file":
            raw = project_read_file(project.path, path=req.file_path)
        else:  # search_code
            query = req.query or step.title
            raw = project_search_code(project.path, query=query, max_results=req.limit)

        completed_at = datetime.now().isoformat()
        result_json = {**raw, "tool_call_id": tool_call.id}
        update_tool_call(
            tool_call.id,
            status="completed",
            output_json=json.dumps(result_json, ensure_ascii=False),
            completed_at=completed_at,
            finished_at=completed_at,
        )

        # Build human-readable summary
        if req.action_type == "list_files":
            n = len(raw.get("files", []))
            summary = f"Listed {n} file(s)."
        elif req.action_type == "read_file":
            chars = len(raw.get("content", ""))
            summary = f"Read {chars} character(s) from {req.file_path}."
        else:
            n = len(raw.get("matches", []))
            summary = f"Found {n} match(es) for '{req.query or step.title}'."

        return AutoStepReadResponse(
            run_id=run_id,
            step_id=step_id,
            action_type=req.action_type,
            tool_call_id=tool_call.id,
            status="completed",
            summary=summary,
            result=result_json,
            warnings=warnings,
        )

    except (PermissionError, ValueError) as exc:
        msg = str(exc)
        _mark_tool_call_failed(tool_call.id, msg)
        raise HTTPException(status_code=400, detail=msg) from exc
    except HTTPException:
        _mark_tool_call_failed(tool_call.id, "HTTP error")
        raise
    except Exception as exc:
        msg = str(exc)
        _mark_tool_call_failed(tool_call.id, msg)
        raise HTTPException(status_code=500, detail=f"Auto-read failed: {msg}") from exc


@router.post("/api/runs/{run_id}/steps/{step_id}/auto-context")
async def run_step_auto_context(
    run_id: str,
    step_id: str,
    req: AutoContextGatherRequest,
) -> AutoContextGatherResponse:
    """Bounded read-only context-gathering workflow for a staged step.

    Runs up to *max_tool_calls* (hard cap: 8) of list_files / search_code / read_file
    using a heuristic strategy.  No file is modified; no command is executed; no patch
    is proposed or applied.  Every call creates a low-risk ToolCall audit record.
    """
    # Enforce hard cap
    if req.max_tool_calls > AUTO_CONTEXT_MAX_HARD_CAP:
        raise HTTPException(
            status_code=400,
            detail=(
                f"max_tool_calls={req.max_tool_calls} exceeds hard cap "
                f"({AUTO_CONTEXT_MAX_HARD_CAP}). Reduce it."
            ),
        )
    cap = max(1, req.max_tool_calls)

    # Resolve run / step / project
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    steps = list_run_steps(run_id)
    step = next((s for s in steps if s.id == step_id), None)
    if not step:
        raise HTTPException(status_code=404, detail="Step not found")

    if not run.project_id:
        raise HTTPException(status_code=400, detail="Run has no associated project")
    project = get_project(run.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    effective_agent = req.agent_id or step.agent_id or ""
    now_iso = datetime.now().isoformat

    # Shared helper: create + run a low-risk tool call and return (tool_call_id, raw_result_or_None)
    def _run_read_tool(tool_name: str, input_meta: dict):
        tc = create_tool_call(
            run_id=run_id,
            project_id=project.id,
            step_id=step_id,
            tool_name=tool_name,
            cwd=project.path,
            status="pending",
            input_json=json.dumps(input_meta, ensure_ascii=False),
            risk_level="low",
            started_at=datetime.now().isoformat(),
        )
        try:
            if tool_name == "list_files":
                raw = project_list_files(project.path, path=".", max_files=200)
            elif tool_name == "search_code":
                raw = project_search_code(
                    project.path,
                    query=input_meta.get("query", ""),
                    max_results=input_meta.get("limit", 50),
                )
            else:  # read_file
                raw = project_read_file(project.path, path=input_meta["file_path"])
            completed = datetime.now().isoformat()
            result_payload = {**raw, "tool_call_id": tc.id}
            update_tool_call(
                tc.id,
                status="completed",
                output_json=json.dumps(result_payload, ensure_ascii=False),
                completed_at=completed,
                finished_at=completed,
            )
            return tc.id, raw
        except Exception as exc:
            _mark_tool_call_failed(tc.id, str(exc))
            return tc.id, None

    tool_call_ids: list[str] = []
    warnings: list[str] = []
    searched_queries: list[str] = []
    files_considered: list[str] = []
    files_read: list[AutoContextGatheredFile] = []
    budget = cap

    # ── Step 1: list_files ────────────────────────────────────────────────────
    if budget <= 0:
        pass
    else:
        tc_id, lf_raw = _run_read_tool("list_files", {"action": "list_files"})
        tool_call_ids.append(tc_id)
        budget -= 1

        if lf_raw:
            listed: list[str] = [f.get("path", f) if isinstance(f, dict) else str(f)
                                  for f in lf_raw.get("files", [])]
            files_considered = listed

    # ── Step 2: search_code ───────────────────────────────────────────────────
    search_query = req.query or step.title or getattr(step, "input", "") or "main"
    sc_matches: list[str] = []
    if budget > 0 and search_query:
        tc_id, sc_raw = _run_read_tool(
            "search_code",
            {"query": search_query, "limit": 50},
        )
        tool_call_ids.append(tc_id)
        budget -= 1
        searched_queries.append(search_query)

        if sc_raw:
            sc_matches = [m.get("path", "") for m in sc_raw.get("matches", []) if m.get("path")]
            # deduplicate and keep order
            seen: set[str] = set()
            deduped: list[str] = []
            for p in sc_matches:
                if p not in seen:
                    seen.add(p)
                    deduped.append(p)
            sc_matches = deduped

    # ── Step 3: read relevant files ───────────────────────────────────────────
    # Priority: search matches → file-list heuristic
    BACKEND_KEYWORDS  = {"route", "service", "controller", "model", "database", "api", "schema"}
    FRONTEND_KEYWORDS = {"component", "page", "client", "store", "hook"}
    TEST_KEYWORDS     = {"test", "spec"}
    DOC_KEYWORDS      = {"readme", "doc"}

    def _relevance_score(path: str) -> int:
        low = path.lower()
        if any(k in low for k in BACKEND_KEYWORDS | FRONTEND_KEYWORDS):
            return 3
        if any(k in low for k in TEST_KEYWORDS):
            return 2
        if any(k in low for k in DOC_KEYWORDS):
            return 1
        return 0

    candidates: list[str]
    if sc_matches:
        candidates = sc_matches[:3]
    else:
        # fall back to heuristic from file list
        candidates = sorted(files_considered, key=_relevance_score, reverse=True)[:3]

    # Apply include/exclude patterns from request
    if req.include_file_patterns:
        import fnmatch
        candidates = [
            c for c in candidates
            if any(fnmatch.fnmatch(c, pat) for pat in req.include_file_patterns)
        ]
    if req.exclude_file_patterns:
        import fnmatch
        candidates = [
            c for c in candidates
            if not any(fnmatch.fnmatch(c, pat) for pat in req.exclude_file_patterns)
        ]

    for file_path in candidates:
        if budget <= 0:
            warnings.append(f"Budget exhausted before reading '{file_path}'.")
            break
        reason = (
            f"matched search query '{search_query}'"
            if file_path in sc_matches
            else "selected by file-name heuristic"
        )
        tc_id, rf_raw = _run_read_tool("read_file", {"file_path": file_path})
        tool_call_ids.append(tc_id)
        budget -= 1
        if rf_raw is not None:
            files_read.append(AutoContextGatheredFile(
                file_path=file_path,
                reason=reason,
                source_tool_call_id=tc_id,
            ))
        else:
            warnings.append(f"Could not read '{file_path}'.")

    # ── Step 4: summary + next_recommended_action ─────────────────────────────
    read_only_task_types = {"review", "research", "analysis", "read-only"}
    task_type = getattr(step, "task_type", "") or ""
    has_context = bool(files_read)

    if task_type in read_only_task_types:
        next_action = "done"
    elif has_context:
        next_action = "propose_patch"
    elif searched_queries:
        next_action = "read_context"
    else:
        next_action = "search_code"

    n_calls = len(tool_call_ids)
    n_read  = len(files_read)
    summary = (
        f"Gathered context in {n_calls} tool call(s): "
        f"searched {len(searched_queries)} query/queries, "
        f"read {n_read} file(s). "
        f"Next: {next_action}."
    )
    if warnings:
        summary += f" Warnings: {len(warnings)}."

    status = "completed" if has_context or sc_matches else "partial"

    return AutoContextGatherResponse(
        run_id=run_id,
        step_id=step_id,
        status=status,
        summary=summary,
        tool_call_ids=tool_call_ids,
        searched_queries=searched_queries,
        files_considered=files_considered[:50],  # cap to avoid huge responses
        files_read=files_read,
        warnings=warnings,
        next_recommended_action=next_action,
    )


@router.get("/api/runs/{run_id}/tool-calls")
async def get_run_tool_calls(run_id: str):
    return list_tool_calls_for_run(run_id)


@router.get("/api/runs/{run_id}/steps/{step_id}/tool-calls")
async def get_step_tool_calls(run_id: str, step_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return [call for call in list_tool_calls_for_step(step_id) if call.run_id == run_id]


@router.get("/api/runs/{run_id}/steps/{step_id}/context-bundle")
async def get_step_context_bundle(run_id: str, step_id: str) -> StepContextBundleResponse:
    """Return an aggregated read-only context bundle for a step.

    Reads only already-stored ToolCall records.  Creates no new ToolCalls,
    runs no tools, modifies no files, executes no commands.
    """
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    steps = list_run_steps(run_id)
    step = next((s for s in steps if s.id == step_id), None)
    if not step:
        raise HTTPException(status_code=404, detail="Step not found")

    # Fetch step-level route decision if present (best effort)
    route_decision: ModelRouteDecision | None = None
    try:
        step_routes = list_model_route_decisions_for_steps(run_id)
        route_decision = next((d for d in step_routes if d.step_id == step_id), None)
    except Exception:
        pass

    tool_calls = list_tool_calls_for_step(step_id)
    # Filter to this run only (defensive)
    tool_calls = [tc for tc in tool_calls if tc.run_id == run_id]

    bundle = build_step_context_bundle(
        run_id=run_id,
        step=step,
        tool_calls=tool_calls,
        route_decision=route_decision,
    )
    return StepContextBundleResponse(bundle=bundle)


@router.post("/api/runs/{run_id}/steps/{step_id}/context-patch-draft")
async def get_context_patch_draft(
    run_id: str,
    step_id: str,
    req: ContextPatchDraftRequest,
) -> ContextPatchDraftResponse:
    """Build a draft patch proposal from the step's context bundle.

    Pure read-only: creates no ToolCalls, runs no tools, reads no files,
    creates no patch proposals, applies no patches.
    """
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    steps = list_run_steps(run_id)
    step = next((s for s in steps if s.id == step_id), None)
    if not step:
        raise HTTPException(status_code=404, detail="Step not found")

    # Build bundle from existing tool calls (no new calls created)
    tool_calls = [tc for tc in list_tool_calls_for_step(step_id) if tc.run_id == run_id]
    route_decision: ModelRouteDecision | None = None
    try:
        step_routes = list_model_route_decisions_for_steps(run_id)
        route_decision = next((d for d in step_routes if d.step_id == step_id), None)
    except Exception:
        pass

    bundle = build_step_context_bundle(
        run_id=run_id,
        step=step,
        tool_calls=tool_calls,
        route_decision=route_decision,
    )

    return build_context_patch_draft(
        run_id=run_id,
        step=step,
        bundle=bundle,
        request=req,
    )


@router.get("/api/runs/{run_id}/agents")
async def get_run_agents(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return list_run_agent_assignments(run_id)


@router.get("/api/runs/{run_id}/model-routes")
async def get_run_model_routes(
    run_id: str,
    scope: str = Query(default="all", pattern="^(agents|steps|all)$"),
):
    """Return persisted model route decisions for a run.

    ``?scope=agents``  — agent-level decisions only (step_id IS NULL).
    ``?scope=steps``   — step-level decisions only (step_id IS NOT NULL).
    ``?scope=all``     — all decisions (default).
    """
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    if scope == "agents":
        return list_model_route_decisions_for_agents(run_id)
    if scope == "steps":
        return list_model_route_decisions_for_steps(run_id)
    return get_model_route_decisions_for_run(run_id)


@router.post("/api/runs/{run_id}/model-routes/preview")
async def preview_run_model_routes(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return await _build_run_model_route_decisions(run_id, persist=False)


@router.post("/api/runs/{run_id}/model-routes/persist")
async def persist_run_model_routes(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return await _build_run_model_route_decisions(run_id, persist=True)


@router.post("/api/runs/{run_id}/steps/model-routes/preview")
async def preview_step_model_routes(run_id: str):
    """Preview (without persisting) step-level model route decisions for a run."""
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return await _build_step_model_route_decisions(run_id, persist=False)


@router.post("/api/runs/{run_id}/steps/model-routes/persist")
async def persist_step_model_routes(run_id: str):
    """Compute and persist step-level model route decisions for a run."""
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return await _build_step_model_route_decisions(run_id, persist=True)


@router.post("/api/runs/{run_id}/agents/select")
async def post_select_run_agents(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    project = get_project(run.project_id) if run.project_id else None
    selection = select_agents_for_task(
        prompt=run.prompt,
        project_name=project.name if project else "",
        project_path=run.project_path,
        project_stack=project.stack if project else "",
        package_manager=project.package_manager if project else "",
    )
    assignments = replace_run_agent_assignments(run_id, selection["selected_agents"])
    delete_model_route_decisions_for_run(run_id)
    return {
        **selection,
        "selected_agents": assignments,
        "team_size": len(assignments),
    }


@router.patch("/api/runs/{run_id}/agents/{agent_id}")
async def patch_run_agent(run_id: str, agent_id: str, req: UpdateRunAgentAssignmentRequest):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    assignment = update_run_agent_assignment(
        run_id,
        agent_id,
        **req.model_dump(exclude_unset=True),
    )
    if not assignment:
        raise HTTPException(status_code=404, detail="Run agent assignment not found")
    return assignment


async def _build_run_model_route_decisions(run_id: str, persist: bool) -> ModelRouteDecisionResponse:
    assignments = list_run_agent_assignments(run_id)
    if not assignments:
        return ModelRouteDecisionResponse(
            run_id=run_id,
            count=0,
            persisted=persist,
            decisions=[],
            warnings=["Run has no assigned agents. Select a team before routing models."],
        )

    cfg = get_config()
    provider_mode = _provider_mode_from_config(cfg)
    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    available_models = await ollama.list_models(ollama_url)
    privacy_level = str(cfg.get("project_privacy_level", "private") or "private")
    warnings: list[str] = []
    decisions: list[ModelRouteDecision] = []

    for assignment in assignments:
        task_type = infer_task_type_for_agent(assignment.agent_id, assignment.assigned_role)
        try:
            route = route_model(
                ModelRouteRequest(
                    agent_id=assignment.agent_id,
                    task_type=task_type,
                    provider_mode=provider_mode,
                    available_models=available_models,
                    project_privacy_level=privacy_level,
                ),
                cfg,
            )
            decision = model_route_decision_from_result(
                run_id=run_id,
                agent_id=assignment.agent_id,
                task_type=task_type,
                provider_mode=provider_mode,
                route=route,
            )
            if persist:
                decision = upsert_model_route_decision(
                    run_id=decision.run_id,
                    step_id=decision.step_id,
                    agent_id=decision.agent_id,
                    task_type=decision.task_type,
                    model_profile=decision.model_profile,
                    selected_model=decision.selected_model,
                    selected_provider=decision.selected_provider,
                    fallback_model=decision.fallback_model,
                    fallback_provider=decision.fallback_provider,
                    provider_mode=decision.provider_mode.value,
                    reason=decision.reason,
                    confidence=decision.confidence,
                    warnings=decision.warnings,
                )
            decisions.append(decision)
        except Exception as exc:
            warnings.append(f"Failed to route {assignment.agent_id}: {exc}")

    return ModelRouteDecisionResponse(
        run_id=run_id,
        count=len(decisions),
        persisted=persist,
        decisions=decisions,
        warnings=warnings,
    )


async def _build_step_model_route_decisions(run_id: str, persist: bool) -> ModelRouteDecisionResponse:
    """Build model route decisions for every staged step of a run.

    ``persist=False``  — returns the computed decisions without writing to DB.
    ``persist=True``   — upserts each decision keyed on (run_id, step_id).
    """
    steps = list_run_steps(run_id)
    staged_steps = [s for s in steps if s.parent_step_id]  # child steps from staging
    if not staged_steps:
        return ModelRouteDecisionResponse(
            run_id=run_id,
            count=0,
            persisted=persist,
            decisions=[],
            warnings=["Run has no staged steps. Execute the run first to generate steps."],
        )

    cfg = get_config()
    provider_mode = _provider_mode_from_config(cfg)
    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    available_models = await ollama.list_models(ollama_url)
    privacy_level = str(cfg.get("project_privacy_level", "private") or "private")
    warnings: list[str] = []
    decisions: list[ModelRouteDecision] = []

    for step in staged_steps:
        agent_id = infer_agent_for_step(step.title, step.input)
        task_type = infer_task_type_for_step(step.title, step.input, agent_id)
        try:
            route = route_model(
                ModelRouteRequest(
                    agent_id=agent_id,
                    task_type=task_type,
                    provider_mode=provider_mode,
                    available_models=available_models,
                    project_privacy_level=privacy_level,
                ),
                cfg,
            )
            decision = model_route_decision_from_result(
                run_id=run_id,
                agent_id=agent_id,
                task_type=task_type,
                provider_mode=provider_mode,
                route=route,
                step_id=step.id,
            )
            if persist:
                decision = upsert_step_route_decision(
                    run_id=decision.run_id,
                    step_id=step.id,
                    agent_id=decision.agent_id,
                    task_type=decision.task_type,
                    model_profile=decision.model_profile,
                    selected_model=decision.selected_model,
                    selected_provider=decision.selected_provider,
                    fallback_model=decision.fallback_model,
                    fallback_provider=decision.fallback_provider,
                    provider_mode=decision.provider_mode.value,
                    reason=decision.reason,
                    confidence=decision.confidence,
                    warnings=decision.warnings,
                )
            decisions.append(decision)
        except Exception as exc:
            warnings.append(f"Failed to route step '{step.title}': {exc}")

    return ModelRouteDecisionResponse(
        run_id=run_id,
        count=len(decisions),
        persisted=persist,
        decisions=decisions,
        warnings=warnings,
    )


def _provider_mode_from_config(cfg: dict) -> ProviderMode:
    try:
        return ProviderMode(str(cfg.get("provider_mode", "local") or "local"))
    except ValueError:
        return ProviderMode.LOCAL


@router.get("/api/runs/{run_id}/artifacts/{artifact_name}")
async def get_run_artifact(run_id: str, artifact_name: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    artifact_path = _resolve_run_artifact_path(run, artifact_name)
    return {
        "name": artifact_name,
        "path": str(artifact_path.relative_to(_run_path(run))),
        "content": artifact_path.read_text(encoding="utf-8"),
    }


@router.post("/api/runs/{run_id}/clarifications")
async def post_clarification_answers(run_id: str, req: ClarificationAnswerRequest):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    answers = req.answers.strip()
    if not answers:
        raise HTTPException(status_code=400, detail="Clarification answers are empty")

    run_path = _run_path(run)
    run_path.mkdir(parents=True, exist_ok=True)
    artifact_name = "clarification-answers.md"
    artifact_path = run_path / artifact_name
    now = datetime.now().isoformat()
    artifact_path.write_text(
        "# Clarification Answers\n\n"
        f"**Answered at:** {now}\n\n"
        f"{answers}\n",
        encoding="utf-8",
    )
    artifacts = list(run.artifacts)
    if artifact_name not in artifacts:
        artifacts.append(artifact_name)

    logs = list(run.logs)
    logs.append(f"[{datetime.now().strftime('%H:%M:%S')}] Saved clarification answers")
    update_run(run_id, artifacts=artifacts, logs=logs)

    step = create_run_step(
        run_id=run_id,
        title="Record clarification answers",
        agent_id="user",
        status=RunStatus.COMPLETED.value,
        input="User answered clarification questions.",
        output=f"Saved {artifact_name}",
        started_at=now,
        finished_at=datetime.now().isoformat(),
    )
    return {
        "artifact": artifact_name,
        "content": artifact_path.read_text(encoding="utf-8"),
        "step": step,
    }


@router.post("/api/runs/{run_id}/regenerate-plan")
async def post_regenerate_plan(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    product_spec = _read_optional_run_artifact(run, "product-spec.md")
    questions = _read_optional_run_artifact(run, "clarification-questions.md")
    answers = _read_optional_run_artifact(run, "clarification-answers.md").strip()
    if not answers:
        raise HTTPException(status_code=400, detail="Clarification answers are required")

    now = datetime.now().isoformat()
    step = create_run_step(
        run_id=run_id,
        title="Regenerate plan from clarification answers",
        agent_id="orchestrator",
        status=RunStatus.RUNNING.value,
        input="Use product spec, clarification questions, and saved answers to update plan.md.",
        started_at=now,
    )
    update_run(run_id, current_step_id=step.id)

    cfg = get_config()
    ollama_url = cfg.get("ollama", {}).get("base_url", "http://localhost:11434")
    ollama_model = cfg.get("ollama", {}).get("default_model", "qwen2.5-coder:7b")
    instructions = load_agent_instructions("orchestrator") or "You are an AI orchestrator."

    try:
        healthy = await ollama.check_health(ollama_url)
        if healthy:
            plan_text = await ollama.chat_completion(
                prompt=_regenerate_plan_prompt(
                    run=run,
                    product_spec=product_spec,
                    questions=questions,
                    answers=answers,
                ),
                system=instructions,
                model=ollama_model,
                base_url=ollama_url,
            )
            source = f"Regenerated with Ollama model {ollama_model}."
        else:
            plan_text = _fallback_regenerated_plan(run.prompt, product_spec, answers)
            source = "Ollama unavailable; generated fallback regenerated plan."

        project = get_project(run.project_id) if run.project_id else None
        project_stack = project.stack if project else ""

        if healthy:
            try:
                architecture_text = await ollama.chat_completion(
                    prompt=build_architecture_prompt(
                        prompt=run.prompt,
                        product_spec=product_spec,
                        plan_text=plan_text,
                        project_id=run.project_id,
                        project_path=run.project_path,
                        project_stack=project_stack,
                    ),
                    system=instructions,
                    model=ollama_model,
                    base_url=ollama_url,
                )
                architecture_source = f"Architecture regenerated with Ollama model {ollama_model}."
            except Exception as exc:
                architecture_text = fallback_architecture(run.prompt, product_spec, plan_text, project_stack)
                architecture_source = f"Ollama architecture call failed: {exc}. Generated fallback architecture."
        else:
            architecture_text = fallback_architecture(run.prompt, product_spec, plan_text, project_stack)
            architecture_source = "Ollama unavailable; generated fallback architecture."

        if healthy:
            try:
                task_breakdown = await ollama.chat_completion(
                    prompt=build_task_breakdown_prompt(
                        prompt=run.prompt,
                        product_spec=product_spec,
                        plan_text=plan_text,
                        architecture_text=architecture_text,
                    ),
                    system=instructions,
                    model=ollama_model,
                    base_url=ollama_url,
                )
                tasks_source = f"Tasks regenerated with Ollama model {ollama_model}."
            except Exception as exc:
                task_breakdown = fallback_task_breakdown(run.prompt, product_spec, plan_text, architecture_text)
                tasks_source = f"Ollama task breakdown call failed: {exc}. Generated fallback tasks."
        else:
            task_breakdown = fallback_task_breakdown(run.prompt, product_spec, plan_text, architecture_text)
            tasks_source = "Ollama unavailable; generated fallback tasks."

        run_path = _run_path(run)
        plan_path = run_path / "plan.md"
        plan_path.write_text(f"# Execution Plan\n\n{plan_text}\n", encoding="utf-8")
        (run_path / "architecture.md").write_text(f"# Architecture\n\n{architecture_text}\n", encoding="utf-8")
        (run_path / "tasks.md").write_text(f"# Tasks\n\n{task_breakdown}\n", encoding="utf-8")
        # Clear stale step-level route decisions from the previous staging before
        # creating new steps. Agent-level decisions (step_id IS NULL) are preserved.
        delete_step_route_decisions_for_run(run_id)

        staged_steps = stage_executable_task_steps(
            run_id=run_id,
            parent_step_id=step.id,
            task_breakdown=task_breakdown,
            architecture_text=architecture_text,
            project_stack=project_stack,
        )

        # Execute staged steps through Ollama (same guards + limits as execute_run).
        # If Ollama is unavailable the steps remain pending and are visible in the timeline.
        executed_count = 0
        if healthy and staged_steps:
            exec_step = create_run_step(
                run_id=run_id,
                title="Execute staged task steps (regenerated)",
                agent_id="orchestrator",
                status=RunStatus.RUNNING.value,
                input=f"Run {len(staged_steps)} pending steps through Ollama.",
                started_at=datetime.now().isoformat(),
            )
            update_run(run_id, current_step_id=exec_step.id)
            regen_logs: list[str] = list(run.logs)

            def _regen_log(msg: str) -> None:
                regen_logs.append(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
                update_run(run_id, logs=regen_logs)

            # Persist step-level route decisions for the new staged steps.
            regen_step_routes: dict = {}
            try:
                regen_step_routes, _regen_route_warnings = await _persist_step_route_decisions(
                    run_id=run_id,
                    staged_steps=staged_steps,
                    provider_mode=cfg.get("provider_mode", "local"),
                    ollama_base_url=ollama_url,
                    log_fn=_regen_log,
                )
                _regen_log(
                    f"Persisted {len(regen_step_routes)}/{len(staged_steps)} "
                    "step-level route decisions for regenerated steps"
                )
            except Exception as exc:
                _regen_log(f"WARNING: Step route decision persistence failed during regen: {exc}")

            executed_count = await _execute_staged_steps(
                staged_steps=staged_steps,
                run_id=run_id,
                instructions=instructions,
                product_spec=product_spec,
                plan_text=plan_text,
                architecture_text=architecture_text,
                task_breakdown=task_breakdown,
                project_stack=project_stack,
                ollama_model=ollama_model,
                ollama_base_url=ollama_url,
                log_fn=_regen_log,
                step_route_decisions=regen_step_routes,
            )
            update_run_step(
                exec_step.id,
                status=RunStatus.COMPLETED.value,
                output=f"Executed {executed_count}/{len(staged_steps)} staged steps.",
                finished_at=datetime.now().isoformat(),
            )
            update_run(run_id, current_step_id="", logs=regen_logs)

        staged_summary = format_staged_steps(staged_steps)
        final_report = _format_regenerated_report(
            run,
            product_spec,
            questions,
            answers,
            plan_text,
            architecture_text,
            task_breakdown,
            staged_summary,
        )
        (run_path / "final-report.md").write_text(final_report, encoding="utf-8")

        artifacts = list(run.artifacts)
        for artifact in ["plan.md", "architecture.md", "tasks.md", "final-report.md"]:
            if artifact not in artifacts:
                artifacts.append(artifact)
        logs = list(run.logs)
        logs.append(
            f"[{datetime.now().strftime('%H:%M:%S')}] "
            "Regenerated plan, architecture, and tasks from clarification answers"
        )

        update_run(
            run_id,
            plan=plan_text,
            result=final_report,
            artifacts=artifacts,
            logs=logs,
            current_step_id="",
        )
        has_step_failures = staged_steps and executed_count < len(staged_steps)
        completion_note = (
            f"Completed with partial step failures ({executed_count}/{len(staged_steps)} steps succeeded)."
            if has_step_failures
            else "Completed successfully."
        )
        completed_step = update_run_step(
            step.id,
            status=RunStatus.COMPLETED.value,
            output=(
                f"{source}\n"
                f"{architecture_source}\n"
                f"{tasks_source}\n"
                f"Staged {len(staged_steps)} pending execution steps. "
                f"{completion_note}\n"
                "Saved plan.md, architecture.md, tasks.md, and final-report.md"
            ),
            finished_at=datetime.now().isoformat(),
        )
        return {
            "plan": plan_text,
            "architecture": architecture_text,
            "tasks": task_breakdown,
            "staged_steps": staged_steps,
            "executed_count": executed_count,
            "source": source,
            "artifacts": artifacts,
            "step": completed_step,
        }
    except Exception as exc:
        update_run_step(
            step.id,
            status=RunStatus.FAILED.value,
            error=str(exc),
            finished_at=datetime.now().isoformat(),
        )
        update_run(run_id, current_step_id="")
        raise


@router.post("/api/runs/{run_id}/stop")
async def stop_run(run_id: str):
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    terminal_statuses = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.STOPPED}
    if run.status in terminal_statuses:
        return {"status": run.status.value, "run_id": run_id, "task_cancelled": False}

    task_cancelled = cancel_run_task(run_id)
    update_run(run_id, status=RunStatus.STOPPED.value, finished_at=datetime.now().isoformat())
    return {"status": "stopped", "run_id": run_id, "task_cancelled": task_cancelled}


def _run_path(run) -> Path:
    return resolve_runtime_path(run.run_dir, "runs")


def _resolve_run_artifact_path(run, artifact_name: str) -> Path:
    if not artifact_name or "/" in artifact_name or "\\" in artifact_name or artifact_name in {".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid artifact name")

    run_path = _run_path(run).resolve(strict=False)
    artifact_path = (run_path / artifact_name).resolve(strict=False)
    if artifact_path != run_path and run_path not in artifact_path.parents:
        raise HTTPException(status_code=400, detail="Artifact path escapes run directory")
    if not artifact_path.exists():
        raise HTTPException(status_code=404, detail="Artifact not found")
    if not artifact_path.is_file():
        raise HTTPException(status_code=400, detail="Artifact is not a file")
    return artifact_path


def _read_optional_run_artifact(run, artifact_name: str) -> str:
    try:
        return _resolve_run_artifact_path(run, artifact_name).read_text(encoding="utf-8")
    except HTTPException as exc:
        if exc.status_code == 404:
            return ""
        raise


def _regenerate_plan_prompt(run, product_spec: str, questions: str, answers: str) -> str:
    return (
        "Regenerate the execution plan for this software development run using the user's clarification answers.\n\n"
        f"## Original Request\n{run.prompt}\n\n"
        "## Project Context\n"
        f"- Project ID: {run.project_id or 'unassigned'}\n"
        f"- Project Path: {run.project_path or 'unassigned'}\n"
        f"- Mode: {run.mode.value if hasattr(run.mode, 'value') else run.mode}\n\n"
        f"## Product Spec\n{product_spec or 'No product spec artifact found.'}\n\n"
        f"## Clarification Questions\n{questions or 'No clarification questions artifact found.'}\n\n"
        f"## User Answers\n{answers}\n\n"
        "## Required Output\n"
        "Return Markdown with these sections:\n"
        "1. Updated Product Understanding\n"
        "2. Implementation Phases\n"
        "3. Agent Roles Needed\n"
        "4. Files likely to change\n"
        "5. Safe Commands to Run\n"
        "6. Risks and Required Approvals\n"
        "7. Acceptance Criteria\n"
        "Keep it concrete and ready for execution by an AI software studio."
    )


def _fallback_regenerated_plan(prompt: str, product_spec: str, answers: str) -> str:
    return (
        "## Regenerated Plan (Fallback)\n\n"
        f"**Original request:** {prompt}\n\n"
        "### Updated Product Understanding\n\n"
        "The plan has been updated using the saved clarification answers. "
        "Ollama was unavailable, so this fallback keeps the scope conservative.\n\n"
        "### Clarification Answers\n\n"
        f"{answers}\n\n"
        "### Product Spec Context\n\n"
        f"{product_spec or 'No product spec artifact was available.'}\n\n"
        "### Implementation Phases\n\n"
        "1. Confirm scope and acceptance criteria from the clarification answers.\n"
        "2. Review the selected project structure and stack.\n"
        "3. Produce an architecture and task breakdown before editing files.\n"
        "4. Implement the smallest useful vertical slice.\n"
        "5. Run configured safe tests/build commands.\n"
        "6. Record tool calls, results, changed files, and remaining risks.\n\n"
        "### Agent Roles Needed\n\n"
        "- orchestrator\n"
        "- repo-analyst\n"
        "- backend or frontend specialist depending on project stack\n"
        "- qa\n"
        "- security reviewer\n\n"
        "### Risks and Required Approvals\n\n"
        "- Any file writes outside the selected project path must be blocked.\n"
        "- Package installs, secret changes, destructive commands, and git push require approval.\n\n"
        "### Acceptance Criteria\n\n"
        "- The requested product behavior is visible and testable.\n"
        "- Safe tests/builds pass or failures are clearly reported.\n"
        "- A final report explains implementation decisions and remaining work.\n"
    )


def _format_regenerated_report(
    run,
    product_spec: str,
    questions: str,
    answers: str,
    plan_text: str,
    architecture_text: str,
    task_breakdown: str,
    staged_summary: str,
) -> str:
    return (
        "# Run Report\n\n"
        f"**Run ID:** {run.id}\n"
        f"**Mode:** {run.mode.value if hasattr(run.mode, 'value') else run.mode}\n"
        f"**Status:** {run.status.value if hasattr(run.status, 'value') else run.status}\n"
        f"**Updated at:** {datetime.now().isoformat()}\n\n"
        "## Project\n"
        f"- **Project ID:** {run.project_id or 'unassigned'}\n"
        f"- **Project Path:** {run.project_path or 'unassigned'}\n\n"
        f"## Input\n{run.prompt}\n\n"
        f"## Product Spec\n{product_spec or 'No product spec artifact found.'}\n\n"
        f"## Clarification Questions\n{questions or 'No clarification questions artifact found.'}\n\n"
        f"## Clarification Answers\n{answers}\n\n"
        f"## Regenerated Plan\n{plan_text}\n\n"
        f"## Architecture\n{architecture_text}\n\n"
        f"## Tasks\n{task_breakdown}\n\n"
        f"## Executable Task Steps\n{staged_summary}\n\n"
        "## Artifacts\n"
        "- `input.md`\n"
        "- `product-spec.md`\n"
        "- `clarification-questions.md`\n"
        "- `clarification-answers.md`\n"
        "- `plan.md`\n"
        "- `architecture.md`\n"
        "- `tasks.md`\n"
        "- `final-report.md`\n"
    )


# ── Local Tools ──────────────────────────────────────────────────────────────

@router.get("/api/workspace/status")
async def workspace_status():
    """Return a compact git workspace status for the dashboard."""
    return _workspace_status(PROJECT_ROOT)


@router.get("/api/projects/{project_id}/workspace/status")
async def project_workspace_status(project_id: str):
    project = _get_project_or_404(project_id)
    return _workspace_status(Path(project.path))


@router.post("/api/projects/{project_id}/tools/run-tests")
async def run_project_tests(project_id: str):
    project = _get_project_or_404(project_id)
    return _run_project_command(project, project.test_command, "test")


@router.post("/api/projects/{project_id}/tools/run-build")
async def run_project_build(project_id: str):
    project = _get_project_or_404(project_id)
    return _run_project_command(project, project.build_command, "build")


@router.post("/api/projects/{project_id}/tools/run-command")
async def run_project_command_endpoint(
    project_id: str,
    req: RunProjectCommandRequest,
) -> RunProjectCommandResponse:
    """Run a project-profile command (test/build/lint/typecheck) safely.

    Only commands from the Project Profile allowlist are executed:
    - test → project.test_command
    - build → project.build_command
    - lint / typecheck → matched from project.safe_commands by keyword

    The command is run with shell=False, cwd=project.path, LC_ALL=C,
    stdout/stderr capped at 100 000 chars. A ToolCall record is created
    and linked to the supplied run_id / step_id / project_id.
    """
    project = _get_project_or_404(project_id)

    kind = req.command_kind

    # Resolve the command from the project profile
    if kind == ProjectCommandKind.TEST:
        command = (project.test_command or "").strip()
        if not command:
            raise HTTPException(
                status_code=400,
                detail="Project test_command is not configured. Set it in the Project Profile.",
            )
    elif kind == ProjectCommandKind.BUILD:
        command = (project.build_command or "").strip()
        if not command:
            raise HTTPException(
                status_code=400,
                detail="Project build_command is not configured. Set it in the Project Profile.",
            )
    else:
        # lint or typecheck: search safe_commands by keyword
        command = find_safe_command_for_kind(kind.value, project.safe_commands) or ""
        if not command:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"No {kind.value} command found in project safe_commands. "
                    f"Add a matching command (e.g. 'ruff check .' for lint, 'npx tsc --noEmit' for typecheck)."
                ),
            )

    # Verify the resolved command is allowed by the project profile
    allowed = set()
    if project.test_command:
        allowed.add(project.test_command.strip())
    if project.build_command:
        allowed.add(project.build_command.strip())
    for sc in project.safe_commands:
        if sc.strip():
            allowed.add(sc.strip())

    if command not in allowed:
        raise HTTPException(
            status_code=403,
            detail="Resolved command is not in the project allowlist. This is a safety guard.",
        )

    # Create a ToolCall record before running
    input_meta = json.dumps({
        "command_kind": kind.value,
        "command": command,
        "run_id": req.run_id,
        "step_id": req.step_id,
        "agent_id": req.agent_id,
    }, ensure_ascii=False)
    started_at_str = datetime.now().isoformat()
    tool_call = create_tool_call(
        run_id=req.run_id or f"project:{project.id}",
        project_id=project.id,
        step_id=req.step_id,
        tool_name="run-command",
        command=command,
        cwd=project.path,
        status="pending",
        input_json=input_meta,
        risk_level="medium",
        started_at=started_at_str,
    )

    # Execute
    try:
        runner_result = _run_safe_command(
            project.path,
            command,
            timeout_seconds=req.timeout_seconds,
        )
    except ValueError as exc:
        _mark_tool_call_failed(tool_call.id, str(exc))
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        _mark_tool_call_failed(tool_call.id, str(exc))
        raise HTTPException(status_code=500, detail=f"Command runner error: {exc}") from exc

    # Update ToolCall — non-zero returncode is still "completed"
    finished_at_str = datetime.now().isoformat()
    output_meta = json.dumps({
        "returncode": runner_result["returncode"],
        "timed_out": runner_result["timed_out"],
        "duration_ms": runner_result["duration_ms"],
    }, ensure_ascii=False)
    update_tool_call(
        tool_call.id,
        status="completed",
        stdout=runner_result["stdout"],
        stderr=runner_result["stderr"],
        returncode=runner_result["returncode"],
        output_json=output_meta,
        completed_at=finished_at_str,
        finished_at=finished_at_str,
    )

    return RunProjectCommandResponse(
        command_kind=kind.value,
        command=runner_result["command"],
        cwd=runner_result["cwd"],
        returncode=runner_result["returncode"],
        stdout=runner_result["stdout"],
        stderr=runner_result["stderr"],
        duration_ms=runner_result["duration_ms"],
        timed_out=runner_result["timed_out"],
        tool_call_id=tool_call.id,
    )


@router.post("/api/projects/{project_id}/tools/analyze-command-result")
async def analyze_project_command_result(
    project_id: str,
    req: CommandAnalysisRequest,
) -> CommandAnalysisResponse:
    """Heuristic analysis of a previous run-command output.

    Accepts either a tool_call_id (looks up the stored stdout/stderr) or
    inline stdout/stderr/returncode fields. No LLM — pure pattern matching.
    Creates a low-risk ToolCall audit record and returns CommandAnalysisResponse.
    """
    project = _get_project_or_404(project_id)

    stdout = req.stdout
    stderr = req.stderr
    returncode = req.returncode
    timed_out = False
    source_tc_id = req.tool_call_id

    # Resolve from stored tool_call if id provided
    if req.tool_call_id:
        all_calls = list_tool_calls_for_project(project_id, limit=200)
        tc = next((c for c in all_calls if c.id == req.tool_call_id), None)
        if tc is None:
            raise HTTPException(
                status_code=404,
                detail=f"tool_call '{req.tool_call_id}' not found for project '{project_id}'",
            )
        stdout = tc.stdout or req.stdout
        stderr = tc.stderr or req.stderr
        if returncode is None:
            returncode = tc.returncode
        # Check timed_out from output_json if present
        if tc.output_json:
            try:
                meta = json.loads(tc.output_json)
                timed_out = bool(meta.get("timed_out", False))
            except (json.JSONDecodeError, AttributeError):
                pass

    # Create audit tool_call before analysis
    input_meta = json.dumps({
        "source_tool_call_id": source_tc_id,
        "command_kind": req.command_kind,
        "run_id": req.run_id,
        "step_id": req.step_id,
        "agent_id": req.agent_id,
        "returncode": returncode,
    }, ensure_ascii=False)
    started_at_str = datetime.now().isoformat()
    audit_tc = create_tool_call(
        run_id=req.run_id or f"project:{project.id}",
        project_id=project.id,
        step_id=req.step_id,
        tool_name="analyze-command-result",
        status="pending",
        input_json=input_meta,
        risk_level="low",
        started_at=started_at_str,
    )

    try:
        raw = _analyze_command(
            stdout=stdout,
            stderr=stderr,
            returncode=returncode,
            timed_out=timed_out,
            command_kind=req.command_kind,
        )
    except Exception as exc:
        _mark_tool_call_failed(audit_tc.id, str(exc))
        raise HTTPException(status_code=500, detail=f"Analysis error: {exc}") from exc

    finished_at_str = datetime.now().isoformat()
    output_meta = json.dumps({
        "status": raw["status"],
        "issue_count": len(raw["issues"]),
        "can_create_fix_proposal": raw["can_create_fix_proposal"],
    }, ensure_ascii=False)
    update_tool_call(
        audit_tc.id,
        status="completed",
        output_json=output_meta,
        completed_at=finished_at_str,
        finished_at=finished_at_str,
    )

    return CommandAnalysisResponse(
        status=raw["status"],
        summary=raw["summary"],
        issues=[CommandIssue(**i) for i in raw["issues"]],
        suggested_next_actions=raw["suggested_next_actions"],
        can_create_fix_proposal=raw["can_create_fix_proposal"],
        source_tool_call_id=source_tc_id,
    )


@router.post("/api/projects/{project_id}/tools/list-files")
async def run_project_list_files(project_id: str, req: ListFilesRequest | None = None):
    project = _get_project_or_404(project_id)
    body = req or ListFilesRequest()
    return _run_logged_read_tool(
        project=project,
        tool_name="list_files",
        req=body,
        operation=lambda: project_list_files(project.path, path=body.path, max_files=body.max_files),
    )


@router.post("/api/projects/{project_id}/tools/read-file")
async def run_project_read_file(project_id: str, req: ReadFileRequest):
    project = _get_project_or_404(project_id)
    return _run_logged_read_tool(
        project=project,
        tool_name="read_file",
        req=req,
        operation=lambda: project_read_file(project.path, path=req.path, max_chars=req.max_chars),
    )


@router.post("/api/projects/{project_id}/tools/search-code")
async def run_project_search_code(project_id: str, req: SearchCodeRequest):
    project = _get_project_or_404(project_id)
    return _run_logged_read_tool(
        project=project,
        tool_name="search_code",
        req=req,
        operation=lambda: project_search_code(
            project.path,
            query=req.query,
            path=req.path,
            max_results=req.max_results,
        ),
    )


@router.post("/api/projects/{project_id}/tools/propose-patch")
async def run_project_propose_patch(project_id: str, req: ProposePatchRequest):
    project = _get_project_or_404(project_id)
    return _run_logged_read_tool(
        project=project,
        tool_name="propose-patch",
        req=req,
        operation=lambda: propose_project_patch(project.path, req.operations),
        risk_level="medium",
    )


@router.post("/api/projects/{project_id}/tools/apply-patch")
async def run_project_apply_patch(project_id: str, req: ApplyPatchRequest):
    project = _get_project_or_404(project_id)

    def apply_with_git_snapshot():
        result = apply_project_patch(project.path, req.operations, req.confirm)
        status = _run_project_git(project, ["status", "--short"])
        diff_stat = _run_project_git(project, ["diff", "--stat"])
        return {
            **result,
            "git_status": status["stdout"] or status["stderr"],
            "git_diff_stat": diff_stat["stdout"] or diff_stat["stderr"],
            "applied_from_proposal_id": req.proposal_id,
        }

    return _run_logged_read_tool(
        project=project,
        tool_name="apply-patch",
        req=req,
        operation=apply_with_git_snapshot,
        risk_level="high",
    )


@router.post("/api/projects/{project_id}/tools/rollback-patch")
async def rollback_project_patch_endpoint(
    project_id: str,
    req: RollbackPatchRequest,
) -> RollbackPatchResponse:
    """Revert files from a previous apply-patch using stored rollback metadata.

    - Requires confirm=true.
    - Reads rollback_data from the apply-patch tool_call's output_json.
    - Skips files that have been modified after the apply (conflict detection).
    - Logs a high-risk rollback-patch tool_call.
    - No shell commands executed.
    """
    project = _get_project_or_404(project_id)

    # Verify tool_call belongs to this project and is an apply-patch
    all_calls = list_tool_calls_for_project(project_id, limit=500)
    source_tc = next((c for c in all_calls if c.id == req.tool_call_id), None)
    if source_tc is None:
        raise HTTPException(
            status_code=404,
            detail=f"tool_call '{req.tool_call_id}' not found for project '{project_id}'",
        )
    if source_tc.tool_name != "apply-patch":
        raise HTTPException(
            status_code=400,
            detail=f"Rollback only supported for apply-patch tool calls, got '{source_tc.tool_name}'",
        )

    # Parse rollback_data from stored output_json
    rollback_data: list[dict] = []
    if source_tc.output_json:
        try:
            out = json.loads(source_tc.output_json)
            rollback_data = out.get("rollback_data", [])
        except (json.JSONDecodeError, AttributeError):
            pass

    if not rollback_data:
        raise HTTPException(
            status_code=400,
            detail="No rollback metadata found for this apply-patch tool call. "
                   "Only patches applied after rollback support was introduced can be reverted.",
        )

    # Create audit tool_call (logged before execution)
    input_meta = json.dumps({
        "source_tool_call_id": req.tool_call_id,
        "confirm": req.confirm,
        "run_id": req.run_id,
        "step_id": req.step_id,
        "agent_id": req.agent_id,
    }, ensure_ascii=False)
    started_at = datetime.now().isoformat()
    rollback_tc = create_tool_call(
        run_id=req.run_id or f"project:{project.id}",
        project_id=project.id,
        step_id=req.step_id,
        tool_name="rollback-patch",
        cwd=project.path,
        status="pending",
        input_json=input_meta,
        risk_level="high",
        started_at=started_at,
    )

    try:
        raw = _rollback_patch(project.path, rollback_data, req.confirm)
        git_status = _run_project_git(project, ["status", "--short"])
        git_diff = _run_project_git(project, ["diff", "--stat"])
        result = {
            **raw,
            "git_status": git_status["stdout"] or git_status["stderr"],
            "git_diff_stat": git_diff["stdout"] or git_diff["stderr"],
            "tool_call_id": rollback_tc.id,
        }
        completed_at = datetime.now().isoformat()
        update_tool_call(
            rollback_tc.id,
            status="completed",
            output_json=json.dumps({
                "rolled_back_files": raw["rolled_back_files"],
                "skipped_files": raw["skipped_files"],
                "warnings": raw["warnings"],
                "summary": raw["summary"],
                "source_tool_call_id": req.tool_call_id,
            }, ensure_ascii=False),
            completed_at=completed_at,
            finished_at=completed_at,
        )
        return RollbackPatchResponse(
            rolled_back_files=[RolledBackFile(**f) for f in raw["rolled_back_files"]],
            skipped_files=[RolledBackFile(**f) for f in raw["skipped_files"]],
            warnings=raw["warnings"],
            git_status=result["git_status"],
            git_diff_stat=result["git_diff_stat"],
            tool_call_id=rollback_tc.id,
        )
    except PermissionError as exc:
        _mark_tool_call_failed(rollback_tc.id, str(exc))
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        _mark_tool_call_failed(rollback_tc.id, str(exc))
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        _mark_tool_call_failed(rollback_tc.id, str(exc))
        raise HTTPException(status_code=500, detail=f"Rollback failed: {exc}") from exc


@router.post("/api/projects/{project_id}/tools/review-patch")
async def review_project_patch_endpoint(
    project_id: str,
    req: PatchReviewRequest,
) -> PatchReviewResponse:
    """Review patch operations for safety issues before creating a proposal or applying.

    This endpoint is read-only:
    - Does NOT create tool_calls.
    - Does NOT modify files.
    - Does NOT create proposals.
    - Does NOT apply patches.
    """
    project = _get_project_or_404(project_id)
    ops = [PatchReviewOperation(
        file_path=op.file_path,
        old_text=op.old_text,
        new_text=op.new_text,
    ) for op in req.operations]
    return review_patch_operations(project.path, ops)


@router.get("/api/projects/{project_id}/git/status")
async def get_project_git_status(project_id: str):
    project = _get_project_or_404(project_id)
    result = _run_project_git(project, ["status", "--short"])
    lines = [line for line in result["stdout"].splitlines() if line.strip()]
    return {
        "project_id": project.id,
        "project_path": project.path,
        "command": ["git", "status", "--short"],
        "returncode": result["returncode"],
        "stdout": result["stdout"],
        "stderr": result["stderr"],
        "changed_files": [_parse_git_status_line(line) for line in lines],
        "clean": result["returncode"] == 0 and not lines,
    }


@router.get("/api/projects/{project_id}/git/diff")
async def get_project_git_diff(project_id: str):
    project = _get_project_or_404(project_id)
    stat = _run_project_git(project, ["diff", "--stat"])
    name_only = _run_project_git(project, ["diff", "--name-only"])
    diff = _run_project_git(project, ["diff"], max_chars=200_000)
    return {
        "project_id": project.id,
        "project_path": project.path,
        "commands": [
            ["git", "diff", "--stat"],
            ["git", "diff", "--name-only"],
            ["git", "diff"],
        ],
        "returncode": _first_nonzero(stat["returncode"], name_only["returncode"], diff["returncode"]),
        "stat": stat["stdout"],
        "name_only": [line for line in name_only["stdout"].splitlines() if line.strip()],
        "diff": diff["stdout"],
        "stderr": "\n".join(item for item in [stat["stderr"], name_only["stderr"], diff["stderr"]] if item),
        "truncated": diff["truncated"],
    }


@router.get("/api/projects/{project_id}/tool-calls")
async def get_project_tool_calls(project_id: str):
    _get_project_or_404(project_id)
    return list_tool_calls_for_project(project_id)


def _workspace_status(path: Path) -> dict:
    env = {
        "LC_ALL": "C",
        "LANG": "C",
        "PATH": os.environ.get("PATH", ""),
    }
    try:
        result = subprocess.run(
            ["git", "-C", str(path), "status", "--short", "--branch"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
            env=env,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to read git status: {exc}") from exc

    lines = [line for line in result.stdout.splitlines() if line.strip()]
    branch = lines[0].replace("## ", "", 1) if lines and lines[0].startswith("## ") else ""
    changes = [_parse_git_status_line(line) for line in lines[1:]]
    # Normalize non-git-repo error so tests are locale-independent
    error = result.stderr or ""
    if result.returncode != 0 and "not a git repository" not in error.lower():
        error = f"not a git repository (or any parent): {error.strip()}"
    return {
        "branch": branch,
        "clean": result.returncode == 0 and len(changes) == 0,
        "changes": changes,
        "raw": result.stdout,
        "error": error,
        "returncode": result.returncode,
        "cwd": str(path),
    }


def _get_project_or_404(project_id: str):
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if not project.path:
        raise HTTPException(status_code=400, detail="Project path is not configured")
    return project


def _run_logged_read_tool(project, tool_name: str, req, operation, risk_level: str = "low"):
    input_data = req.model_dump() if hasattr(req, "model_dump") else {}
    started_at = datetime.now().isoformat()
    tool_call = create_tool_call(
        run_id=input_data.get("run_id", ""),
        project_id=project.id,
        step_id=input_data.get("step_id", ""),
        tool_name=tool_name,
        cwd=project.path,
        status="pending",
        input_json=json.dumps(input_data, ensure_ascii=False),
        risk_level=risk_level,
        started_at=started_at,
    )
    try:
        result = operation()
        completed_at = datetime.now().isoformat()
        result_with_id = {**result, "tool_call_id": tool_call.id}
        if tool_name == "propose-patch":
            result_with_id["proposal_id"] = tool_call.id
        update_tool_call(
            tool_call.id,
            status="completed",
            output_json=json.dumps(result_with_id, ensure_ascii=False),
            completed_at=completed_at,
            finished_at=completed_at,
        )
        return result_with_id
    except HTTPException as exc:
        _mark_tool_call_failed(tool_call.id, str(exc.detail))
        raise
    except PermissionError as exc:
        _mark_tool_call_failed(tool_call.id, str(exc))
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        _mark_tool_call_failed(tool_call.id, str(exc))
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        _mark_tool_call_failed(tool_call.id, str(exc))
        raise HTTPException(status_code=500, detail=f"Tool execution failed: {exc}") from exc


def _mark_tool_call_failed(tool_call_id: str, error: str) -> None:
    completed_at = datetime.now().isoformat()
    update_tool_call(
        tool_call_id,
        status="failed",
        error=error,
        completed_at=completed_at,
        finished_at=completed_at,
    )


def _run_project_git(project, args: list[str], timeout: int = 15, max_chars: int | None = None) -> dict:
    env = {
        "LC_ALL": "C",
        "LANG": "C",
        "PATH": os.environ.get("PATH", ""),
    }
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=project.path,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            env=env,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or "Git command timed out"
        result = subprocess.CompletedProcess(["git", *args], 124, stdout, stderr)

    stdout = result.stdout or ""
    truncated = False
    if max_chars is not None and len(stdout) > max_chars:
        stdout = stdout[:max_chars]
        truncated = True
    return {
        "returncode": result.returncode,
        "stdout": stdout,
        "stderr": result.stderr or "",
        "truncated": truncated,
    }


def _first_nonzero(*codes: int) -> int:
    for code in codes:
        if code != 0:
            return code
    return 0


def _run_project_command(project, command: str, command_type: str) -> dict:
    command = (command or "").strip()
    if not command:
        raise HTTPException(status_code=400, detail=f"Project {command_type}_command is empty")

    blocked_match = _find_blocked_command(command, project.blocked_commands)
    if blocked_match:
        return _approval_required_response(
            project=project,
            command=command,
            command_type=command_type,
            action="blocked_command",
            description=f"Command matches project blocked command: {blocked_match}",
        )

    needs_approval, action, description = check_command(command)
    if needs_approval:
        return _approval_required_response(
            project=project,
            command=command,
            command_type=command_type,
            action=action,
            description=description,
        )

    if not _is_safe_command(command, project.safe_commands):
        return _approval_required_response(
            project=project,
            command=command,
            command_type=command_type,
            action="command_not_allowed",
            description="Command is not listed in project safe_commands",
        )

    return _execute_project_command(project, command, command_type)


def _execute_project_command(project, command: str, command_type: str, approval_id: str = "") -> dict:
    try:
        args = shlex.split(command)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid command syntax: {exc}") from exc
    if not args:
        raise HTTPException(status_code=400, detail=f"Project {command_type}_command is empty")

    project_path = Path(project.path)
    report_dir = PROJECT_ROOT / "runs" / (
        f"project-{command_type}-{datetime.now().strftime('%Y-%m-%dT%H-%M-%S')}_{project.id}"
    )
    report_dir.mkdir(parents=True, exist_ok=True)

    started_at = datetime.now()
    try:
        result = subprocess.run(
            args,
            cwd=project_path,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
        finished_at = datetime.now()
    except subprocess.TimeoutExpired as exc:
        finished_at = datetime.now()
        result = subprocess.CompletedProcess(args, 124, exc.stdout or "", exc.stderr or "")

    report = _format_test_report(
        command=command,
        returncode=result.returncode,
        stdout=result.stdout,
        stderr=result.stderr,
        started_at=started_at,
        finished_at=finished_at,
    )
    report_path = report_dir / f"{command_type}-report.md"
    report_path.write_text(report, encoding="utf-8")
    relative_report_path = str(report_path.relative_to(PROJECT_ROOT))
    status = "passed" if result.returncode == 0 else "failed"
    tool_call = create_tool_call(
        run_id=f"project:{project.id}",
        project_id=project.id,
        tool_name=f"project_{command_type}",
        command=command,
        cwd=project.path,
        status=status,
        approval_id=approval_id,
        stdout=result.stdout,
        stderr=result.stderr,
        returncode=result.returncode,
        report_path=relative_report_path,
        started_at=started_at.isoformat(),
        finished_at=finished_at.isoformat(),
    )

    return {
        "approval_required": False,
        "approval_id": approval_id,
        "tool_call_id": tool_call.id,
        "project_id": project.id,
        "project_path": project.path,
        "command": command,
        "command_type": command_type,
        "status": status,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "started_at": started_at.isoformat(),
        "finished_at": finished_at.isoformat(),
        "report_path": relative_report_path,
    }


def _execute_project_approval(approval) -> dict | None:
    if not approval.run_id.startswith("project:") or not approval.command:
        return None

    project_id = approval.run_id.removeprefix("project:")
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Approval project not found")

    command_type = _approved_project_command_type(project, approval.command)
    return _execute_project_command(project, approval.command, command_type, approval_id=approval.id)


def _approved_project_command_type(project, command: str) -> str:
    normalized = command.strip()
    if normalized == project.test_command.strip():
        return "test"
    if normalized == project.build_command.strip():
        return "build"
    return "approved"


def _find_blocked_command(command: str, blocked_commands: list[str]) -> str:
    normalized = command.strip()
    for blocked in blocked_commands:
        blocked = blocked.strip()
        if blocked and (normalized == blocked or normalized.startswith(f"{blocked} ")):
            return blocked
    return ""


def _is_safe_command(command: str, safe_commands: list[str]) -> bool:
    normalized = command.strip()
    return any(normalized == safe.strip() for safe in safe_commands if safe.strip())


def _approval_required_response(project, command: str, command_type: str, action: str, description: str) -> dict:
    approval_run_id = f"project:{project.id}"
    approval = find_pending_approval(approval_run_id, action, command)
    if not approval:
        approval = create_approval(
            run_id=approval_run_id,
            action=action,
            command=command,
            description=(
                f"Project tool action requires approval.\n"
                f"Project: {project.name} ({project.id})\n"
                f"Path: {project.path}\n"
                f"Command type: {command_type}\n"
                f"Reason: {description}"
            ),
        )
    return {
        "approval_required": True,
        "approval_id": approval.id,
        "project_id": project.id,
        "project_path": project.path,
        "command": command,
        "command_type": command_type,
        "status": "approval_required",
        "returncode": None,
        "stdout": "",
        "stderr": "",
        "action": action,
        "description": description,
        "report_path": "",
    }


@router.post("/api/tools/run-tests")
async def run_tests():
    """Run the repository test script and save a report under runs/."""
    report_dir = PROJECT_ROOT / "runs" / f"test-run-{datetime.now().strftime('%Y-%m-%dT%H-%M-%S')}"
    report_dir.mkdir(parents=True, exist_ok=True)

    command = ["bash", "scripts/run_tests.sh"]
    started_at = datetime.now()
    try:
        result = subprocess.run(
            command,
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
        finished_at = datetime.now()
    except subprocess.TimeoutExpired as exc:
        finished_at = datetime.now()
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        result = subprocess.CompletedProcess(command, 124, stdout, stderr)

    report = _format_test_report(
        command=" ".join(command),
        returncode=result.returncode,
        stdout=result.stdout,
        stderr=result.stderr,
        started_at=started_at,
        finished_at=finished_at,
    )
    report_path = report_dir / "test-report.md"
    report_path.write_text(report, encoding="utf-8")

    return {
        "command": " ".join(command),
        "status": "passed" if result.returncode == 0 else "failed",
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "started_at": started_at.isoformat(),
        "finished_at": finished_at.isoformat(),
        "report_path": str(report_path.relative_to(PROJECT_ROOT)),
    }


def _parse_git_status_line(line: str) -> dict[str, str]:
    """Parse one `git status --short` row for the UI."""
    status = line[:2].strip() or "?"
    path = line[3:] if len(line) > 3 else line.strip()
    return {"status": status, "path": path}


def _format_test_report(
    command: str,
    returncode: int,
    stdout: str,
    stderr: str,
    started_at: datetime,
    finished_at: datetime,
) -> str:
    status = "passed" if returncode == 0 else "failed"
    return (
        "# Test Run Report\n\n"
        f"**Status:** {status}\n"
        f"**Command:** `{command}`\n"
        f"**Return code:** {returncode}\n"
        f"**Started:** {started_at.isoformat()}\n"
        f"**Finished:** {finished_at.isoformat()}\n\n"
        "## Stdout\n\n"
        "```text\n"
        f"{stdout.rstrip()}\n"
        "```\n\n"
        "## Stderr\n\n"
        "```text\n"
        f"{stderr.rstrip()}\n"
        "```\n"
    )


# ── Approvals ────────────────────────────────────────────────────────────────

@router.get("/api/approvals")
async def get_approvals():
    return list_approvals()


@router.post("/api/approvals/{approval_id}/approve")
async def approve(approval_id: str, body: ApprovalDecision | None = None):
    existing = get_approval(approval_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Approval not found")
    if existing.status != ApprovalStatus.PENDING:
        return {"approval": existing, "execution": None, "already_resolved": True}

    result = resolve_approval(approval_id, ApprovalStatus.APPROVED, reason=body.reason if body else "")
    if not result:
        raise HTTPException(status_code=404, detail="Approval not found")

    execution = _execute_project_approval(result)
    return {"approval": result, "execution": execution, "already_resolved": False}


@router.post("/api/approvals/{approval_id}/reject")
async def reject(approval_id: str, body: ApprovalDecision | None = None):
    result = resolve_approval(approval_id, ApprovalStatus.REJECTED, reason=body.reason if body else "")
    if not result:
        raise HTTPException(status_code=404, detail="Approval not found")
    return result


# ── Config ───────────────────────────────────────────────────────────────────

@router.get("/api/config")
async def get_configuration():
    return get_config()


@router.post("/api/config")
async def update_configuration(req: ConfigUpdate):
    updated = save_config(req.model_dump(exclude_none=True))
    return updated


# ── Workflow Policy (read-only) ──────────────────────────────────────────────


@router.get("/api/workflow-policy")
async def get_workflow_policy(
    mode: str = Query(default="guided", description="Automation mode: manual, guided, or safe_prep"),
) -> WorkflowPolicyResponse:
    """Return the workflow action policy matrix for the given automation mode.

    Pure read-only — no DB reads, no tool execution, no state mutation.
    """
    try:
        automation_mode = WorkflowAutomationMode(mode)
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid mode '{mode}'. Must be one of: manual, guided, safe_prep",
        )
    policies = list_workflow_action_policies(automation_mode)
    return WorkflowPolicyResponse(mode=automation_mode, policies=policies)


# ── Project Intake (read-only) ───────────────────────────────────────────────


@router.post("/api/project-intake/questions")
async def post_project_intake_questions(
    req: ProjectIntakeRequest,
) -> ProjectIntakeResponse:
    """Analyze a raw project idea and return structured intake questions.

    Pure read-only — no DB reads, no LLM calls, no tool execution, no state mutation.
    """
    if not req.idea or not req.idea.strip():
        raise HTTPException(
            status_code=400,
            detail="Field 'idea' must be a non-empty string.",
        )
    return analyze_project_intake(req)


@router.post("/api/project-intake/brief-draft")
async def post_project_intake_brief_draft(
    req: ProjectBriefDraftRequest,
) -> ProjectBriefDraftResponse:
    """Generate a deterministic project brief draft from intake analysis.

    Pure read-only — no DB reads, no DB writes, no LLM calls, no tool
    execution, no project/run creation, no ToolCalls, no state mutation.
    """
    if not req.idea or not req.idea.strip():
        raise HTTPException(
            status_code=400,
            detail="Field 'idea' must be a non-empty string.",
        )
    return draft_project_brief(req)


@router.post("/api/project-intake/plan-preview")
async def post_project_intake_plan_preview(
    req: DevelopmentPlanPreviewRequest,
) -> DevelopmentPlanPreviewResponse:
    """Generate a deterministic development plan preview from intake data.

    Pure read-only — no DB reads, no DB writes, no LLM calls, no tool
    execution, no project/run creation, no assignments, no ToolCalls, no state
    mutation.
    """
    if not req.idea or not req.idea.strip():
        raise HTTPException(
            status_code=400,
            detail="Field 'idea' must be a non-empty string.",
        )
    return draft_development_plan(req)
